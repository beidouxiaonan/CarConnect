from pathlib import Path
import hashlib
import struct
import zipfile
from patch_brand import payload,VERSION,strings

ROOT = Path(__file__).resolve().parent.parent
original = ROOT / '.private/apk-analysis/easyplay/input.apk'
patched = ROOT / 'artifacts/CarConnect-0.1.4-beta-OEM-test-Android4.2.apk'
expected = ROOT / '.private/apk-analysis/easyplay/oem4/patched-classes3.dex'

def signature(name):
    upper = name.upper()
    return upper.startswith('META-INF/') and (upper.endswith(('.RSA', '.DSA', '.EC', '.SF')) or upper == 'META-INF/MANIFEST.MF')

with zipfile.ZipFile(original) as before, zipfile.ZipFile(patched) as after:
    old = {n for n in before.namelist() if not signature(n)}
    new = {n for n in after.namelist() if not signature(n)}
    assert old == new, (old - new, new - old)
    assert after.testzip() is None
    changed = [n for n in sorted(old) if before.read(n) != after.read(n)]
    expected_changes=payload(original)
    expected_changes['classes3.dex']=expected.read_bytes()
    assert changed == sorted(expected_changes),changed
    for name,data in expected_changes.items():assert after.read(name)==data,name
    manifest=after.read('AndroidManifest.xml')
    assert VERSION in strings(manifest[8:8+struct.unpack_from('<I',manifest,12)[0]])
    # minSdkVersion must be 17 (Android 4.2); resolve it via the resource map.
    at=8; rids=[]
    while at<len(manifest):
        kind,header,size=struct.unpack_from('<HHI',manifest,at)
        if kind==0x180:
            rids=list(struct.unpack_from('<%dI'%((size-header)//4),manifest,at+header))
        elif kind==0x102:
            attrStart,attrSize,attrCount=struct.unpack_from('<HHH',manifest,at+24)
            for i in range(attrCount):
                pos=at+16+attrStart+i*attrSize
                nameIndex=struct.unpack_from('<I',manifest,pos+4)[0]
                if nameIndex<len(rids) and rids[nameIndex]==0x0101020c:
                    assert struct.unpack_from('<I',manifest,pos+16)[0]==17
        at+=size
    resources=after.read('resources.arsc')
    assert strings(resources[12:12+struct.unpack_from('<I',resources,16)[0]])[0]=='CarConnect' 
    assert after.read('classes3.dex') == expected.read_bytes()
    dex = after.read('classes3.dex')
    assert dex[:8] == b'dex\n035\0', dex[:8]
    assert hashlib.sha1(dex[32:]).digest() == dex[12:32]
    assert struct.unpack_from('<I', dex, 88)[0] < 65536
    assert struct.unpack_from('<I', dex, 80)[0] < 65536
    assert struct.unpack_from('<I', dex, 64)[0] < 65536
    print('APK payload audit PASS: only classes3.dex, Manifest version, app label and about/history assets changed')
    print(f'Preserved {len(old)-len(expected_changes)} payload entries; authentication assets, all native libraries and classes1/classes2 identical')
    print(f'DEX 035, method refs={struct.unpack_from("<I", dex, 88)[0]}, field refs={struct.unpack_from("<I", dex, 80)[0]}')
    print(f'Original APK SHA256: {hashlib.sha256(original.read_bytes()).hexdigest()}')
    digest = hashlib.sha256(patched.read_bytes()).hexdigest()
    patched.with_suffix('.apk.sha256').write_text(f'{digest}  {patched.name}\n', encoding='ascii')
    print(f'Patched APK SHA256: {digest}')
