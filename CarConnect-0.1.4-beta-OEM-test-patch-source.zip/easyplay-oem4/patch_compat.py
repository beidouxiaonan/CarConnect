import re

P = 'Lcom/shilapi/xcertplay/patch/'
CP = P + 'Compat17;'

def fix_reflective_catches(text):
    """ReflectiveOperationException is unavailable on API 17 (public API 19).
    Replace it with Exception and reorder handlers so the subclass
    (RuntimeException / SecurityException) is caught before its superclass."""
    text = text.replace('Ljava/lang/ReflectiveOperationException;',
                        'Ljava/lang/Exception;')
    pattern = re.compile(
        r'(?m)^(?P<exc>    \.catch Ljava/lang/Exception; \{[^}]*\} :\S+)\n'
        r'(?P<sub>    \.catch Ljava/lang/(?:Runtime|Security)Exception; \{[^}]*\} :\S+)\n')
    def swap(m):
        return m.group('sub') + '\n' + m.group('exc') + '\n'
    return pattern.sub(swap, text)

def load_current(work, name):
    """Read the latest version: modified if an earlier patch already wrote it,
    otherwise the freshly disassembled original."""
    m = work/'modified'/name
    if m.exists():
        return m.read_text(encoding='utf-8')
    return (work/'original'/name).read_text(encoding='utf-8')

def patch_compat(work, original, write, edit_method, one):
    # ---- CarPlayController: constructor BluetoothManager + reflection catch
    name = 'com/shilapi/xcertplay/orchestration/CarPlayController.smali'
    text = load_current(work, name)
    old_ctor = '''    .line 185
    iget-object v1, v0, Lcom/shilapi/xcertplay/orchestration/CarPlayController;->appContext:Landroid/content/Context;

    const-string v2, "bluetooth"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    instance-of v2, v1, Landroid/bluetooth/BluetoothManager;

    if-eqz v2, :cond_bc

    check-cast v1, Landroid/bluetooth/BluetoothManager;

    goto :goto_bd

    :cond_bc
    const/4 v1, 0x0

    :goto_bd
    if-eqz v1, :cond_c4

    invoke-virtual {v1}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v1

    goto :goto_c5

    :cond_c4
    const/4 v1, 0x0

    :goto_c5
    iput-object v1, v0, Lcom/shilapi/xcertplay/orchestration/CarPlayController;->bluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;'''
    new_ctor = '''    .line 185
    iget-object v1, v0, Lcom/shilapi/xcertplay/orchestration/CarPlayController;->appContext:Landroid/content/Context;

    invoke-static {v1}, ''' + CP + '''->getBluetoothAdapter(Landroid/content/Context;)Landroid/bluetooth/BluetoothAdapter;

    move-result-object v1

    iput-object v1, v0, Lcom/shilapi/xcertplay/orchestration/CarPlayController;->bluetoothAdapter:Landroid/bluetooth/BluetoothAdapter;'''
    text = one(text, old_ctor, new_ctor)
    text = fix_reflective_catches(text)
    write(name, text)

    # ---- LegacyPhoneSelector: scan BluetoothManager + isConnected catch
    name = 'com/shilapi/xcertplay/legacy/LegacyPhoneSelector.smali'
    text = load_current(work, name)
    old_scan = '''    .line 47
    .local v3, "appContext":Landroid/content/Context;
    const-string v0, "bluetooth"

    invoke-virtual {v3, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    instance-of v4, v0, Landroid/bluetooth/BluetoothManager;

    if-eqz v4, :cond_1a

    check-cast v0, Landroid/bluetooth/BluetoothManager;

    goto :goto_1b

    :cond_1a
    const/4 v0, 0x0

    :goto_1b
    if-eqz v0, :cond_205

    invoke-virtual {v0}, Landroid/bluetooth/BluetoothManager;->getAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-nez v0, :cond_29

    move-object/from16 v2, p2

    move-object/from16 v5, p3

    goto/16 :goto_209

    :cond_29
    move-object v4, v0'''
    new_scan = '''    .line 47
    .local v3, "appContext":Landroid/content/Context;
    invoke-static {v3}, ''' + CP + '''->getBluetoothAdapter(Landroid/content/Context;)Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    if-nez v0, :cond_29

    move-object/from16 v2, p2

    move-object/from16 v5, p3

    goto/16 :goto_209

    :cond_29
    move-object v4, v0'''
    text = one(text, old_scan, new_scan)
    text = fix_reflective_catches(text)
    write(name, text)

    # ---- LegacyVideoDecoder: MediaCodec.getName
    name = 'com/shilapi/xcertplay/media/LegacyVideoDecoder.smali'
    text = load_current(work, name)
    text = one(text,
        '    invoke-virtual {v6}, Landroid/media/MediaCodec;->getName()Ljava/lang/String;',
        f"    invoke-static {{v6}}, {CP}->getMediaCodecName(Landroid/media/MediaCodec;)Ljava/lang/String;")
    write(name, text)

    # ---- LegacyBluetoothAudioHandoff: two reflection catches
    name = 'com/shilapi/xcertplay/legacy/LegacyBluetoothAudioHandoff.smali'
    text = load_current(work, name)
    text = fix_reflective_catches(text)
    write(name, text)

    # ---- WifiP2pGroupManager: quitSafely (2) + getIndex (1)
    name = 'com/shilapi/xcertplay/network/WifiP2pGroupManager.smali'
    text = load_current(work, name)
    text = one(text,
        '    invoke-virtual {v1}, Landroid/os/HandlerThread;->quitSafely()Z',
        f"    invoke-static {{v1}}, {CP}->quitHandlerThreadSafely(Landroid/os/HandlerThread;)Z")
    text = one(text,
        '    invoke-virtual {v2}, Landroid/os/HandlerThread;->quitSafely()Z',
        f"    invoke-static {{v2}}, {CP}->quitHandlerThreadSafely(Landroid/os/HandlerThread;)Z")
    text = one(text,
        '    invoke-virtual {v0}, Ljava/net/NetworkInterface;->getIndex()I',
        f"    invoke-static {{v0}}, {CP}->getNetworkInterfaceIndex(Ljava/net/NetworkInterface;)I")
    write(name, text)

    # ---- ManualHotspotManager: getIndex + reflection catches
    name = 'com/shilapi/xcertplay/network/ManualHotspotManager.smali'
    text = load_current(work, name)
    text = one(text,
        '    invoke-virtual {p1}, Ljava/net/NetworkInterface;->getIndex()I',
        f"    invoke-static {{p1}}, {CP}->getNetworkInterfaceIndex(Ljava/net/NetworkInterface;)I")
    text = fix_reflective_catches(text)
    write(name, text)

    # ---- LocalOnlyHotspotManager: getIndex + getCause + reflection catches
    name = 'com/shilapi/xcertplay/network/LocalOnlyHotspotManager.smali'
    text = load_current(work, name)
    text = one(text,
        '    invoke-virtual {p1}, Ljava/net/NetworkInterface;->getIndex()I',
        f"    invoke-static {{p1}}, {CP}->getNetworkInterfaceIndex(Ljava/net/NetworkInterface;)I")
    text = fix_reflective_catches(text)
    write(name, text)
