package com.shilapi.xcertplay.patch;

import android.content.*;
import java.util.*;
import org.junit.Test;
import com.shilapi.xcertplay.legacy.LegacyPhoneSelector.*;
import static org.junit.Assert.*;

public class RememberedPhoneTest {
    private static final String FIRST="11:22:33:44:55:66",SECOND="22:33:44:55:66:77";
    /** Each instance loads a fresh process view of committed storage. */
    private static final class Prefs implements SharedPreferences {
        final Map<String,Object> disk,values; boolean fail; int commits;
        Prefs(Map<String,Object> disk){this.disk=disk;this.values=new HashMap<String,Object>(disk);}
        public Map<String,?> getAll(){return new HashMap<String,Object>(values);}
        public String getString(String k,String d){return values.containsKey(k)?(String)values.get(k):d;}
        public Set<String> getStringSet(String k,Set<String>d){return d;}
        public int getInt(String k,int d){return d;}
        public long getLong(String k,long d){return d;}
        public float getFloat(String k,float d){return d;}
        public boolean getBoolean(String k,boolean d){return values.containsKey(k)?(Boolean)values.get(k):d;}
        public boolean contains(String k){return values.containsKey(k);}
        public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l){}
        public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l){}
        public Editor edit(){return new Editor(){
            final Map<String,Object> staged=new HashMap<String,Object>(values);
            public Editor putString(String k,String v){staged.put(k,v);return this;}
            public Editor putStringSet(String k,Set<String>v){return this;}
            public Editor putInt(String k,int v){return this;}
            public Editor putLong(String k,long v){return this;}
            public Editor putFloat(String k,float v){return this;}
            public Editor putBoolean(String k,boolean v){staged.put(k,v);return this;}
            public Editor remove(String k){staged.remove(k);return this;}
            public Editor clear(){staged.clear();return this;}
            public boolean commit(){commits++;values.clear();values.putAll(staged);if(fail)return false;disk.clear();disk.putAll(staged);return true;}
            public void apply(){throw new AssertionError("phone selection must be committed before connecting");}
        };}
    }
    private static Context context(final Prefs prefs){return new Context(){
        public SharedPreferences getSharedPreferences(String name,int mode){assertEquals("legacy-settings",name);assertEquals(0,mode);return prefs;}
    };}
    private static Prefs empty(){return new Prefs(new HashMap<String,Object>());}
    @Test public void coldLaunchUsesCommittedPhoneAndName(){
        Prefs old=empty();assertTrue(RememberedPhone.remember(context(old),"112233445566","My iPhone"));
        Prefs restarted=new Prefs(old.disk);
        assertEquals(FIRST,RememberedPhone.address(context(restarted)));
        Selection selected=OemWireless.connected(context(restarted),FIRST,"My iPhone");
        assertEquals(FIRST,selected.getAddress());assertEquals("My iPhone",selected.getName());
        assertEquals(Reason.PREFERRED_CONNECTED,selected.getReason());assertEquals(1,restarted.commits);
    }
    @Test public void existingVersionPreferencesNeedNoReselection(){
        Prefs p=empty();p.values.put("phone","11:22:33:44:55:66");p.values.put("phoneName","Old iPhone");
        assertEquals(FIRST,OemWireless.connected(context(p),FIRST,"Old iPhone").getAddress());assertEquals(1,p.commits);
    }
    @Test public void otherConnectedPhoneDoesNotOverwriteSavedTarget(){
        Prefs p=empty();RememberedPhone.remember(context(p),FIRST,"First iPhone");
        Selection s=OemWireless.connected(context(p),SECOND,"Other iPhone");
        assertNull(s.getAddress());assertEquals(Reason.WAITING,s.getReason());assertEquals(FIRST,RememberedPhone.address(context(p)));
        assertEquals(1,p.commits);
    }
    @Test public void explicitChangeSurvivesNextLaunch(){
        Prefs p=empty();RememberedPhone.remember(context(p),FIRST,"First");
        assertTrue(RememberedPhone.remember(context(p),SECOND,"Second"));
        Prefs restart=new Prefs(p.disk);
        assertNull(OemWireless.connected(context(restart),FIRST,"First").getAddress());
        assertEquals(SECOND,OemWireless.connected(context(restart),SECOND,"Second").getAddress());
    }
    @Test public void missingOrInvalidPeerKeepsRecordDuringStartup(){
        Prefs p=empty();RememberedPhone.remember(context(p),FIRST,"First");
        for(String value:new String[]{null,"t3","00:00:00:00:00:00","02:00:00:00:00:00"}){
            assertNull(OemWireless.connected(context(p),value,"missing").getAddress());
            assertFalse(RememberedPhone.remember(context(p),value,"missing"));
            assertEquals(FIRST,RememberedPhone.address(context(p)));
        }assertEquals(1,p.commits);
    }
    @Test public void firstOemConnectedPhoneIsSavedBeforeSelectionReturns(){
        Prefs p=empty();Selection s=OemWireless.connected(context(p),FIRST,"First");
        assertEquals(Reason.CONNECTED_PHONE,s.getReason());assertEquals(FIRST,s.getAddress());
        assertEquals(FIRST,new Prefs(p.disk).getString("phone",null));assertEquals("First",p.disk.get("phoneName"));
    }
    @Test public void failedSaveDoesNotStartSession(){
        Prefs p=empty();p.fail=true;
        assertNull(OemWireless.connected(context(p),FIRST,"First").getAddress());assertTrue(p.disk.isEmpty());
    }
    @Test public void failedDiskWriteIsRetriedEvenWhenRamAlreadyContainsPhone(){
        Prefs p=empty();p.fail=true;
        assertNull(OemWireless.connected(context(p),FIRST,"First").getAddress());
        assertNull(OemWireless.connected(context(p),FIRST,"First").getAddress());assertTrue(p.disk.isEmpty());
        p.fail=false;assertEquals(FIRST,OemWireless.connected(context(p),FIRST,"First").getAddress());
        assertEquals(FIRST,new Prefs(p.disk).getString("phone",null));assertEquals(3,p.commits);
    }
    @Test public void selectingPhoneDoesNotChangeModeHotspotOrAutoPreference(){
        Prefs p=empty();p.values.put("autoConnect",false);p.values.put("wired",true);p.values.put("hotspotSsid","CarHotspot");
        RememberedPhone.remember(context(p),FIRST,"First");
        assertEquals(false,p.disk.get("autoConnect"));assertEquals(true,p.disk.get("wired"));assertEquals("CarHotspot",p.disk.get("hotspotSsid"));
    }
    @Test public void normalizedSavedMacMatchesAndMissingNameHasFallback(){
        Prefs p=empty();p.values.put("phone","112233445566");
        assertTrue(RememberedPhone.matches(context(p),FIRST));
        assertTrue(RememberedPhone.remember(context(p),FIRST,null));assertEquals("iPhone",p.disk.get("phoneName"));
    }
}
