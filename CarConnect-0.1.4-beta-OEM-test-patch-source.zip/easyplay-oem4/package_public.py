"""Package only authored patch source and docs; private build inputs stay local."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = '0.1.4-beta-OEM-test'
DOCS = ['README.md', 'USAGE.zh-CN.md', 'CHANGES.zh-CN.md', 'BUILD.zh-CN.md', 'CREDITS.md']
OUT = ROOT / 'artifacts' / ('CarConnect-' + VERSION)
OUT.mkdir(parents=True, exist_ok=True)
for name in DOCS:
    shutil.copyfile(ROOT / 'easyplay-oem4' / name, OUT / name)
shutil.copyfile(ROOT / 'LICENSE', OUT / 'LICENSE')

source = ROOT / 'artifacts' / ('CarConnect-' + VERSION + '-patch-source.zip')
files = {}
for directory in ['easyplay-touchfix', 'easyplay-oem4']:
    base = ROOT / directory
    for folder in ['src', 'stubs', 'test', 'test-stubs', 'tools']:
        for path in (base / folder).rglob('*.java'):
            files[path.relative_to(ROOT).as_posix()] = path
    for path in base.iterdir():
        if path.is_file() and (path.suffix in {'.py', '.ps1'} or path.name in DOCS):
            files[path.relative_to(ROOT).as_posix()] = path
for name in DOCS + ['LICENSE']:
    files[name] = OUT / name
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
    for name, path in sorted(files.items()):
        assert not any(part in {'.private', 'build', '__pycache__'} for part in Path(name).parts)
        assert path.suffix not in {'.apk', '.dex', '.smali', '.jks', '.log', '.txt', '.so'}
        archive.write(path, name)
with zipfile.ZipFile(source) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(files)
digest = hashlib.sha256(source.read_bytes()).hexdigest()
source.with_suffix('.zip.sha256').write_text(f'{digest}  {source.name}\n', encoding='ascii')
apk = ROOT / 'artifacts' / ('CarConnect-' + VERSION + '-Android4.2.apk')
metadata = {
    'release': 'https://github.com/beidouxiaonan/CarConnect/releases/tag/v0.1.4-beta-oem-test',
    'versionCode': 41, 'minSdk': 17, 'jvmTests': 58,
    'hardwareAutoRestoreTest': 'pending',
    'previousWirelessConnection': 'user reported working on their vehicle',
    'assets': {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
               for path in [apk, apk.with_suffix('.apk.sha256'), source, source.with_suffix('.zip.sha256')]},
}
(OUT / 'publication.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(f'Public source: {source.name}; {len(files)} allowed files; SHA256={digest}')
print(f'Public docs: {OUT}')
