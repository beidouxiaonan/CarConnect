package com.shilapi.xcertplay.legacy;
/** JVM representation of the APK's value class; never packaged. */
public final class LegacyPhoneSelector {
    public enum Reason { PREFERRED_CONNECTED, EVENT_PHONE, CONNECTED_PHONE, PREFERRED_BONDED, AMBIGUOUS, WAITING }
    public static final class Selection {
        private final String address, name, explanation;
        private final Reason reason;
        public Selection(String address,String name,String explanation,Reason reason) {
            this.address=address;this.name=name;this.explanation=explanation;this.reason=reason;
        }
        public String getAddress(){return address;}
        public String getName(){return name;}
        public String getExplanation(){return explanation;}
        public Reason getReason(){return reason;}
    }
}
