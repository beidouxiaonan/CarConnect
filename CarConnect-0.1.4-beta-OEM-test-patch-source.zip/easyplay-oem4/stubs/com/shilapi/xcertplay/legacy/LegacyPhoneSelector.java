package com.shilapi.xcertplay.legacy;

/** Compile-only signatures verified against the supplied APK. Never packaged. */
public final class LegacyPhoneSelector {
    public enum Reason { PREFERRED_CONNECTED, EVENT_PHONE, CONNECTED_PHONE, PREFERRED_BONDED, AMBIGUOUS, WAITING }
    public static final class Selection {
        public Selection(String address, String name, String explanation, Reason reason) { throw new AssertionError(); }
    }
}
