"""Join the OEM transport to the launch/service selector, preserving standard Bluetooth."""
import re

P = 'Lcom/shilapi/xcertplay/patch/'
A = 'Lcom/shilapi/xcertplay/legacy/LegacyActivity;'

def patch_wireless(work, write, edit_method, one):
    def current(name): return (work/'modified'/name).read_text(encoding='utf-8')
    name = 'com/shilapi/xcertplay/legacy/LegacyPhoneSelector.smali'
    def scan(m):
        marker = '    .line 46'
        return one(m, marker, f'''    invoke-static {{v2}}, {P}EnhancementPrefs;->getOemBluetooth(Landroid/content/Context;)Z
    move-result v0
    if-eqz v0, :patch_standard_phone_scan
    invoke-static {{v2}}, {P}OemWireless;->scan(Landroid/content/Context;)Lcom/shilapi/xcertplay/legacy/LegacyPhoneSelector$Selection;
    move-result-object v0
    return-object v0
    :patch_standard_phone_scan
{marker}''')
    write(name, edit_method(current(name), 'scan(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Lcom/shilapi/xcertplay/legacy/LegacyPhoneSelector$Selection;', scan))

    name = 'com/shilapi/xcertplay/legacy/LegacySessionService.smali'
    text = current(name)
    def ready(m):
        marker = '    .line 53'
        m = one(m, marker, f'''    invoke-static {{p0}}, {P}EnhancementPrefs;->getOemBluetooth(Landroid/content/Context;)Z
    move-result v0
    if-nez v0, :patch_check_hotspot
{marker}''')
        return one(m, '    .line 54', '    :patch_check_hotspot\n    .line 54')
    text = edit_method(text, 'wirelessRadiosReady$lambda$3(Lcom/shilapi/xcertplay/legacy/LegacySessionService;)Z', ready)
    def prepare(m):
        marker = '    invoke-static/range {v1 .. v8}, Lcom/shilapi/xcertplay/legacy/LegacyBluetoothController;->ensureReady$default(Lcom/shilapi/xcertplay/legacy/LegacyBluetoothController;Landroid/content/Context;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;JILjava/lang/Object;)V'
        return one(m, marker, f'''    invoke-static {{v2}}, {P}EnhancementPrefs;->getOemBluetooth(Landroid/content/Context;)Z
    move-result v7
    if-nez v7, :patch_prepare_hotspot
    const/16 v7, 0x8
{marker}
    :patch_prepare_hotspot''')
    text = edit_method(text, 'prepareWirelessRadios$lambda$2(Lcom/shilapi/xcertplay/legacy/LegacySessionService;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)Lcom/shilapi/xcertplay/legacy/LegacyHotspotController$Configuration;', prepare)
    write(name, text)

    name = 'com/shilapi/xcertplay/legacy/LegacyConnectionScreen.smali'
    owner = 'Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;'
    def render(m):
        before, after = m.rsplit('    return-void', 1)
        return before + f'''    iget-object v10, v0, {owner}->wired:Landroid/widget/CheckBox;
    invoke-virtual {{v10}}, Landroid/widget/CheckBox;->isChecked()Z
    move-result v10
    if-nez v10, :patch_main_labels_done
    invoke-virtual {{v0}}, Landroid/view/View;->getContext()Landroid/content/Context;
    move-result-object v10
    iget-object v11, v0, {owner}->bluetoothName:Landroid/widget/TextView;
    iget-object v12, v0, {owner}->bluetoothHint:Landroid/widget/TextView;
    invoke-static {{v10, v11, v12}}, {P}OemWireless;->mainLabels(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V
    :patch_main_labels_done
    return-void''' + after
    write(name, edit_method(current(name), 'render(Lcom/shilapi/xcertplay/legacy/LegacySessionService;Ljava/lang/String;)V', render))

    name = 'com/shilapi/xcertplay/legacy/LegacyActivity.smali'
    text = current(name)
    def choose(m):
        return one(m, '    .line 266', f'''    invoke-static {{p0}}, {P}OemWireless;->choosePhone(Landroid/app/Activity;)Z
    move-result v0
    if-eqz v0, :patch_standard_phone_chooser
    return-void
    :patch_standard_phone_chooser
    .line 266''')
    text = edit_method(text, 'choosePhone()V', choose)
    def startup(m):
        # Respect the user's saved autoConnect checkbox instead of forcing true on every cold launch.
        pattern = r'    if-nez p1, :cond_84\n.*?    \.line 93\n'
        matches = list(re.finditer(pattern, m, re.S)); assert len(matches) == 1
        m = m[:matches[0].start()] + '    .line 93\n' + m[matches[0].end():]
        m = one(m, '    :cond_84\n', '')
        return m.replace('\\u9009\\u62e9\\u5df2\\u914d\\u5bf9\\u7684 iPhone', '\\u9009\\u62e9 iPhone\\uff08\\u9996\\u6b21\\u8bbe\\u7f6e\\uff09')
    text = edit_method(text, 'onCreate(Landroid/os/Bundle;)V', startup)
    text += f'''
.method public final patchUseRememberedPhone(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7
    iput-object p1, p0, {A}->phoneAddress:Ljava/lang/String;
    iput-object p2, p0, {A}->phoneName:Ljava/lang/String;
    iget-object v0, p0, {A}->phoneButton:Landroid/widget/Button;
    invoke-virtual {{v0, p2}}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V
    iget-object v0, p0, {A}->automatic:Landroid/widget/CheckBox;
    invoke-virtual {{v0}}, Landroid/widget/CheckBox;->isChecked()Z
    move-result v1
    const/4 v2, 0x1
    if-nez v1, :patch_restart_auto
    invoke-virtual {{v0, v2}}, Landroid/widget/CheckBox;->setChecked(Z)V
    return-void
    :patch_restart_auto
    const/4 v1, 0x0
    const/4 v3, 0x0
    invoke-static {{p0, v1, v2, v3}}, {A}->startAutomaticConnection$default({A}ZILjava/lang/Object;)V
    return-void
.end method
'''
    write(name, text)
