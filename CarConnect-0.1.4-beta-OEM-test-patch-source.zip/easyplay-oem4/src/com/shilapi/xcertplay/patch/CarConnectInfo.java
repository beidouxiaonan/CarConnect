package com.shilapi.xcertplay.patch;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.widget.Toast;
public final class CarConnectInfo {
    public static final String HOME="https://github.com/beidouxiaonan";
    public static final String VERSION="Carplay-connect-0.1.4-beta-OEM-test";
    public static void open(Activity activity) {
        try { activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(HOME))); }
        catch(ActivityNotFoundException error) { Toast.makeText(activity,"GitHub 主页："+HOME,Toast.LENGTH_LONG).show(); }
    }
    public static void about(final Activity activity) {
        if(activity.isFinishing()||activity.isDestroyed())return;
        new AlertDialog.Builder(activity).setTitle("关于 CarConnect")
            .setMessage(VERSION+"\n\nAndroid 4.2~4.4 车机测试版。保留视频和触摸优化、30/60fps 设置及独立音量。首次记住原车已连接的 iPhone，启动优先恢复，不必每次重新选择。\n\n兼容已核对的 BC03 1.7.9 / 1.3.6 / gocsdk，无需 Root。用户已反馈其车机无线连接可用，本次自动恢复改动尚待车机验证。\n\n基于用户提供的 EasyPlay 0.2.7(36) 修改，参考 DiPlay / xcertplay。保留原许可证及第三方声明。\n\n项目主页："+HOME)
            .setPositiveButton("GitHub 主页",new DialogInterface.OnClickListener(){public void onClick(DialogInterface dialog,int which){open(activity);}})
            .setNegativeButton("关闭",null).show();
    }
}
