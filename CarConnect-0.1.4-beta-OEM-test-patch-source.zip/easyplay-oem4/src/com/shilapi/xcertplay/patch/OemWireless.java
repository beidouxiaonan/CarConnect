package com.shilapi.xcertplay.patch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.widget.TextView;
import com.shilapi.xcertplay.legacy.LegacyActivity;
import com.shilapi.xcertplay.legacy.LegacyPhoneSelector.Selection;
import com.shilapi.xcertplay.legacy.LegacyPhoneSelector.Reason;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicBoolean;

/** OEM selection uses the original service's worker, generation checks and retry schedule. */
public final class OemWireless {
    private static final AtomicBoolean selecting = new AtomicBoolean();
    private OemWireless() {}
    public static Selection scan(Context context) {
        try {
            Bc03Access bc = new Bc03Access(context);
            Bc03Access.Snapshot phone;
            try { phone = bc.snapshot(); } finally { bc.close(); }
            return connected(context, phone.phone, phone.name);
        } catch (Exception error) {
            return waiting("等待原车蓝牙连接已记住的 iPhone。" + error.getMessage());
        }
    }
    static Selection connected(Context context, String address, String name) {
        if (!RememberedPhone.matches(context, address))
            return waiting("原车当前连接了另一台手机，或地址无效；请连接已记住的 iPhone，或点击手机按钮更换。记录已保留。");
        boolean known = RememberedPhone.address(context) != null;
        if (!RememberedPhone.acceptConnected(context, address, name))
            return waiting("手机选择未能保存，或选择已变化；稍后重试。记录未被清除。");
        return new Selection(OemProtocol.normalizeMac(address), name, "正在恢复已记住的原车 iPhone…",
            known ? Reason.PREFERRED_CONNECTED : Reason.CONNECTED_PHONE);
    }
    private static Selection waiting(String text) { return new Selection(null, null, text, Reason.WAITING); }
    public static void mainLabels(Context context, TextView title, TextView hint) {
        if (!EnhancementPrefs.getOemBluetooth(context)) return;
        title.setText("原车蓝牙 · " + (RememberedPhone.address(context) == null ? "首次连接 iPhone" : RememberedPhone.name(RememberedPhone.settings(context))));
        hint.setText(RememberedPhone.address(context) == null ? "在原车蓝牙页面配对并连接，再选择手机记住"
            : "已保存手机选择；启动后自动恢复，换手机时再选择");
    }

    /** Replaces the standard-stack chooser only when the OEM option is enabled. */
    public static boolean choosePhone(final Activity activity) {
        return choosePhone(activity, null);
    }
    public static boolean choosePhone(final Activity activity, TextView savedLabel) {
        if (!EnhancementPrefs.getOemBluetooth(activity)) return false;
        if (!selecting.compareAndSet(false, true)) {
            Toast.makeText(activity, "正在读取原车已连接手机，请稍候", Toast.LENGTH_SHORT).show();
            return true;
        }
        final WeakReference<Activity> screen = new WeakReference<Activity>(activity);
        final WeakReference<TextView> saved = new WeakReference<TextView>(savedLabel);
        final Context app = activity.getApplicationContext();
        final Handler main = new Handler(Looper.getMainLooper());
        final AtomicBoolean delivered = new AtomicBoolean();
        final Runnable timeout = new Runnable() { public void run() {
            if (!delivered.compareAndSet(false, true)) return;
            Activity a = screen.get();
            if (alive(a)) Toast.makeText(a, "原车蓝牙读取超时，请稍后再试；原有选择已保留", Toast.LENGTH_LONG).show();
        }};
        main.postDelayed(timeout, 8000);
        Toast.makeText(activity, "正在读取原车已连接的 iPhone…", Toast.LENGTH_SHORT).show();
        Thread worker = new Thread(new Runnable() { public void run() {
            Bc03Access.Snapshot result = null; String failure = null;
            try {
                Bc03Access bc = new Bc03Access(app);
                try { result = bc.snapshot(); } finally { bc.close(); }
            } catch (Exception error) { failure = error.getMessage(); }
            final Bc03Access.Snapshot phone = result; final String message = failure;
            selecting.set(false);
            main.post(new Runnable() { public void run() {
                if (!delivered.compareAndSet(false, true)) return;
                main.removeCallbacks(timeout);
                final Activity a = screen.get(); if (!alive(a)) return;
                if (phone == null) {
                    new AlertDialog.Builder(a).setTitle("先连接原车蓝牙")
                        .setMessage("在车机原来的蓝牙页面连接已配对的 iPhone，再回来选择一次。\n\n" + message)
                        .setPositiveButton("知道了", null).show(); return;
                }
                new AlertDialog.Builder(a).setTitle("记住这台 iPhone")
                    .setMessage((phone.name == null ? "iPhone" : phone.name) + "\n\n保存后下次启动自动使用它。更换手机时再点这个入口。")
                    .setPositiveButton("记住并自动连接", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) { save(screen, saved, app, main, phone); }
                    }).setNegativeButton("取消", null).show();
            }});
        }}, "carconnect-select-oem-phone");
        worker.setDaemon(true); worker.start(); return true;
    }
    private static void save(final WeakReference<Activity> screen, final WeakReference<TextView> saved, final Context app,
            final Handler main, final Bc03Access.Snapshot phone) {
        Thread worker = new Thread(new Runnable() { public void run() {
            String failure = null;
            try {
                Bc03Access bc = new Bc03Access(app);
                try {
                    if (!phone.phone.equals(bc.snapshot().phone)) throw new IOException("原车连接手机已变化，请重新选择");
                } finally { bc.close(); }
                if (!RememberedPhone.remember(app, phone.phone, phone.name)) throw new IOException("手机选择保存失败，请重试");
            } catch (Exception error) { failure = error.getMessage(); }
            final String message = failure;
            main.post(new Runnable() { public void run() {
                Activity a = screen.get(); if (!alive(a)) return;
                if (message != null) { Toast.makeText(a, message, Toast.LENGTH_LONG).show(); return; }
                if (a instanceof LegacyActivity) ((LegacyActivity)a).patchUseRememberedPhone(phone.phone,
                    phone.name == null || phone.name.trim().length() == 0 ? "iPhone" : phone.name);
                TextView label = saved.get(); if (label != null) label.setText(RememberedPhone.summary(app));
                Toast.makeText(a, "已记住 iPhone，下次无需重新选择", Toast.LENGTH_LONG).show();
            }});
        }}, "carconnect-save-oem-phone");
        worker.setDaemon(true); worker.start();
    }
    private static boolean alive(Activity activity) { return activity != null && !activity.isFinishing() && !activity.isDestroyed(); }
}
