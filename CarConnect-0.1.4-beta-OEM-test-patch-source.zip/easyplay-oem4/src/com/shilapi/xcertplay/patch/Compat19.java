package com.shilapi.xcertplay.patch;

import java.net.NetworkInterface;

/**
 * High-version (API 19) implementations. This class is loaded only after
 * Compat17 confirms the runtime is at least API 19.
 */
public final class Compat19 {
    private Compat19() {}

    public static int getNetworkInterfaceIndex(NetworkInterface iface) {
        return iface.getIndex();
    }
}
