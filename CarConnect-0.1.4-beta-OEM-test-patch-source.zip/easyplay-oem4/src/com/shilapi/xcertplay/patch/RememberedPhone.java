package com.shilapi.xcertplay.patch;

import android.content.Context;
import android.content.SharedPreferences;

/** Uses the original preference file so covering an existing install retains its selection. */
public final class RememberedPhone {
    private RememberedPhone() {}
    static SharedPreferences settings(Context context) {
        return context.getSharedPreferences("legacy-settings", Context.MODE_PRIVATE);
    }
    public static synchronized String address(Context context) { return address(settings(context)); }
    static String address(SharedPreferences prefs) {
        return OemProtocol.normalizeMac(prefs.getString("phone", null));
    }
    static String name(SharedPreferences prefs) {
        String value = prefs.getString("phoneName", "iPhone");
        if (value == null || value.trim().length() == 0) return "iPhone";
        value = value.trim();
        return value.length() > 128 ? value.substring(0, 128) : value;
    }
    public static synchronized String summary(Context context) {
        SharedPreferences prefs = settings(context);
        return address(prefs) == null ? "尚未记住 iPhone。首次选择一次即可。"
            : "已记住：" + name(prefs) + "。下次启动优先恢复这台手机，无需再次选择。";
    }
    public static synchronized boolean remember(Context context, String phone, String name) {
        return remember(settings(context), phone, name);
    }
    static boolean remember(SharedPreferences prefs, String phone, String name) {
        phone = OemProtocol.normalizeMac(phone);
        if (phone == null) return false;
        if (name == null || name.trim().length() == 0) name = "iPhone";
        name = name.trim();
        if (name.length() > 128) name = name.substring(0, 128);
        // Called on a worker: durable completion before starting a new connection.
        // Retry commit even for identical in-memory values: Android may update RAM after a disk failure.
        return prefs.edit().putString("phone", phone).putString("phoneName", name).commit();
    }
    static boolean matches(SharedPreferences prefs, String current) {
        String saved = address(prefs), normalized = OemProtocol.normalizeMac(current);
        return normalized != null && (saved == null || saved.equals(normalized));
    }
    public static synchronized boolean matches(Context context, String current) {
        return matches(settings(context), current);
    }
    static synchronized boolean acceptConnected(Context context, String current, String name) {
        SharedPreferences prefs = settings(context);
        return matches(prefs, current) && remember(prefs, current, name);
    }
}
