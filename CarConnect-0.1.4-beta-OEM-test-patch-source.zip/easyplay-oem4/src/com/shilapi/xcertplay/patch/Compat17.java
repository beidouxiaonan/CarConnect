package com.shilapi.xcertplay.patch;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.media.MediaCodec;
import android.os.Build;
import android.os.HandlerThread;
import java.net.NetworkInterface;

/**
 * Compatibility entry points. Every method is safe to load and verify on
 * Android 4.2 (API 17): the high-version types are referenced only from the
 * dedicated Compat18 / Compat19 classes, which are entered solely after the
 * runtime version check passes.
 */
public final class Compat17 {
    private Compat17() {}

    public static BluetoothAdapter getBluetoothAdapter(Context context) {
        if (Build.VERSION.SDK_INT >= 18) {
            return Compat18.getBluetoothAdapter(context);
        }
        return BluetoothAdapter.getDefaultAdapter();
    }

    public static String getMediaCodecName(MediaCodec codec) {
        if (Build.VERSION.SDK_INT >= 18) {
            return Compat18.getMediaCodecName(codec);
        }
        return "MediaCodec";
    }

    public static boolean quitHandlerThreadSafely(HandlerThread thread) {
        if (Build.VERSION.SDK_INT >= 18) {
            return Compat18.quitHandlerThreadSafely(thread);
        }
        thread.quit();
        return true;
    }

    public static int getNetworkInterfaceIndex(NetworkInterface iface) {
        if (Build.VERSION.SDK_INT >= 19) {
            return Compat19.getNetworkInterfaceIndex(iface);
        }
        return -1;
    }
}
