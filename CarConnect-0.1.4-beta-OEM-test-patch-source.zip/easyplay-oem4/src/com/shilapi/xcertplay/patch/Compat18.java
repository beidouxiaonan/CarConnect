package com.shilapi.xcertplay.patch;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.media.MediaCodec;
import android.os.HandlerThread;

/**
 * High-version (API 18) implementations. This class is loaded only after
 * Compat17 confirms the runtime is at least API 18.
 */
public final class Compat18 {
    private Compat18() {}

    public static BluetoothAdapter getBluetoothAdapter(Context context) {
        Object service = context.getSystemService("bluetooth");
        if (service instanceof BluetoothManager) {
            return ((BluetoothManager) service).getAdapter();
        }
        return null;
    }

    public static String getMediaCodecName(MediaCodec codec) {
        return codec.getName();
    }

    public static boolean quitHandlerThreadSafely(HandlerThread thread) {
        return thread.quitSafely();
    }
}
