param(
    [string]$JdkPath = '',
    [string]$PythonPath = 'D:\Program Files\Python3.13.13\python.exe',
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath("$PSScriptRoot/..")
if (-not $JdkPath) { $JdkPath = "$root/.tooling/jdk25" }
$patchRoot = "$root/easyplay-oem4"
$work = "$root/.private/apk-analysis/easyplay/oem4"
$bt = "$root/.tooling/build-tools/android-15"
$jadx = "$root/.tooling/jadx/lib/jadx-1.5.6-all.jar"
$android = "$root/.tooling/platform/android-4.4.2/android.jar"
$java = "$JdkPath/bin/java.exe"
$javac = "$JdkPath/bin/javac.exe"
$jar = "$JdkPath/bin/jar.exe"

# Run a native command, surfacing stderr as plain text so the Stop preference
# does not turn javac/java notes into terminating NativeCommandError records.
function Run([string]$stage, [scriptblock]$Block) {
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = & $Block 2>&1
        $code = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $prev
    }
    foreach ($line in $out) {
        if ($line -is [System.Management.Automation.ErrorRecord]) { Write-Host $line.Exception.Message }
        else { Write-Host $line }
    }
    if ($code -ne 0) { throw "$stage failed: $code" }
}

Push-Location $root
try {
    New-Item -ItemType Directory -Force "$patchRoot/build/stubs", "$patchRoot/build/classes", "$patchRoot/build/tests", "$patchRoot/build/test-stubs", "$patchRoot/build/dex", "$root/artifacts" | Out-Null
    $stubSources = @(Get-ChildItem "$patchRoot/stubs" -Recurse -Filter '*.java' | ForEach-Object FullName)
    $patchSources = @(Get-ChildItem "$patchRoot/src" -Recurse -Filter '*.java' | ForEach-Object FullName)
    Run 'Compile stubs' { & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $android -d "$patchRoot/build/stubs" @stubSources }
    Run 'Compile helpers' { & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp "$patchRoot/build/stubs;$android" -d "$patchRoot/build/classes" @patchSources }
    if (-not $SkipTests) {
        $fakes = @(Get-ChildItem "$patchRoot/test-stubs" -Recurse -Filter '*.java' | ForEach-Object FullName)
        Run 'Compile test fakes' { & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $android -d "$patchRoot/build/test-stubs" @fakes }
        $testCp = "$patchRoot/build/test-stubs;$patchRoot/build/stubs;$patchRoot/build/classes;$root/.tooling/test-libs/junit.jar;$root/.tooling/test-libs/hamcrest.jar;$android"
        $tests = @(Get-ChildItem "$patchRoot/test" -Recurse -Filter '*.java' | ForEach-Object FullName)
        Run 'Compile tests' { & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $testCp -d "$patchRoot/build/tests" @tests }
        Run 'Touch/audio/preferences/wireless tests' { & $java -cp "$testCp;$patchRoot/build/tests" org.junit.runner.JUnitCore com.shilapi.xcertplay.patch.TouchDispatcherTest com.shilapi.xcertplay.patch.AudioLevelsTest com.shilapi.xcertplay.patch.EnhancementPrefsTest com.shilapi.xcertplay.patch.VideoProgressTest com.shilapi.xcertplay.patch.Bc03SchemaTest com.shilapi.xcertplay.patch.VideoOutputTest com.shilapi.xcertplay.patch.OemProtocolTest com.shilapi.xcertplay.patch.RememberedPhoneTest }
    }
    Run 'Stub classpath jar' { & $jar --create --file "$patchRoot/build/stubs.jar" -C "$patchRoot/build/stubs" . }
    Run 'Helper jar' { & $jar --create --file "$patchRoot/build/patch.jar" -C "$patchRoot/build/classes" . }
    # Fresh, idempotent disassembly/patch: drop prior outputs so a re-run does
    # not apply the smali patches twice.
    foreach ($relative in @('original', 'modified')) {
        $targetPath = [IO.Path]::GetFullPath([IO.Path]::Combine($work, $relative))
        $expectedParent = [IO.Path]::GetFullPath($work)
        if ([IO.Path]::GetDirectoryName($targetPath) -ne $expectedParent -or
            -not $targetPath.StartsWith($root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe disassembly cleanup path: $targetPath"
        }
        Remove-Item -LiteralPath $targetPath -Recurse -Force -ErrorAction SilentlyContinue
    }
    Run 'D8 API 17' { & $java -cp "$bt/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 17 --lib $android --classpath "$patchRoot/build/stubs.jar" --output "$patchRoot/build/dex" "$patchRoot/build/patch.jar" }
    Run 'Disassemble original' { & $java -cp $jadx "$patchRoot/tools/DexTool.java" dis "$work/../classes3.dex" "$work/original" 'Lcom/shilapi/xcertplay/orchestration/CarPlayController;' 'Lcom/shilapi/xcertplay/airplay/AirPlaySession;' 'Lcom/shilapi/xcertplay/legacy/LegacyActivity;' 'Lcom/shilapi/xcertplay/legacy/LegacySessionService;' 'Lcom/shilapi/xcertplay/legacy/LegacyPhoneSelector;' 'Lcom/shilapi/xcertplay/legacy/LegacyBluetoothAudioHandoff;' 'Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;' 'Lcom/shilapi/xcertplay/media/LegacyAudioFocus;' 'Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;' 'Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;' 'Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;' 'Lcom/shilapi/xcertplay/legacy/EasyPlayVersionSettings;' 'Lcom/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream;' 'Lcom/shilapi/xcertplay/network/WifiP2pGroupManager;' 'Lcom/shilapi/xcertplay/network/ManualHotspotManager;' 'Lcom/shilapi/xcertplay/network/LocalOnlyHotspotManager;' }
    Run 'Patch smali' { & $PythonPath "$patchRoot/patch_apk.py" smali }
    Run 'Assemble modified classes' { & $java -cp $jadx "$patchRoot/tools/DexTool.java" asm "$work/modified" "$work/controller.dex" }
    Run 'Merge helpers' { & $java -Xmx1g -cp $jadx "$patchRoot/tools/DexTool.java" merge "$work/patched-classes3.dex" "$work/../classes3.dex" "$work/controller.dex" "$patchRoot/build/dex/classes.dex" }
    $auditArgs=@("$work/../classes3.dex", "$work/patched-classes3.dex", "$work/../patch/patched-classes3.dex")
    if(Test-Path -LiteralPath "$work/../stability3/patched-classes3.dex") { $auditArgs+= "$work/../stability3/patched-classes3.dex" }
    else { Write-Output 'Published 0.1.0 media baseline absent; optional comparison skipped' }
    Run 'Original code and stable touch audit' { & $java -Xmx1g -cp $jadx "$patchRoot/tools/DexAudit.java" @auditArgs }
    Run 'OEM query and callback schema' { & $PythonPath "$patchRoot/verify_vendor_schema.py" }
    Run 'Repack APK' { & $PythonPath "$patchRoot/patch_apk.py" repack }
    Run 'Align APK' { & "$bt/zipalign.exe" -f 4 "$work/unsigned.apk" "$work/aligned.apk" }
    $apk = "$root/artifacts/CarConnect-0.1.4-beta-OEM-test-Android4.2.apk"
    Run 'Sign APK' { & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" sign --ks "$root/.private/kitkat-probe-debug.jks" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --min-sdk-version 17 --v1-signing-enabled true --v2-signing-enabled true --v4-signing-enabled false --out $apk "$work/aligned.apk" }
    Run 'API 17 signature verification' { & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" verify --verbose --min-sdk-version 17 $apk }
    Run 'Alignment verification' { & "$bt/zipalign.exe" -c 4 $apk }
    Run 'APK payload verification' { & $PythonPath "$patchRoot/verify_apk.py" }
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $manifest = & "$bt/aapt.exe" dump xmltree $apk AndroidManifest.xml 2>&1
        $mcode = $LASTEXITCODE
    } finally {
        $ErrorActionPreference = $prev
    }
    if ($mcode -ne 0) { throw 'Manifest verification failed' }
    $manifest | Set-Content "$patchRoot/build/manifest.txt" -Encoding utf8
    Write-Output "CarConnect APK: $apk"
} finally { Pop-Location }
