package com.shilapi.xcertplay.patch;
import java.io.IOException;
/** A disconnect request is not success: only a settled OEM status allows VF. */
public final class SppRelease {
    static final long WAIT=5000000000L, SETTLE=300000000L, COOLDOWN=45000000000L;
    public interface Port { boolean connected() throws Exception; void disconnect() throws Exception; }
    public interface Monitor { void check() throws Exception; void log(String value); }
    public interface Time { long now(); void pause() throws Exception; }
    private boolean attempted; private long lastAttempt;
    public synchronized boolean ensureFree(boolean enabled,boolean owned,Port port,Monitor monitor,Time time) throws Exception {
        monitor.check();
        if(owned)throw new IOException("CarConnect 自己的数据通道正在使用，跳过 SPP 清理");
        if(!port.connected()){monitor.log("C1：未发现原车 SPP 占用，不发送断开请求");return false;}
        if(!enabled)throw new IOException("原车已有 SPP 连接；自动清理开关未开启，请先关闭其他投屏连接或开启清理");
        long elapsed=time.now()-lastAttempt;
        if(attempted&&elapsed>=0&&elapsed<COOLDOWN)
            throw new IOException("SPP 清理冷却中，约 "+((COOLDOWN-elapsed+999999999L)/1000000000L)+" 秒后再试；未发送 VF");
        monitor.check();
        if(!port.connected()){monitor.log("C1：原车 SPP 已自行释放，不发送断开请求");return false;}
        monitor.check();
        attempted=true;lastAttempt=time.now();
        monitor.log("C1：检测到原车 SPP 占用，按已开启的开关请求释放");
        port.disconnect();
        monitor.log("C2：原车 SppDisConnect 请求已返回，等待状态释放；不等于清理成功");
        long started=time.now(),clearSince=0;boolean clearing=false;
        while(true) {
            monitor.check();
            long now=time.now();boolean connected=port.connected();
            monitor.check();
            if(connected)clearing=false;
            else if(!clearing){clearing=true;clearSince=now;}
            if(clearing&&now-clearSince>=SETTLE){
                monitor.log("C3：原车 SPP 未连接状态稳定 300ms，清理完成");return true;
            }
            if(now-started>=WAIT)throw new IOException("SPP 清理超时：原车仍占用或状态未稳定；停止本次连接，未发送 VF");
            time.pause();
        }
    }
}
