"""Explicit public allowlist: authored packaging scripts and documentation only."""
from pathlib import Path
import hashlib
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'artifacts' / 'CarConnect-0.1.4-SD8227-V1-test'
OUT.mkdir(parents=True, exist_ok=True)
names = ['profile.py', 'build.ps1', 'collect-install.ps1', 'package_public.py',
         'README.md', 'VERIFICATION.zh-CN.md']
files = {f'easyplay-sd8227/{name}': ROOT / 'easyplay-sd8227' / name for name in names}
for name in ['README.md', 'VERIFICATION.zh-CN.md']:
    shutil.copyfile(ROOT / 'easyplay-sd8227' / name, OUT / name)
    files[name] = OUT / name
shutil.copyfile(ROOT / 'LICENSE', OUT / 'LICENSE')
shutil.copyfile(ROOT / 'easyplay-oem4/CREDITS.md', OUT / 'CREDITS.md')
for name in ['LICENSE', 'CREDITS.md']:
    files[name] = OUT / name
source = ROOT / 'artifacts/CarConnect-0.1.4-SD8227-V1-test-patch-source.zip'
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED, allowZip64=False) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
with zipfile.ZipFile(source) as archive:
    if archive.testzip() is not None or set(archive.namelist()) != set(files):
        raise ValueError('Public source allowlist/CRC mismatch')
sha = hashlib.sha256(source.read_bytes()).hexdigest()
source.with_suffix('.zip.sha256').write_text(sha + '  ' + source.name + '\n', encoding='ascii')
print(f'Public source: {len(files)} allowed files, SHA256={sha}')
