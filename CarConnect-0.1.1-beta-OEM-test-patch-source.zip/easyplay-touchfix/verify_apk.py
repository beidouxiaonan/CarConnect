from pathlib import Path
import hashlib
import struct
import zipfile

ROOT = Path(__file__).resolve().parent.parent
original = ROOT / '.private/apk-analysis/easyplay/input.apk'
patched = ROOT / 'artifacts/EasyPlay-0.2.7-touchfix1-Android4.4.apk'
expected = ROOT / '.private/apk-analysis/easyplay/patch/patched-classes3.dex'

def signature(name):
    upper = name.upper()
    return upper.startswith('META-INF/') and (upper.endswith(('.RSA', '.DSA', '.EC', '.SF')) or upper == 'META-INF/MANIFEST.MF')

with zipfile.ZipFile(original) as before, zipfile.ZipFile(patched) as after:
    old = {n for n in before.namelist() if not signature(n)}
    new = {n for n in after.namelist() if not signature(n)}
    assert old == new, (old - new, new - old)
    assert after.testzip() is None
    changed = [n for n in sorted(old) if before.read(n) != after.read(n)]
    assert changed == ['classes3.dex'], changed
    assert after.read('classes3.dex') == expected.read_bytes()
    dex = after.read('classes3.dex')
    assert dex[:8] == b'dex\n035\0', dex[:8]
    assert hashlib.sha1(dex[32:]).digest() == dex[12:32]
    assert struct.unpack_from('<I', dex, 88)[0] < 65536
    assert struct.unpack_from('<I', dex, 80)[0] < 65536
    assert struct.unpack_from('<I', dex, 64)[0] < 65536
    print('APK payload audit PASS: classes3.dex is the only changed non-signature entry')
    print(f'Preserved {len(old)-1} payload entries; AndroidManifest/resources/assets/all native libraries/classes1/classes2 identical')
    print(f'DEX 035, method refs={struct.unpack_from("<I", dex, 88)[0]}, field refs={struct.unpack_from("<I", dex, 80)[0]}')
    print(f'Original APK SHA256: {hashlib.sha256(original.read_bytes()).hexdigest()}')
    digest = hashlib.sha256(patched.read_bytes()).hexdigest()
    patched.with_suffix('.apk.sha256').write_text(f'{digest}  {patched.name}\n', encoding='ascii')
    print(f'Patched APK SHA256: {digest}')
