"""Patch only touch scheduling/lifecycle in an existing, disassembled EasyPlay APK."""
from pathlib import Path
import re
import zipfile
import sys

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / '.private/apk-analysis/easyplay/patch'
CONTROLLER = 'com/shilapi/xcertplay/orchestration/CarPlayController.smali'
SESSION = 'com/shilapi/xcertplay/airplay/AirPlaySession.smali'
C = 'Lcom/shilapi/xcertplay/orchestration/CarPlayController;'
B = 'Lcom/shilapi/xcertplay/patch/TouchBridge;'
S = 'Lcom/shilapi/xcertplay/airplay/AirPlaySession;'

def replace_method(text, signature, method):
    pattern = r'^\.method [^\n]*' + re.escape(signature) + r'\n.*?^\.end method'
    text, count = re.subn(pattern, lambda _: method.strip(), text, flags=re.M | re.S)
    assert count == 1, (signature, count)
    return text

def patch_smali():
    text = (WORK / 'original' / CONTROLLER).read_text(encoding='utf-8')
    marker = '.field private final touchExecutor:Ljava/util/concurrent/ExecutorService;'
    assert text.count(marker) == 1
    text = text.replace(marker, f'.field private final touchBridge:{B}\n\n' + marker)
    marker = f'    iput-object v1, v0, {C}->touchExecutor:Ljava/util/concurrent/ExecutorService;'
    assert text.count(marker) == 1
    text = text.replace(marker, marker + f'''

    new-instance v1, {B}
    invoke-direct {{v1}}, {B}-><init>()V
    iput-object v1, v0, {C}->touchBridge:{B}
''')
    text = replace_method(text, 'sendTouch(Ljava/util/List;)Z', f'''
.method public final sendTouch(Ljava/util/List;)Z
    .registers 5
    const-string v0, "contacts"
    invoke-static {{p1, v0}}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v0, 0x0
    iget-boolean v1, p0, {C}->closed:Z
    if-nez v1, :done
    iget-object v1, p0, {C}->activeSession:{S}
    if-eqz v1, :done
    iget-object v2, p0, {C}->touchBridge:{B}
    invoke-virtual {{v2, v1, p1}}, {B}->offer({S}Ljava/util/List;)Z
    move-result v0
    :done
    return v0
.end method
''')
    text = replace_method(text, 'access$setActiveSession$p(' + C + S + ')V', f'''
.method public static final synthetic access$setActiveSession$p({C}{S})V
    .registers 4
    monitor-enter p0
    :try_start
    iget-object v0, p0, {C}->touchBridge:{B}
    invoke-virtual {{v0, p1}}, {B}->setSession({S})V
    iput-object p1, p0, {C}->activeSession:{S}
    :try_end
    .catchall {{:try_start .. :try_end}} :failed
    monitor-exit p0
    return-void
    :failed
    move-exception v0
    monitor-exit p0
    throw v0
.end method
''')
    # The original close method has already sealed the controller before this point.
    marker = f'    iget-object v0, p0, {C}->touchExecutor:Ljava/util/concurrent/ExecutorService;'
    assert text.count(marker) == 1
    text = text.replace(marker, f'''    iget-object v0, p0, {C}->touchBridge:{B}
    invoke-virtual {{v0}}, {B}->close()V

''' + marker)
    out = WORK / 'modified' / CONTROLLER
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding='utf-8')
    text = (WORK / 'original' / SESSION).read_text(encoding='utf-8')
    assert 'touchPatchLog' not in text
    text += f'''

# Send patch diagnostics through the app's existing exportable log listener.
.method public final touchPatchLog(Ljava/lang/String;)V
    .registers 4
    :try_start
    iget-object v0, p0, {S}->listener:Lcom/shilapi/xcertplay/airplay/AirPlaySessionListener;
    invoke-interface {{v0, p1}}, Lcom/shilapi/xcertplay/airplay/AirPlaySessionListener;->onDebugLog(Ljava/lang/String;)V
    :try_end
    .catch Ljava/lang/Exception; {{:try_start .. :try_end}} :ignored
    goto :log
    :ignored
    move-exception v0
    :log
    const-string v0, "EasyPlayTouch"
    invoke-static {{v0, p1}}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    return-void
.end method
'''
    out = WORK / 'modified' / SESSION
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding='utf-8')
    print('Patched controller scheduling/lifecycle and added session diagnostic method')

def repack():
    with zipfile.ZipFile(WORK.parent / 'input.apk') as original, zipfile.ZipFile(WORK / 'unsigned.apk', 'w') as target:
        for entry in original.infolist():
            name = entry.filename
            if name.upper().startswith('META-INF/') and (name.upper().endswith(('.RSA', '.DSA', '.EC', '.SF'))
                    or name.upper() == 'META-INF/MANIFEST.MF'):
                continue
            content = (WORK / 'patched-classes3.dex').read_bytes() if name == 'classes3.dex' else original.read(name)
            target.writestr(entry, content)
    print('Repacked APK; all other payload entries retained byte-for-byte')

if __name__ == '__main__':
    {'smali': patch_smali, 'repack': repack}[sys.argv[1]]()
