import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

/** Compare canonical bytecode, independently of relocated DEX indices/offsets. */
public class DexAudit {
    private static String canonical(ClassDef c) throws Exception {
        BaksmaliOptions options = new BaksmaliOptions(); options.apiLevel=19; options.sequentialLabels=true;
        StringWriter text = new StringWriter(); BaksmaliWriter writer = new BaksmaliWriter(text);
        ClassDefinition def = new ClassDefinition(options,c); def.writeTo(writer); writer.flush();
        if (def.hadValidationErrors()) throw new Exception("Invalid class " + c.getType());
        // DexWriter may promote a string load when the merged string index exceeds 65535.
        String result=text.toString().replace("const-string/jumbo ", "const-string ");
        // Trailing encoded static default values may be omitted by DexWriter.
        return result.replaceAll("(?m)^(\\.field [^\\r\\n]+?) = (false|0x0|null|0\\.0f?)(?=\\r?$)", "$1");
    }
    private static Map<String,String> methods(String text) {
        Map<String,String> result = new TreeMap<String,String>();
        Matcher matcher = Pattern.compile("(?m)^\\.method ([^\\n]+)\\n.*?^\\.end method", Pattern.DOTALL).matcher(text);
        while (matcher.find()) result.put(matcher.group(1).trim(), matcher.group());
        return result;
    }
    public static void main(String[] args) throws Exception {
        String controller="Lcom/shilapi/xcertplay/orchestration/CarPlayController;";
        String session="Lcom/shilapi/xcertplay/airplay/AirPlaySession;";
        Map<String,ClassDef> target=new TreeMap<String,ClassDef>();
        DexFile original=DexFileFactory.loadDexFile(args[0],Opcodes.forApi(19));
        DexFile patched=DexFileFactory.loadDexFile(args[1],Opcodes.forApi(19));
        for (ClassDef c:patched.getClasses()) target.put(c.getType(),c);
        int unchanged=0,changed=0;
        for (ClassDef c:original.getClasses()) {
            ClassDef p=target.remove(c.getType());
            if (p==null) throw new Exception("Removed class " + c.getType());
            String before=canonical(c),after=canonical(p);
            if (before.equals(after)) {unchanged++;continue;}
            if (!c.getType().equals(controller) && !c.getType().equals(session)) {
                java.nio.file.Files.write(java.nio.file.Paths.get(args[1]+".before.smali"),before.getBytes("UTF-8"));
                java.nio.file.Files.write(java.nio.file.Paths.get(args[1]+".after.smali"),after.getBytes("UTF-8"));
                throw new Exception("Unexpected change " + c.getType());
            }
            String beforeHeader=before.substring(0,before.indexOf(".method "));
            String afterHeader=after.substring(0,after.indexOf(".method "));
            afterHeader=afterHeader.replaceAll("(?m)^\\.field private final touchBridge:Lcom/shilapi/xcertplay/patch/TouchBridge;\\r?\\n","");
            if (!beforeHeader.replaceAll("(?m)^\\s*$","").equals(afterHeader.replaceAll("(?m)^\\s*$","")))
                throw new Exception("Unexpected field/class metadata change " + c.getType());
            Map<String,String> oldMethods=methods(before),newMethods=methods(after);
            for (Map.Entry<String,String> m:oldMethods.entrySet()) {
                String newer=newMethods.remove(m.getKey());
                if (m.getValue().equals(newer)) continue;
                String name=m.getKey();
                if (!c.getType().equals(controller) || !(name.startsWith("public constructor <init>(")
                    || name.equals("public close()V") || name.equals("public final sendTouch(Ljava/util/List;)Z")
                    || name.startsWith("public static final synthetic access$setActiveSession$p(")))
                    throw new Exception("Unexpected method change " + c.getType() + " " + name);
                changed++; System.out.println("Modified method: " + name);
            }
            for (String name:newMethods.keySet()) {
                if (!c.getType().equals(session) || !name.equals("public final touchPatchLog(Ljava/lang/String;)V"))
                    throw new Exception("Unexpected new method " + name);
                System.out.println("Added method: " + name);
            }
        }
        for (ClassDef c:target.values()) {
            if (!c.getType().startsWith("Lcom/shilapi/xcertplay/patch/")) throw new Exception("Unexpected new class " + c.getType());
            canonical(c);
        }
        if (changed!=4) throw new Exception("Expected four patched controller methods; found " + changed);
        System.out.println("AUDIT PASS: unchanged original classes="+unchanged+", patched original classes=2, new patch classes="+target.size());
    }
}
