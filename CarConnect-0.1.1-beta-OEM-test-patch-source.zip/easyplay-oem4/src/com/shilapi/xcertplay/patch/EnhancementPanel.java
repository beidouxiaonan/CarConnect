package com.shilapi.xcertplay.patch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.View;
import android.widget.*;

public final class EnhancementPanel {
    public static void attach(final Activity activity, LinearLayout settings) {
        EnhancementPrefs.init(activity);
        Button button = new Button(activity);
        button.setText("画面帧率、独立音量和原车蓝牙");
        button.setMinHeight(dp(activity, 52));
        button.setTextSize(18);
        settings.addView(button, new LinearLayout.LayoutParams(-1, -2));
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) { show(activity); }
        });
    }
    private static int dp(Activity a, int value) { return (int)(value * a.getResources().getDisplayMetrics().density + .5f); }
    private static TextView label(Activity a, LinearLayout parent, String text, float size) {
        TextView view = new TextView(a); view.setText(text); view.setTextSize(size); view.setTextColor(Color.WHITE);
        view.setPadding(0,dp(a,8),0,dp(a,5)); parent.addView(view); return view;
    }
    public static void show(final Activity activity) {
        if (activity.isFinishing() || activity.isDestroyed()) return;
        EnhancementPrefs.init(activity);
        LinearLayout panel = new LinearLayout(activity); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(activity,18),dp(activity,8),dp(activity,18),dp(activity,14));
        panel.setBackgroundColor(Color.rgb(20,30,45));
        ScrollView scroll = new ScrollView(activity); scroll.addView(panel);
        label(activity,panel,"CarPlay 视频帧率（请求上限）",20);
        final RadioGroup fps = new RadioGroup(activity); fps.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton thirty = new RadioButton(activity); thirty.setId(3001); thirty.setText("30fps（流畅优先）"); thirty.setTextColor(Color.WHITE);
        RadioButton sixty = new RadioButton(activity); sixty.setId(6001); sixty.setText("60fps"); sixty.setTextColor(Color.WHITE);
        fps.addView(thirty,new RadioGroup.LayoutParams(0,dp(activity,50),1));
        fps.addView(sixty,new RadioGroup.LayoutParams(0,dp(activity,50),1)); panel.addView(fps);
        fps.check(EnhancementPrefs.getVideoFps(activity) == 60 ? 6001 : 3001);
        fps.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group,int checked) {
                EnhancementPrefs.saveVideoFps(activity,checked == 6001 ? 60 : 30);
            }
        });
        float hz = activity.getWindowManager().getDefaultDisplay().getRefreshRate();
        String display = hz > 0 && !Float.isNaN(hz) ? "车机屏幕约 " + Math.round(hz) + "Hz。" : "";
        label(activity,panel,display + "帧率更改后需重新连接；实际帧率取决于手机和车机解码能力。",14);
        label(activity,panel,"CarPlay 独立音量",20);
        volume(activity,panel,true); volume(activity,panel,false);
        label(activity,panel,"实时生效并保存。100% 为原始音量；系统音量与车机功放音量仍决定最终响度。",14);
        label(activity,panel,"如果导航应用把播报混入音乐，播报会随媒体音量一起变化。",14);
        label(activity,panel,"视频状态",20);
        label(activity,panel,VideoGuard.summary(),14);
        label(activity,panel,"原车蓝牙状态",20);
        final TextView status = label(activity,panel,"点击读取蓝牙状态和连接手机",16);
        Button refresh = new Button(activity); refresh.setText("读取 / 刷新原车蓝牙"); panel.addView(refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) { VendorBluetoothStatus.refresh(activity,status); }
        });
        label(activity,panel,"原车蓝牙无线连接测试",20);
        CheckBox oem = new CheckBox(activity);oem.setTextColor(Color.WHITE);
        oem.setText("使用 BC03 / gocsdk 原车数据通道（实验）");
        oem.setChecked(EnhancementPrefs.getOemBluetooth(activity));panel.addView(oem);
        oem.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton button,boolean checked){EnhancementPrefs.saveOemBluetooth(activity,checked);}
        });
        label(activity,panel,"默认关闭，更改后重新连接。先在原车蓝牙连接 iPhone，再开启车机热点并从主页面启动无线 CarPlay。仅适配已核对的 BC03 1.7.9 / gocsdk；有线连接不使用此入口。",14);
        final TextView oemStatus=label(activity,panel,OemTransport.summary(),14);
        Button inspect=new Button(activity);inspect.setText("刷新原车通道诊断");panel.addView(inspect);
        inspect.setOnClickListener(new View.OnClickListener(){public void onClick(View v){oemStatus.setText(OemTransport.summary());}});
        Button copy=new Button(activity);copy.setText("复制原车通道诊断");panel.addView(copy);
        copy.setOnClickListener(new View.OnClickListener(){public void onClick(View v){
            String text=OemTransport.summary();oemStatus.setText(text);
            android.content.ClipboardManager clip=(android.content.ClipboardManager)activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            if(clip!=null)clip.setPrimaryClip(android.content.ClipData.newPlainText("CarConnect OEM Bluetooth",text));
            Toast.makeText(activity,"原车通道诊断已复制",Toast.LENGTH_SHORT).show();
        }});
        AlertDialog dialog = new AlertDialog.Builder(activity).setTitle("CarConnect 0.1.1 beta · 原车蓝牙测试").setView(scroll)
            .setPositiveButton("完成",new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog,int which) { EnhancementPrefs.saveVolumes(); }
            }).create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) { EnhancementPrefs.saveVolumes(); }
        });
        dialog.show();
    }
    private static void volume(final Activity a,LinearLayout panel,final boolean navigation) {
        final String title = navigation ? "导航播报" : "媒体（音乐、视频）";
        final int initial = navigation ? AudioLevels.getNavigationVolume() : AudioLevels.getMediaVolume();
        final TextView value = label(a,panel,title + "：" + initial + "%",17);
        SeekBar slider = new SeekBar(a); slider.setMax(100); slider.setProgress(initial);
        slider.setPadding(dp(a,8),0,dp(a,8),0);
        panel.addView(slider,new LinearLayout.LayoutParams(-1,dp(a,48)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar bar,int progress,boolean fromUser) {
                if (!fromUser) return;
                AudioLevels.setUserVolumes(navigation ? progress : AudioLevels.getNavigationVolume(),
                    navigation ? AudioLevels.getMediaVolume() : progress);
                value.setText(title + "：" + progress + "%");
            }
            public void onStartTrackingTouch(SeekBar bar) {}
            public void onStopTrackingTouch(SeekBar bar) { EnhancementPrefs.saveVolumes(); }
        });
    }
}
