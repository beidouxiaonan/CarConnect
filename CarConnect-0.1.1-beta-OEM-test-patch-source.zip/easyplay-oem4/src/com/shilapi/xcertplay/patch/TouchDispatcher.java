package com.shilapi.xcertplay.patch;

import com.shilapi.xcertplay.airplay.AirPlayContact;
import java.io.Closeable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/** Bounded, session-local HID sender. Only consecutive move snapshots may be merged. */
public final class TouchDispatcher implements Closeable {
    public interface Sink {
        boolean send(List<AirPlayContact> contacts);
        void log(String message);
        void failed(String reason);
    }
    private static final class Job {
        final List<AirPlayContact> contacts;
        final boolean edge;
        final long queuedNs;
        Job(List<AirPlayContact> contacts, boolean edge) {
            this.contacts = contacts; this.edge = edge; queuedNs = System.nanoTime();
        }
    }
    private final Object lock = new Object();
    private final ArrayDeque<Job> queue = new ArrayDeque<Job>();
    private final Sink sink;
    private final int capacity;
    private final long stallNs, moveIntervalNs;
    private List<AirPlayContact> previous = Collections.emptyList();
    private boolean closed;
    private long sendingNs, lastStartedNs, lastLogNs, merged;
    private final Timer watchdog;
    private final Thread worker;

    public TouchDispatcher(Sink sink) { this(sink, 32, 5000, 33); }

    public TouchDispatcher(Sink sink, int capacity, long stallMillis, long moveMillis) {
        if (sink == null || capacity < 1 || stallMillis < 1 || moveMillis < 0)
            throw new IllegalArgumentException();
        this.sink = sink; this.capacity = capacity;
        stallNs = stallMillis * 1000000L; moveIntervalNs = moveMillis * 1000000L;
        watchdog = new Timer("easyplay-touch-watchdog", true);
        worker = new Thread(new Runnable() {
            public void run() { drain(); }
        }, "easyplay-touch-send");
        worker.setDaemon(true);
        watchdog.schedule(new TimerTask() {
            public void run() {
                boolean stalled;
                synchronized (lock) {
                    stalled = !closed && sendingNs != 0 && System.nanoTime() - sendingNs > stallNs;
                    // Seal under the same lock as send completion; never replay the backlog later.
                    if (stalled) sealLocked();
                }
                if (stalled) finishFailure("触摸发送阻塞超过 " + stallNs / 1000000L + "ms，请重新连接");
            }
        }, 100, 100);
        worker.start();
    }

    public boolean offer(List<AirPlayContact> contacts) {
        if (contacts == null) throw new NullPointerException("contacts");
        // AirPlayContact is immutable; copy the list, preserving contact order and IDs.
        List<AirPlayContact> snapshot = new ArrayList<AirPlayContact>(contacts);
        synchronized (lock) {
            if (closed) return false;
            boolean edge = !sameState(snapshot, previous);
            Job tail = queue.peekLast();
            if (!edge && tail != null && !tail.edge) {
                queue.removeLast(); merged++;
            }
            if (queue.size() < capacity) {
                queue.addLast(new Job(snapshot, edge)); previous = snapshot;
                lock.notifyAll(); return true;
            }
            // An overflow of gesture boundaries cannot be safely repaired by dropping an UP.
            sealLocked();
        }
        finishFailure("触摸事件积压达到上限 " + capacity + "，请重新连接");
        return false;
    }

    private static boolean sameState(List<AirPlayContact> a, List<AirPlayContact> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) {
            if (a.get(i).getId() != b.get(i).getId() || a.get(i).getDown() != b.get(i).getDown())
                return false;
        }
        return true;
    }

    private void drain() {
        try {
            while (true) {
                Job job;
                long started;
                synchronized (lock) {
                    while (true) {
                        if (closed) return;
                        if (queue.isEmpty()) { lock.wait(); continue; }
                        Job head = queue.peekFirst();
                        long remaining = moveIntervalNs - (System.nanoTime() - lastStartedNs);
                        // Never delay DOWN/UP/CANCEL; flush a preceding move if an edge is waiting.
                        if (!head.edge && queue.size() == 1 && remaining > 0) {
                            lock.wait(remaining / 1000000L, (int) (remaining % 1000000L));
                            continue;
                        }
                        job = queue.removeFirst();
                        started = System.nanoTime(); sendingNs = started; lastStartedNs = started;
                        break;
                    }
                }
                boolean sent;
                try { sent = sink.send(job.contacts); }
                finally { synchronized (lock) { sendingNs = 0; } }
                long finished = System.nanoTime();
                String diagnostic = null;
                synchronized (lock) {
                    if (closed) return;
                    if (finished - lastLogNs >= 5000000000L) {
                        diagnostic = "EasyPlay touchfix1 queuedMs=" + (started - job.queuedNs) / 1000000L
                            + " sendMs=" + (finished - started) / 1000000L + " pending=" + queue.size()
                            + " merged=" + merged + " sent=" + sent;
                        lastLogNs = finished;
                    }
                }
                // A false result also means the event socket is not ready yet. Keep original behavior.
                if (diagnostic != null) sink.log(diagnostic);
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } catch (Exception error) {
            fail("触摸发送异常：" + error.getClass().getSimpleName() + ": " + error.getMessage());
        }
    }

    private void sealLocked() {
        closed = true; queue.clear(); previous = Collections.emptyList(); lock.notifyAll();
    }
    private void fail(String reason) {
        synchronized (lock) {
            if (closed) return;
            sealLocked();
        }
        finishFailure(reason);
    }
    private void finishFailure(final String reason) {
        watchdog.cancel(); worker.interrupt();
        // A UI caller must not perform socket/media teardown or wait for the blocked sender.
        Thread closer = new Thread(new Runnable() {
            public void run() {
                try { sink.log("EasyPlay touchfix1: " + reason); } catch (Exception ignored) {}
                try { sink.failed(reason); } catch (Exception ignored) {}
            }
        }, "easyplay-touch-recover");
        closer.setDaemon(true); closer.start();
    }
    public void close() {
        synchronized (lock) {
            if (!closed) sealLocked();
        }
        watchdog.cancel(); worker.interrupt();
    }
}
