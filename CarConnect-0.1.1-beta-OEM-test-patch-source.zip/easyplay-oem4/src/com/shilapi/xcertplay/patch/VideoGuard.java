package com.shilapi.xcertplay.patch;

import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;
import kotlin.jvm.functions.Function1;

/** One shared observer; no codec calls or UI work on the observer thread. */
public final class VideoGuard {
    private static final Map<Object,Entry> entries=new WeakHashMap<Object,Entry>();
    private static volatile String latest="视频尚未连接。";
    private static ScheduledExecutorService observer;
    private static final class Entry {
        final VideoProgress progress=new VideoProgress();
        final WeakReference<Function1> report;
        Entry(Function1 report) { this.report=new WeakReference<Function1>(report); }
        void emit(String message) {
            if(message==null) return;
            latest=message;
            Function1 callback=report.get();
            try { if(callback!=null) callback.invoke(message); } catch(Exception ignored) {}
            Log.i("EasyPlayVideo",message);
        }
    }
    public static synchronized void bind(Object stats,Function1 report) {
        entries.put(stats,new Entry(report));
        if(observer==null) {
            observer=Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
                public Thread newThread(Runnable r) { Thread t=new Thread(r,"easyplay-video-observer"); t.setDaemon(true); return t; }
            });
            observer.scheduleWithFixedDelay(new Runnable() { public void run() { observe(); } },1,1,TimeUnit.SECONDS);
        }
    }
    private static synchronized Entry get(Object stats) { return entries.get(stats); }
    private static void observe() {
        List<Entry> active;
        synchronized(VideoGuard.class) { active=new ArrayList<Entry>(entries.values()); }
        for(Entry entry:active) entry.emit(entry.progress.report(System.nanoTime(),false));
    }
    public static synchronized void close(Object stats) { entries.remove(stats); }
    public static void received(Object stats) { Entry e=get(stats); if(e!=null)e.progress.received(System.nanoTime()); }
    public static void queued(Object stats) { Entry e=get(stats); if(e!=null)e.progress.queued(System.nanoTime()); }
    public static void released(Object stats,boolean render) { Entry e=get(stats); if(e!=null)e.progress.released(System.nanoTime(),render); }
    public static void nativeStarted(Object stats) { Entry e=get(stats); if(e!=null)e.progress.nativeStarted(System.nanoTime()); }
    public static void nativeFinished(Object stats) { Entry e=get(stats); if(e!=null)e.progress.nativeFinished(); }
    public static void stage(Object stats,String stage) { Entry e=get(stats); if(e!=null)e.progress.stage(stage); }
    public static void reset(Object stats) { Entry e=get(stats); if(e!=null)e.progress.reset(); }
    public static boolean recoveryDue(Object stats,boolean usable) {
        Entry e=get(stats); if(e==null)return false;
        if(!e.progress.recoveryDue(System.nanoTime(),usable))return false;
        e.emit(e.progress.report(System.nanoTime(),true)+" action=worker-resync"); return true;
    }
    public static void note(Object stats,String message) { Entry e=get(stats); if(e!=null)e.emit("VideoHealth "+message); }
    public static synchronized void texture() { long now=System.nanoTime(); for(Entry e:entries.values())e.progress.texture(now); }
    public static String summary() { return latest+"\nreceived 为收到的帧，decoded 为解码输出，texture 为屏幕更新。"; }
}
