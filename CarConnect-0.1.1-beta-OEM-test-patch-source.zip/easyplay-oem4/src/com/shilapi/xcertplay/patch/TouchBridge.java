package com.shilapi.xcertplay.patch;

import com.shilapi.xcertplay.airplay.AirPlayContact;
import com.shilapi.xcertplay.airplay.AirPlaySession;
import java.util.List;

/** Owned by the original controller; the USB, authentication and HID protocols remain intact. */
public final class TouchBridge {
    private AirPlaySession session;
    private TouchDispatcher dispatcher;
    private boolean closed;

    public synchronized void setSession(final AirPlaySession next) {
        if (closed || session == next) return;
        if (dispatcher != null) dispatcher.close();
        session = next; dispatcher = null;
        if (next != null) {
            dispatcher = new TouchDispatcher(new TouchDispatcher.Sink() {
                public boolean send(List<AirPlayContact> contacts) { return next.sendTouch(contacts); }
                public void log(String message) { next.touchPatchLog(message); }
                public void failed(String reason) { next.close(); }
            });
        }
    }
    public synchronized boolean offer(AirPlaySession expected, List<AirPlayContact> contacts) {
        return !closed && expected != null && session == expected && dispatcher != null
            && dispatcher.offer(contacts);
    }
    public synchronized void close() {
        closed = true;
        if (dispatcher != null) dispatcher.close();
        dispatcher = null; session = null;
    }
}
