import re

P='Lcom/shilapi/xcertplay/patch/'
C='Lcom/shilapi/xcertplay/orchestration/CarPlayController;'
S='Lcom/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream;'

def patch_oem(work,original,write,edit_method,one):
    name='com/shilapi/xcertplay/orchestration/CarPlayController.smali'
    text=(work/'modified'/name).read_text(encoding='utf-8')
    def select(m):
        marker='    move-object/from16 v0, p0'
        return one(m,marker,marker+f'''
    invoke-static {{}}, {P}OemTransport;->enabled()Z
    move-result v1
    if-eqz v1, :patch_standard_selection
    invoke-static/range {{p1 .. p1}}, {P}OemTransport;->select(Landroid/bluetooth/BluetoothAdapter;)Landroid/bluetooth/BluetoothDevice;
    move-result-object v1
    return-object v1
    :patch_standard_selection
''')
    text=edit_method(text,'selectWirelessBluetoothDevice(Landroid/bluetooth/BluetoothAdapter;)Landroid/bluetooth/BluetoothDevice;',select)
    def local(m):
        assert m.count('    .line 2046')==2
        return m.replace('    .line 2046',f'''    invoke-static {{}}, {P}OemTransport;->enabled()Z
    move-result v0
    if-eqz v0, :patch_standard_local_mac
    invoke-static {{}}, {P}OemTransport;->localMac()Ljava/lang/String;
    move-result-object v0
    return-object v0
    :patch_standard_local_mac
    .line 2046''',1)
    text=edit_method(text,'accessoryBluetoothMac(Landroid/bluetooth/BluetoothAdapter;)Ljava/lang/String;',local)
    def wireless(m):
        m=one(m,'    :try_start_8\n',f'''    :try_start_8
    iget-object v6, v1, {C}->appContext:Landroid/content/Context;
    invoke-static {{v6, v1, v2}}, {P}OemTransport;->begin(Landroid/content/Context;{C}I)V
''')
        m=one(m,'    invoke-virtual {v3}, Landroid/bluetooth/BluetoothAdapter;->isEnabled()Z',f'    invoke-static {{v3}}, {P}OemTransport;->adapterEnabled(Landroid/bluetooth/BluetoothAdapter;)Z')
        m=one(m,'    .line 1058',f'''    invoke-static {{}}, {P}OemTransport;->enabled()Z
    move-result v9
    if-eqz v9, :patch_standard_socket
    invoke-virtual {{v4}}, Landroid/bluetooth/BluetoothDevice;->getAddress()Ljava/lang/String;
    move-result-object v9
    invoke-static {{v9}}, {P}OemTransport;->open(Ljava/lang/String;)Lcom/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream;
    move-result-object v10
    const/4 v9, 0x0
    # Publish ownership immediately so existing generation cancellation can close it.
    iput-object v10, v1, {C}->bluetoothStream:{S}
    invoke-direct/range {{p0 .. p1}}, {C}->isStaleWirelessRun(I)Z
    move-result v13
    if-eqz v13, :patch_stream_ready
    invoke-virtual {{v10}}, {S}->close()V
    return-void
    :patch_standard_socket
    .line 1058''')
        marker=f'    invoke-direct {{v10, v9}}, {S}-><init>(Landroid/bluetooth/BluetoothSocket;)V'
        m=one(m,marker,marker+'\n\n    :patch_stream_ready')
        # The run snapshot must not outlive the worker. Stream ownership remains with the controller.
        m=m.replace('    return-void',f'    invoke-static {{}}, {P}OemTransport;->end()V\n    return-void')
        return m
    text=edit_method(text,'runWireless(I)V',wireless)
    write(name,text)

    name='com/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream.smali'
    text=original(name)
    text=one(text,'# instance fields',f'# instance fields\n.field private final patchOwnedSocket:Ljava/io/Closeable;\n')
    ctor=re.search(r'(?ms)^\.method public constructor <init>\(Landroid/bluetooth/BluetoothSocket;\)V\n.*?^\.end method',text)[0]
    new=ctor.replace('<init>(Landroid/bluetooth/BluetoothSocket;)V','<init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/io/Closeable;)V').replace('.registers 6','.registers 8')
    new=re.sub(r'^    \.param p1,.*\n','',new,flags=re.M).replace('const-string v0, "socket"','const-string v0, "input"')
    new=one(new,f'    iput-object p1, p0, {S}->socket:Landroid/bluetooth/BluetoothSocket;',f'    iput-object p3, p0, {S}->patchOwnedSocket:Ljava/io/Closeable;')
    for kind,parameter in [('Input','p1'),('Output','p2')]:
        lower=kind.lower()
        block=f'''    iget-object v0, p0, {S}->socket:Landroid/bluetooth/BluetoothSocket;

    invoke-virtual {{v0}}, Landroid/bluetooth/BluetoothSocket;->get{kind}Stream()Ljava/io/{kind}Stream;

    move-result-object v0

    iput-object v0, p0, {S}->{lower}:Ljava/io/{kind}Stream;'''
        new=one(new,block,f'    iput-object {parameter}, p0, {S}->{lower}:Ljava/io/{kind}Stream;')
    new=new.replace('xcertplay-bluetooth-rfcomm-reader','carconnect-oem-spp-reader')
    text=text+'\n\n'+new+'\n'
    def close(m):
        start=f'    iget-object v0, p0, {S}->socket:Landroid/bluetooth/BluetoothSocket;'
        m=one(m,start,f'''    iget-object v0, p0, {S}->patchOwnedSocket:Ljava/io/Closeable;
    if-eqz v0, :patch_close_standard_socket
    invoke-interface {{v0}}, Ljava/io/Closeable;->close()V
    goto :patch_close_socket_done
    :patch_close_standard_socket
{start}''')
        end='    invoke-virtual {v0}, Landroid/bluetooth/BluetoothSocket;->close()V'
        return one(m,end,end+'\n    :patch_close_socket_done')
    text=edit_method(text,'closeSocketOnce()Ljava/io/IOException;',close)
    write(name,text)
