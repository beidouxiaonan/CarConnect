param(
    [string]$JdkPath = '',
    [string]$PythonPath = 'D:\Program Files\Python3.13.13\python.exe',
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath("$PSScriptRoot/..")
if (-not $JdkPath) { $JdkPath = "$root/.tooling/jdk25" }
$patchRoot = "$root/easyplay-oem4"
$work = "$root/.private/apk-analysis/easyplay/oem4"
$bt = "$root/.tooling/build-tools/android-15"
$jadx = "$root/.tooling/jadx/lib/jadx-1.5.6-all.jar"
$android = "$root/.tooling/platform/android-4.4.2/android.jar"
$java = "$JdkPath/bin/java.exe"
$javac = "$JdkPath/bin/javac.exe"
$jar = "$JdkPath/bin/jar.exe"
function Check([string]$stage) { if ($LASTEXITCODE -ne 0) { throw "$stage failed: $LASTEXITCODE" } }
Push-Location $root
try {
    New-Item -ItemType Directory -Force "$patchRoot/build/stubs", "$patchRoot/build/classes", "$patchRoot/build/tests", "$patchRoot/build/test-stubs", "$patchRoot/build/dex", "$root/artifacts" | Out-Null
    $stubSources = @(Get-ChildItem "$patchRoot/stubs" -Recurse -Filter '*.java' | ForEach-Object FullName)
    $patchSources = @(Get-ChildItem "$patchRoot/src" -Recurse -Filter '*.java' | ForEach-Object FullName)
    & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $android -d "$patchRoot/build/stubs" @stubSources; Check 'Compile stubs'
    & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp "$patchRoot/build/stubs;$android" -d "$patchRoot/build/classes" @patchSources; Check 'Compile helpers'
    if (-not $SkipTests) {
        $fakes = @(Get-ChildItem "$patchRoot/test-stubs" -Recurse -Filter '*.java' | ForEach-Object FullName)
        & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $android -d "$patchRoot/build/test-stubs" @fakes; Check 'Compile test fakes'
        $testCp = "$patchRoot/build/test-stubs;$patchRoot/build/stubs;$patchRoot/build/classes;$root/.tooling/test-libs/junit.jar;$root/.tooling/test-libs/hamcrest.jar;$android"
        $tests = @(Get-ChildItem "$patchRoot/test" -Recurse -Filter '*.java' | ForEach-Object FullName)
        & $javac --release 8 -Xlint:-options -encoding UTF-8 -cp $testCp -d "$patchRoot/build/tests" @tests; Check 'Compile tests'
        & $java -cp "$testCp;$patchRoot/build/tests" org.junit.runner.JUnitCore com.shilapi.xcertplay.patch.TouchDispatcherTest com.shilapi.xcertplay.patch.AudioLevelsTest com.shilapi.xcertplay.patch.EnhancementPrefsTest com.shilapi.xcertplay.patch.VideoProgressTest com.shilapi.xcertplay.patch.Bc03SchemaTest com.shilapi.xcertplay.patch.VideoOutputTest com.shilapi.xcertplay.patch.OemProtocolTest; Check 'Touch/audio/preferences tests'
    }
    & $jar --create --file "$patchRoot/build/stubs.jar" -C "$patchRoot/build/stubs" .; Check 'Stub classpath jar'
    & $jar --create --file "$patchRoot/build/patch.jar" -C "$patchRoot/build/classes" .; Check 'Helper jar'
    & $java -cp "$bt/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 19 --lib $android --classpath "$patchRoot/build/stubs.jar" --output "$patchRoot/build/dex" "$patchRoot/build/patch.jar"; Check 'D8 API 19'
    & $java -cp $jadx "$patchRoot/tools/DexTool.java" dis "$work/../classes3.dex" "$work/original" 'Lcom/shilapi/xcertplay/orchestration/CarPlayController;' 'Lcom/shilapi/xcertplay/airplay/AirPlaySession;' 'Lcom/shilapi/xcertplay/legacy/LegacyActivity;' 'Lcom/shilapi/xcertplay/legacy/LegacySessionService;' 'Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;' 'Lcom/shilapi/xcertplay/media/LegacyAudioFocus;' 'Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;' 'Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;' 'Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;' 'Lcom/shilapi/xcertplay/legacy/EasyPlayVersionSettings;' 'Lcom/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream;'; Check 'Disassemble original'
    & $PythonPath "$patchRoot/patch_apk.py" smali; Check 'Patch smali'
    & $java -cp $jadx "$patchRoot/tools/DexTool.java" asm "$work/modified" "$work/controller.dex"; Check 'Assemble modified classes'
    & $java -Xmx1g -cp $jadx "$patchRoot/tools/DexTool.java" merge "$work/patched-classes3.dex" "$work/../classes3.dex" "$work/controller.dex" "$patchRoot/build/dex/classes.dex"; Check 'Merge helpers'
    $auditArgs=@("$work/../classes3.dex", "$work/patched-classes3.dex", "$work/../patch/patched-classes3.dex")
    if(Test-Path -LiteralPath "$work/../stability3/patched-classes3.dex") { $auditArgs+= "$work/../stability3/patched-classes3.dex" }
    else { Write-Output 'Published 0.1.0 media baseline absent; optional comparison skipped' }
    & $java -Xmx1g -cp $jadx "$patchRoot/tools/DexAudit.java" @auditArgs; Check 'Original code and stable touch audit'
    & $PythonPath "$patchRoot/verify_vendor_schema.py"; Check 'OEM query and callback schema'
    & $PythonPath "$patchRoot/patch_apk.py" repack; Check 'Repack APK'
    & "$bt/zipalign.exe" -f 4 "$work/unsigned.apk" "$work/aligned.apk"; Check 'Align APK'
    $apk = "$root/artifacts/CarConnect-0.1.1-beta-OEM-test-Android4.4.apk"
    & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" sign --ks "$root/.private/kitkat-probe-debug.jks" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --min-sdk-version 19 --v1-signing-enabled true --v2-signing-enabled true --v4-signing-enabled false --out $apk "$work/aligned.apk"; Check 'Sign APK'
    & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" verify --verbose --min-sdk-version 19 $apk; Check 'API 19 signature verification'
    & "$bt/zipalign.exe" -c 4 $apk; Check 'Alignment verification'
    & $PythonPath "$patchRoot/verify_apk.py"; Check 'APK payload verification'
    & "$bt/aapt.exe" dump xmltree $apk AndroidManifest.xml | Set-Content "$patchRoot/build/manifest.txt" -Encoding utf8; Check 'Manifest verification'
    Write-Output "EasyPlay APK: $apk"
} finally { Pop-Location }
