"""Verify our read-only transaction numbers against the user-supplied OEM AIDL sources."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
vendor = root / '.private/vendor-analysis'
if not (vendor/'bc03/decoded/sources/com/bt/BTFeature.java').exists():
    print('OEM reference-source audit skipped: private BC03/GocSdk sources not supplied; no assumed schema added')
    raise SystemExit(0)
def transactions(file):
    return {name: int(code) for name, code in re.findall(r'static final int TRANSACTION_(\w+)\s*=\s*(\d+)', file.read_text(encoding='utf-8'))}

bc = transactions(vendor / 'bc03/decoded/sources/com/bt/BTFeature.java')
for name, code in {'isBlueToothPowerOn': 3, 'isConnectDevice': 6, 'isConnectHFP': 35,
                   'isConnectA2DP': 36, 'getLocalDeviceName': 10, 'getConnectDevice': 38}.items():
    assert bc[name] == code, (name, bc[name], code)
device = (vendor / 'bc03/decoded/sources/com/bt/BTDevice.java').read_text(encoding='utf-8')
assert re.search(r'private BTDevice\(Parcel parcel\)\s*\{\s*this.mAddress = parcel.readString\(\);\s*this.mName = parcel.readString\(\);', device)
goc = transactions(vendor / 'goc/decoded/sources/com/goodocom/gocsdk/IGocsdkService.java')
for name, code in {'GOCSDK_registerCallback': 1, 'GOCSDK_unregisterCallback': 2, 'GOCSDK_InquiryHfpStatus': 32,
                   'GOCSDK_InquiryA2dpStatus': 37, 'GOCSDK_InquiryCurBtAddr': 61, 'GOCSDK_InquiryCurBtName': 62}.items():
    assert goc[name] == code, (name, goc[name], code)
callback = transactions(vendor / 'goc/decoded/sources/com/goodocom/gocsdk/IGocsdkCallback.java')
for name, code in {'onHfpDisconnected': 1, 'onHfpConnected': 2, 'onCurrentAddr': 19, 'onCurrentName': 20,
                   'onHfpStatus': 21, 'onAvStatus': 22, 'onCurrentDeviceName': 24,
                   'onA2dpConnected': 26, 'onA2dpDisconnected': 28}.items():
    assert callback[name] == code, (name, callback[name], code)
print('OEM protocol audit PASS: BC03 getters/peer parcel and GocSdk query/callback/unregister schema match supplied files')

# Actual installed 1.7.9 reference, separately from the earlier 1.3.6 sample.
actual=vendor/'bc03-179/decoded/sources/com/bt/BTFeature.java'
if actual.exists():
    t=transactions(actual)
    assert t['getLocalDeviceAddress']==20 and t['isSppConnect']==50
    h=(actual.parent/'bc03/HdLinkManager.java').read_text(encoding='utf-8')
    body=re.search(r'public boolean SppConnect\(String address\)\s*\{(.*?)\n    \}',h,re.S)[1]
    assert 'return true;' in body and 'mBtFeature' not in body
    print('Actual BC03 1.7.9 audit PASS: local MAC/SPP getters match; public SppConnect remains a no-op')
else:
    print('Actual BC03 1.7.9 audit skipped: private reference not present')
