from pathlib import Path
import importlib.util
import re
import sys
from patch_video import patch_video
from patch_oem import patch_oem
from patch_brand import patch_brand, repack

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / '.private/apk-analysis/easyplay/oem4'
spec = importlib.util.spec_from_file_location('touch_patch', ROOT / 'easyplay-touchfix/patch_apk.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.WORK = WORK
P = 'Lcom/shilapi/xcertplay/patch/'

def one(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

def edit_method(text, signature, edit):
    pattern = r'^\.method [^\n]*' + re.escape(signature) + r'\n.*?^\.end method'
    matches = list(re.finditer(pattern, text, re.M | re.S))
    assert len(matches) == 1, (signature, len(matches))
    match = matches[0]
    return text[:match.start()] + edit(match.group()) + text[match.end():]

def write(name, text):
    path = WORK / 'modified' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')

def original(name):
    return (WORK / 'original' / name).read_text(encoding='utf-8')

def patch():
    base.patch_smali()
    name = 'com/shilapi/xcertplay/legacy/LegacyActivity.smali'
    text = original(name)
    def activity(method):
        return one(method, '    .line 159\n    return-void', f'''
    iget-object v3, v0, Lcom/shilapi/xcertplay/legacy/LegacyActivity;->connectionScreen:Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;
    invoke-virtual {{v3}}, Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;->getAdvanced()Landroid/widget/LinearLayout;
    move-result-object v3
    invoke-static {{v0, v3}}, {P}EnhancementPanel;->attach(Landroid/app/Activity;Landroid/widget/LinearLayout;)V
    .line 159
    return-void''')
    write(name, edit_method(text,'onCreate(Landroid/os/Bundle;)V',activity))

    name = 'com/shilapi/xcertplay/legacy/LegacySessionService.smali'
    text = original(name)
    marker = '.field private'
    index = text.index(marker)
    text = text[:index] + '.field private enhancementFps:I\n\n' + text[index:]
    signature = 'startSession$lambda$46$lambda$43(Lcom/shilapi/xcertplay/legacy/LegacySessionService;ILcom/shilapi/xcertplay/media/LegacyMediaCapabilities;ZZLjava/lang/String;Ljava/lang/String;Lcom/shilapi/xcertplay/airplay/AirPlayIdentity;Ljava/lang/String;Ljava/lang/String;Lcom/shilapi/xcertplay/airplay/PairingStore;Lcom/shilapi/xcertplay/legacy/LegacyStorage;Landroid/content/SharedPreferences;Ljava/lang/String;)V'
    def video(method):
        method = one(method, '    const-string v3, " / 30fps"', f'''    invoke-static {{v1}}, {P}EnhancementPrefs;->getVideoFps(Landroid/content/Context;)I
    move-result v3
    iput v3, v1, Lcom/shilapi/xcertplay/legacy/LegacySessionService;->enhancementFps:I
    invoke-static {{v3}}, {P}EnhancementPrefs;->fpsSuffix(I)Ljava/lang/String;
    move-result-object v3''')
        return one(method,'    const/16 v15, 0x1e','    iget v15, v1, Lcom/shilapi/xcertplay/legacy/LegacySessionService;->enhancementFps:I')
    write(name, edit_method(text,signature,video))

    name = 'com/shilapi/xcertplay/media/LegacyAudioRenderer.smali'
    text = original(name)
    def track(method):
        marker = '    iput-object v5, v1, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->track:Landroid/media/AudioTrack;'
        return one(method,marker,marker+f'''
    iget-object v0, v1, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->selection:Lcom/shilapi/xcertplay/media/AudioChannelSelection;
    invoke-virtual {{v0}}, Lcom/shilapi/xcertplay/media/AudioChannelSelection;->getChannel()Lcom/shilapi/xcertplay/media/AudioChannel;
    move-result-object v0
    invoke-virtual {{v0}}, Ljava/lang/Enum;->name()Ljava/lang/String;
    move-result-object v0
    invoke-static {{v5, v0}}, {P}AudioLevels;->register(Landroid/media/AudioTrack;Ljava/lang/String;)V
''')
    write(name, edit_method(text,'createTrack()V',track))

    name = 'com/shilapi/xcertplay/media/LegacyAudioFocus.smali'
    text = original(name)
    def ctor(method):
        marker = '    invoke-direct {p0}, Ljava/lang/Object;-><init>()V'
        return one(method,marker,marker+f'\n\n    invoke-static {{p1}}, {P}EnhancementPrefs;->init(Landroid/content/Context;)V')
    text = edit_method(text,'<init>(Landroid/content/Context;ZLkotlin/jvm/functions/Function1;)V',ctor)
    def focus(method):
        return one(method, '    invoke-virtual {p1, v0, v1}, Landroid/media/AudioTrack;->setStereoVolume(FF)I',
            f'    invoke-static {{p1, v0, v1}}, {P}AudioLevels;->setStereoVolume(Landroid/media/AudioTrack;FF)I')
    text = edit_method(text,'applyVolume(Landroid/media/AudioTrack;)V',focus)
    def remove(method):
        marker = '    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V'
        return one(method,marker,marker+f'\n\n    invoke-static {{p1}}, {P}AudioLevels;->unregister(Landroid/media/AudioTrack;)V')
    write(name,edit_method(text,'remove(Landroid/media/AudioTrack;)V',remove))
    patch_video(WORK,original,write,edit_method,one,base.replace_method)
    patch_brand(WORK,original,write,edit_method,base.replace_method)
    patch_oem(WORK,original,write,edit_method,one)
    print('Added settings panel, 30/60fps session preference, per-track gain/focus composition and read-only Bluetooth adapters')

if __name__ == '__main__':
    {'smali': patch, 'repack': lambda: repack(WORK,ROOT/'.private/apk-analysis/easyplay/input.apk')}[sys.argv[1]]()
