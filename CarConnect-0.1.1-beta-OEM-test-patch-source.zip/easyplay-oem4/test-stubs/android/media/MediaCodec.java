package android.media;
import java.util.*;
public class MediaCodec {
    public static final int INFO_OUTPUT_FORMAT_CHANGED=-2,INFO_OUTPUT_BUFFERS_CHANGED=-3;
    public static class BufferInfo {}
    public final Deque<Integer> ready=new ArrayDeque<Integer>();
    public final List<String> released=new ArrayList<String>();
    public int throwIndex=-1;
    public int dequeueOutputBuffer(BufferInfo info,long timeout){return ready.isEmpty()?-1:ready.removeFirst();}
    public void releaseOutputBuffer(int index,boolean render){released.add(index+":"+render);if(index==throwIndex)throw new IllegalStateException();}
    public MediaFormat getOutputFormat(){return null;}
}
