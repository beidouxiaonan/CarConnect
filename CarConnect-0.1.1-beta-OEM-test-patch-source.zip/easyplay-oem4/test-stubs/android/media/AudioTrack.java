package android.media;
// JVM test fake only; excluded from APK and production compilation.
public class AudioTrack {
    public float left=1,right=1;
    public boolean released;
    public int setStereoVolume(float left,float right) {
        if (released) throw new IllegalStateException("released track");
        this.left=left;this.right=right;return 0;
    }
}
