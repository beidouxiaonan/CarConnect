package com.shilapi.xcertplay.media;
public class LegacyVideoRenderStats {
    public void vendorCallStarted() {}
    public void vendorCallFinished() {}
    public void released(boolean render) {}
}
