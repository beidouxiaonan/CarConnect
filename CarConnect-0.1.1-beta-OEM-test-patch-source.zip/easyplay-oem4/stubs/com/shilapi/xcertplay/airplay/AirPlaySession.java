package com.shilapi.xcertplay.airplay;
import java.util.*;
// Compile/test stub only; never packaged. The original APK supplies the implementation.
public class AirPlaySession {
    public final List<List<AirPlayContact>> reports = Collections.synchronizedList(new ArrayList<List<AirPlayContact>>());
    public volatile boolean closed;
    public boolean sendTouch(List<AirPlayContact> contacts) { reports.add(contacts); return true; }
    public void touchPatchLog(String message) {}
    public void close() { closed = true; }
}
