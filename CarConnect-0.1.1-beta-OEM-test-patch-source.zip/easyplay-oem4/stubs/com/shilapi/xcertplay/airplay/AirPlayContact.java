package com.shilapi.xcertplay.airplay;
// Compile/test stub only; never packaged. The original APK supplies this immutable type.
public final class AirPlayContact {
    private final int id; private final double x, y; private final boolean down;
    public AirPlayContact(int id, double x, double y, boolean down) {
        this.id=id; this.x=x; this.y=y; this.down=down;
    }
    public int getId() { return id; }
    public double getX() { return x; }
    public double getY() { return y; }
    public boolean getDown() { return down; }
}
