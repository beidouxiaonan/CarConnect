"""Targeted API19 video recovery and output scheduling changes to the original APK."""
D = 'Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;'
P = 'Lcom/shilapi/xcertplay/patch/'
G = P + 'VideoGuard;'

def patch_video(work, original, write, edit_method, one, replace_method):
    name='com/shilapi/xcertplay/media/LegacyVideoDecoder.smali'
    text=original(name)
    text=one(text,'.field private codec:Landroid/media/MediaCodec;', '.field private patchCodecProduced:Z\n\n.field private codec:Landroid/media/MediaCodec;')
    def ctor(m):
        marker=f'    iput-object v1, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;'
        return one(m,marker,marker+f'\n    invoke-static {{v1, p4}}, {G}->bind(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)V')
    text=edit_method(text,'<init>(Landroid/view/Surface;IILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V',ctor)
    def reset(m):
        index=m.index('    move-object v0, p0')
        return m[:index]+f'''    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    invoke-static {{v0}}, {G}->reset(Ljava/lang/Object;)V
    const-string v1, "codec-release"
    invoke-static {{v0, v1}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v0, 0x0
    iput-boolean v0, p0, {D}->patchCodecProduced:Z
'''+m[index:]
    text=edit_method(text,'reset(Ljava/lang/String;)V',reset)
    def run(m):
        m=one(m,f'    invoke-direct {{p0}}, {D}->poll()',f'    invoke-direct {{p0}}, {D}->patchCheckProgress()V\n    invoke-direct {{p0}}, {D}->poll()')
        for reg,reason in [('v5','Video backlog; requesting a fresh keyframe'),('v4','Video queue overflow; requesting a fresh keyframe')]:
            marker=f'    const-string {reg}, "{reason}"\n\n    invoke-direct {{p0, {reg}}}, {D}->reset(Ljava/lang/String;)V'
            m=one(m,marker,marker.replace('->reset(', '->patchResync('))
        return m
    text=edit_method(text,'run()V',run)
    def feed(m):
        old=f'    const-string v0, "Video decoder input stalled"\n\n    invoke-direct {{v1, v0}}, {D}->reset(Ljava/lang/String;)V'
        m=one(m,old,old.replace('->reset(', '->patchResync('))
        m=one(m,'    const-wide/16 v8, 0x2710',f'''    iget-object v8, v1, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    const-string v9, "dequeue-input"
    invoke-static {{v8, v9}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
    const-wide/16 v8, 0x2710''')
        m=one(m,'    const/4 v10, 0x0',f'''    iget-object v0, v1, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    const-string v10, "queue-input"
    invoke-static {{v0, v10}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v10, 0x0''')
        index=m.index('    .line 466')
        return m[:index]+f'''    move-object/from16 v0, p0
    iget-object v0, v0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    const-string v1, "codec-input"
    invoke-static {{v0, v1}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
'''+m[index:]
    text=edit_method(text,'feed(Lcom/shilapi/xcertplay/airplay/OwnedVideoFrame;)Z',feed)
    def configure(m):
        index=m.index('    .line 449')
        return m[:index]+f'''    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    const-string v1, "codec-configure"
    invoke-static {{v0, v1}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
'''+m[index:]
    text=edit_method(text,'configureCodec()V',configure)
    def frame(m):
        index=m.index('    const-string ')
        return m[:index]+f'''    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    invoke-static {{v0}}, {G}->received(Ljava/lang/Object;)V
'''+m[index:]
    text=edit_method(text,'frame(Lcom/shilapi/xcertplay/airplay/OwnedVideoFrame;)V',frame)
    def close(m):
        marker=f'    iput-boolean v0, p0, {D}->running:Z'
        return one(m,marker,marker+f'\n    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;\n    invoke-static {{v0}}, {G}->close(Ljava/lang/Object;)V')
    text=edit_method(text,'close()V',close)
    text=replace_method(text,'drain(Landroid/media/MediaCodec;)V',f'''
.method private final drain(Landroid/media/MediaCodec;)V
    .registers 7
    iget-object v0, p0, {D}->info:Landroid/media/MediaCodec$BufferInfo;
    iget-object v1, p0, {D}->output:Landroid/view/Surface;
    iget-object v2, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    iget-object v3, p0, {D}->report:Lkotlin/jvm/functions/Function1;
    invoke-static {{p1, v0, v1, v2, v3}}, {P}VideoOutput;->drain(Landroid/media/MediaCodec;Landroid/media/MediaCodec$BufferInfo;Landroid/view/Surface;Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;Lkotlin/jvm/functions/Function1;)Z
    move-result v0
    if-eqz v0, :done
    const/4 v0, 0x1
    iput-boolean v0, p0, {D}->patchCodecProduced:Z
    iget-boolean v1, p0, {D}->firstFrame:Z
    if-nez v1, :done
    iput-boolean v0, p0, {D}->firstFrame:Z
    const-string v0, "first frame rendered"
    invoke-interface {{v3, v0}}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :done
    return-void
.end method
''')
    text+=f'''
.method private final patchCheckProgress()V
    .registers 5
    iget-object v0, p0, {D}->codec:Landroid/media/MediaCodec;
    const/4 v1, 0x0
    if-eqz v0, :check
    iget-object v0, p0, {D}->output:Landroid/view/Surface;
    if-eqz v0, :check
    invoke-virtual {{v0}}, Landroid/view/Surface;->isValid()Z
    move-result v1
    :check
    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    invoke-static {{v0, v1}}, {G}->recoveryDue(Ljava/lang/Object;Z)Z
    move-result v0
    if-eqz v0, :done
    iget-object v0, p0, {D}->queueLock:Ljava/lang/Object;
    monitor-enter v0
    :try_start_lock
    invoke-direct {{p0}}, {D}->discardFrames()V
    :try_end_lock
    .catchall {{:try_start_lock .. :try_end_lock}} :unlock
    monitor-exit v0
    const-string v0, "Video output stalled; requesting a fresh keyframe"
    invoke-direct {{p0, v0}}, {D}->patchResync(Ljava/lang/String;)V
    :done
    return-void
    :unlock
    move-exception v1
    monitor-exit v0
    throw v1
.end method

.method private final patchResync(Ljava/lang/String;)V
    .registers 6
    iget-object v0, p0, {D}->renderStats:Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;
    invoke-static {{v0}}, {G}->reset(Ljava/lang/Object;)V
    iget-boolean v1, p0, {D}->needsKeyFrame:Z
    if-eqz v1, :recover
    const-string v2, "Video decoder input stalled"
    invoke-virtual {{v2, p1}}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-nez v2, :hard
    goto :done
    :recover
    iget-object v1, p0, {D}->codec:Landroid/media/MediaCodec;
    if-eqz v1, :hard
    iget-boolean v2, p0, {D}->patchCodecProduced:Z
    if-eqz v2, :hard
    const-string v2, "codec-flush"
    invoke-static {{v0, v2}}, {G}->stage(Ljava/lang/Object;Ljava/lang/String;)V
    const/4 v2, 0x1
    iput-boolean v2, p0, {D}->needsKeyFrame:Z
    invoke-virtual {{v0}}, Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;->vendorCallStarted()V
    :try_start_flush
    invoke-virtual {{v1}}, Landroid/media/MediaCodec;->flush()V
    invoke-virtual {{v1}}, Landroid/media/MediaCodec;->getInputBuffers()[Ljava/nio/ByteBuffer;
    move-result-object v1
    iput-object v1, p0, {D}->inputs:[Ljava/nio/ByteBuffer;
    :try_end_flush
    .catch Ljava/lang/Exception; {{:try_start_flush .. :try_end_flush}} :failed
    invoke-virtual {{v0}}, Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;->vendorCallFinished()V
    invoke-static {{v0, p1}}, {G}->note(Ljava/lang/Object;Ljava/lang/String;)V
    invoke-direct {{p0}}, {D}->askForKeyFrame()V
    goto :done
    :failed
    move-exception v1
    invoke-virtual {{v0}}, Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;->vendorCallFinished()V
    :hard
    invoke-direct {{p0, p1}}, {D}->reset(Ljava/lang/String;)V
    :done
    return-void
.end method
'''
    write(name,text)
    name='com/shilapi/xcertplay/media/LegacyVideoRenderStats.smali'
    text=original(name)
    for signature,hook in [('queued()V','queued(Ljava/lang/Object;)V'),('released(Z)V','released(Ljava/lang/Object;Z)V'),
                           ('vendorCallStarted()V','nativeStarted(Ljava/lang/Object;)V'),('vendorCallFinished()V','nativeFinished(Ljava/lang/Object;)V')]:
        def add(m):
            index=m.index('    monitor-enter p0')
            args='p0, p1' if signature=='released(Z)V' else 'p0'
            return m[:index]+f'    invoke-static {{{args}}}, {G}->{hook}\n'+m[index:]
        text=edit_method(text,signature,add)
    write(name,text)
    name='com/shilapi/xcertplay/legacy/LegacyActivity.smali'
    text=(work/'modified'/name).read_text(encoding='utf-8')
    def texture(m):
        # Insert only on the active path, after the original timestamp assignment.
        marker='    iput-wide v0, p0, Lcom/shilapi/xcertplay/legacy/LegacyActivity;->lastTextureUpdateMs:J'
        return one(m,marker,marker+f'\n    invoke-static {{}}, {G}->texture()V')
    text=edit_method(text,'onSurfaceTextureUpdated(Landroid/graphics/SurfaceTexture;)V',texture)
    write(name,text)
