"""Place a privately obtained input APK into the local build workspace; never publish it."""
from pathlib import Path
import argparse
import hashlib
import shutil
import zipfile

parser=argparse.ArgumentParser()
parser.add_argument('apk',type=Path)
args=parser.parse_args()
root=Path(__file__).resolve().parent.parent
expected='95c194c47fb4cab0fdc75d30b698b3aefeb037386cb5470290112393396a2b68'
assert hashlib.sha256(args.apk.read_bytes()).hexdigest()==expected, 'Input APK does not match the audited EasyPlay 0.2.7(36) build'
work=root/'.private/apk-analysis/easyplay'
work.mkdir(parents=True,exist_ok=True)
target=work/'input.apk'
if args.apk.resolve()!=target.resolve():shutil.copyfile(args.apk,target)
with zipfile.ZipFile(target) as z:
    for name in ['classes.dex','classes2.dex','classes3.dex']:(work/name).write_bytes(z.read(name))
print('Private input prepared; APK and authentication assets must stay outside source uploads.')
