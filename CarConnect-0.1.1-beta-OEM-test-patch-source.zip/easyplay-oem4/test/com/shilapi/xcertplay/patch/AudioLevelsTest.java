package com.shilapi.xcertplay.patch;

import android.media.AudioTrack;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class AudioLevelsTest {
    private final AudioTrack navigation=new AudioTrack(),media=new AudioTrack(),phone=new AudioTrack(),assistant=new AudioTrack();
    @After public void clear() {
        AudioLevels.unregister(navigation);AudioLevels.unregister(media);AudioLevels.unregister(phone);AudioLevels.unregister(assistant);
        AudioLevels.setUserVolumes(100,100);
    }
    @Test public void independentGainsApplyToExistingTracksImmediately() {
        AudioLevels.register(navigation,"NAVIGATION");AudioLevels.register(media,"MEDIA");
        AudioLevels.setUserVolumes(35,80);
        assertEquals(.35f,navigation.left,0);assertEquals(.8f,media.left,0);
        AudioLevels.setUserVolumes(0,60);
        assertEquals(0,navigation.left,0);assertEquals(.6f,media.left,0);
    }
    @Test public void focusDuckAndGainDoNotResetUserVolume() {
        AudioLevels.register(media,"MEDIA");AudioLevels.setUserVolumes(100,50);
        AudioLevels.setStereoVolume(media,.2f,.2f);assertEquals(.1f,media.left,.00001f);
        AudioLevels.setUserVolumes(100,80);assertEquals(.16f,media.left,.00001f);
        AudioLevels.setStereoVolume(media,1,1);assertEquals(.8f,media.left,0);
    }
    @Test public void phoneAndSiriAreUnaffectedByBothSliders() {
        AudioLevels.register(phone,"PHONE");AudioLevels.register(assistant,"ASSISTANT");
        AudioLevels.setUserVolumes(0,0);
        assertEquals(1,phone.left,0);assertEquals(1,assistant.left,0);
    }
    @Test public void newPromptTrackInheritsSavedNavigationGain() {
        AudioLevels.setUserVolumes(40,70);AudioLevels.register(navigation,"NAVIGATION");
        assertEquals(.4f,navigation.left,0);
    }
    @Test public void removedTrackCannotBeChangedByLaterSliderEvents() {
        AudioLevels.register(media,"MEDIA");AudioLevels.unregister(media);
        AudioLevels.setUserVolumes(100,10);assertEquals(1,media.left,0);
    }
    @Test public void releasedTrackRaceDoesNotStopUpdatesToOtherTracks() {
        AudioLevels.register(navigation,"NAVIGATION");AudioLevels.register(media,"MEDIA");media.released=true;
        AudioLevels.setUserVolumes(30,50);assertEquals(.3f,navigation.left,0);
        assertEquals(-3,AudioLevels.setStereoVolume(media,1,1));
    }
    @Test public void invalidPersistedPercentagesAreClampedWithoutAmplification() {
        AudioLevels.setUserVolumes(-500,999);assertEquals(0,AudioLevels.getNavigationVolume());assertEquals(100,AudioLevels.getMediaVolume());
        assertEquals(1,AudioLevels.userGain("MEDIA",-500,999),0);
    }
    @Test public void unregisteredLegacyTrackKeepsItsFocusBehavior() {
        assertEquals(0,AudioLevels.setStereoVolume(phone,.2f,.3f));
        assertEquals(.2f,phone.left,0);assertEquals(.3f,phone.right,0);
    }
}
