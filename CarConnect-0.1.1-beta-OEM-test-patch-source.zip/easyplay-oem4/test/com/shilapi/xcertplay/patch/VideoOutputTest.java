package com.shilapi.xcertplay.patch;
import android.media.MediaCodec;
import android.view.Surface;
import com.shilapi.xcertplay.media.LegacyVideoRenderStats;
import kotlin.jvm.functions.Function1;
import org.junit.Test;
import static org.junit.Assert.*;
public class VideoOutputTest {
    private boolean drain(MediaCodec codec,Surface surface) {
        return VideoOutput.drain(codec,new MediaCodec.BufferInfo(),surface,new LegacyVideoRenderStats(),new Function1<Object,Object>(){
            public Object invoke(Object text){return null;}
        });
    }
    @Test public void newestOutputRenderedAndOlderOutputReleased() {
        MediaCodec c=new MediaCodec();c.ready.add(1);c.ready.add(2);c.ready.add(3);
        assertTrue(drain(c,new Surface()));assertEquals("[1:false, 2:false, 3:true]",c.released.toString());
    }
    @Test public void drainBoundDoesNotStarveInput() {
        MediaCodec c=new MediaCodec();for(int i=0;i<20;i++)c.ready.add(i);
        assertTrue(drain(c,new Surface()));assertEquals(12,c.ready.size());assertEquals("7:true",c.released.get(7));
    }
    @Test public void invalidSurfaceReleasesAllWithoutRendering() {
        MediaCodec c=new MediaCodec();c.ready.add(1);c.ready.add(2);Surface s=new Surface();s.valid=false;
        assertFalse(drain(c,s));assertEquals("[1:false, 2:false]",c.released.toString());
    }
    @Test public void formatEventsDoNotLoseOutputOwnership() {
        MediaCodec c=new MediaCodec();c.ready.add(-2);c.ready.add(1);c.ready.add(-3);c.ready.add(2);
        assertTrue(drain(c,new Surface()));assertEquals("[1:false, 2:true]",c.released.toString());
    }
    @Test public void newOutputIsReturnedWhenOldReleaseFails() {
        MediaCodec c=new MediaCodec();c.ready.add(1);c.ready.add(2);c.throwIndex=1;
        try {drain(c,new Surface());fail();}catch(IllegalStateException expected){}
        assertEquals("[1:false, 2:false]",c.released.toString());
    }
    @Test public void idleDecoderDoesNotProduceFalseProgress() {
        MediaCodec c=new MediaCodec();assertFalse(drain(c,new Surface()));assertTrue(c.released.isEmpty());
    }
}
