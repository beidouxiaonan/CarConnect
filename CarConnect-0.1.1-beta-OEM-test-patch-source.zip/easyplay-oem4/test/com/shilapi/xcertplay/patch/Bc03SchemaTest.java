package com.shilapi.xcertplay.patch;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.junit.Test;
import static org.junit.Assert.*;
public class Bc03SchemaTest {
    private static final String[] N={"isBlueToothPowerOn","isConnectDevice","isConnectHFP","isConnectA2DP","getLocalDeviceName"};
    private Map<String,String> signatures() {
        Map<String,String> s=new HashMap<String,String>();
        for(String n:N)s.put(n,n.equals("getLocalDeviceName")?"()Ljava/lang/String;":"()Z");return s;
    }
    private Map<String,Object> codes() {
        Map<String,Object> c=new HashMap<String,Object>();c.put("DESCRIPTOR","com.bt.BTFeature");
        for(int i=0;i<N.length;i++)c.put("TRANSACTION_"+N[i],i+70);return c;
    }
    @Test public void suppliedOemApkMetadataMatchesVerifiedSchema() throws Exception {
        org.junit.Assume.assumeTrue(new File(".private/vendor-analysis/bc03/input.apk").isFile());
        Bc03Schema s=Bc03Schema.read(".private/vendor-analysis/bc03/input.apk");
        assertEquals(3,s.code(N[0]));assertEquals(10,s.code(N[4]));assertEquals(38,s.code("getConnectDevice"));assertTrue(s.peerLayoutVerified);
    }
    @Test public void changedTransactionNumbersUseActualMap() throws Exception {
        Bc03Schema s=Bc03Schema.validate(signatures(),codes(),false);
        assertEquals(70,s.code(N[0]));assertEquals(74,s.code(N[4]));assertFalse(s.peerLayoutVerified);
    }
    @Test(expected=IOException.class) public void incompatibleSignatureRejected() throws Exception {
        Map<String,String> s=signatures();s.put(N[0],"(I)Z");Bc03Schema.validate(s,codes(),false);
    }
    @Test(expected=IOException.class) public void duplicateTransactionRejected() throws Exception {
        Map<String,Object> c=codes();c.put("TRANSACTION_"+N[1],70);Bc03Schema.validate(signatures(),c,false);
    }
    @Test(expected=IOException.class) public void missingConstantRejected() throws Exception {
        Map<String,Object> c=codes();c.remove("TRANSACTION_"+N[0]);Bc03Schema.validate(signatures(),c,false);
    }
    @Test(expected=IOException.class) public void wrongDescriptorRejected() throws Exception {
        Map<String,Object> c=codes();c.put("DESCRIPTOR","another.Interface");Bc03Schema.validate(signatures(),c,false);
    }
    @Test(expected=IOException.class) public void unverifiedParcelableCannotBeQueried() throws Exception {
        Bc03Schema.validate(signatures(),codes(),false).code("getConnectDevice");
    }
    @Test public void truncatedDexFailsCleanly() throws Exception {
        File f=File.createTempFile("easyplay-schema-",".apk");
        try {
            ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f));
            z.putNextEntry(new ZipEntry("classes.dex"));z.write(new byte[]{1,2,3});z.close();
            try {Bc03Schema.read(f.getAbsolutePath());fail();}catch(IOException expected){}
        } finally {assertTrue(f.delete());}
    }
}
