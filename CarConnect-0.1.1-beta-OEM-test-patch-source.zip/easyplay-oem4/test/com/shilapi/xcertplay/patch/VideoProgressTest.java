package com.shilapi.xcertplay.patch;
import org.junit.Test;
import static org.junit.Assert.*;
public class VideoProgressTest {
    @Test public void staticPictureNeverTriggersRecovery() {
        VideoProgress p=new VideoProgress();p.received(1);p.queued(2);p.released(3,true);
        assertFalse(p.recoveryDue(10000000000L,true));
    }
    @Test public void noNewVideoIsNotMistakenForDecoderStall() {
        VideoProgress p=new VideoProgress();p.received(1);p.queued(2);
        assertFalse(p.recoveryDue(4000000000L,true));
    }
    @Test public void incomingVideoButNoOutputTriggersOnce() {
        VideoProgress p=new VideoProgress();p.queued(1);p.received(3100000000L);
        assertTrue(p.recoveryDue(3200000000L,true));
        assertFalse(p.recoveryDue(3200000001L,true));
        p.queued(3300000000L);p.received(6500000000L);
        assertFalse(p.recoveryDue(6500000000L,true));
        p.received(9000000000L);assertTrue(p.recoveryDue(9000000000L,true));
    }
    @Test public void nativeBlockIsReportedButNeverRacedByFlush() {
        VideoProgress p=new VideoProgress();p.queued(1);p.received(3100000000L);
        p.stage("release-to-surface");p.nativeStarted(2);
        assertFalse(p.recoveryDue(3200000000L,true));
        assertTrue(p.report(3200000000L,true).contains("native=release-to-surface"));
        p.nativeFinished();assertTrue(p.recoveryDue(3200000000L,true));
    }
    @Test public void missingSurfaceNeverTriggersRecovery() {
        VideoProgress p=new VideoProgress();p.queued(1);p.received(3100000000L);
        assertFalse(p.recoveryDue(3200000000L,false));
    }
    @Test public void decoderOutputAndTextureCountersAreSeparate() {
        VideoProgress p=new VideoProgress();p.received(1);p.queued(2);p.released(3,true);
        assertTrue(p.report(4,true).contains("rendered=1 texture=0"));
        p.texture(5);assertTrue(p.report(6,true).contains("rendered=1 texture=1"));
    }
}
