package com.shilapi.xcertplay.patch;

import com.shilapi.xcertplay.airplay.*;
import java.util.*;
import java.util.concurrent.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class TouchDispatcherTest {
    private static List<AirPlayContact> finger(double x, boolean down) {
        return Collections.singletonList(new AirPlayContact(0, x, .5, down));
    }
    private static void await(CountDownLatch latch) throws Exception {
        assertTrue("sender did not finish", latch.await(3, TimeUnit.SECONDS));
    }
    private static class RecordingSink implements TouchDispatcher.Sink {
        final List<List<AirPlayContact>> sent = Collections.synchronizedList(new ArrayList<List<AirPlayContact>>());
        final CountDownLatch entered = new CountDownLatch(1), release = new CountDownLatch(1), failed = new CountDownLatch(1);
        volatile boolean block = true, result = true;
        public boolean send(List<AirPlayContact> contacts) {
            if (block && sent.isEmpty()) {
                entered.countDown();
                while (release.getCount() > 0) {
                    try { release.await(); } catch (InterruptedException ignored) {}
                }
            }
            sent.add(contacts); return result;
        }
        public void log(String message) {}
        public void failed(String message) { failed.countDown(); }
        void count(int n) throws Exception {
            long end = System.nanoTime() + 3000000000L;
            while (sent.size() < n && System.nanoTime() < end) Thread.sleep(2);
            assertEquals(n, sent.size());
        }
    }
    @Test public void tenThousandMovesKeepLatestPositionAndGestureBoundaries() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink);
        try {
            assertTrue(sender.offer(finger(0, true))); await(sink.entered);
            for (int i=1; i<=10000; i++) assertTrue(sender.offer(finger(i / 10000.0, true)));
            assertTrue(sender.offer(finger(1, false)));
            sink.release.countDown(); sink.count(3);
            assertTrue(sink.sent.get(0).get(0).getDown());
            assertEquals(1.0, sink.sent.get(1).get(0).getX(), 0);
            assertFalse(sink.sent.get(2).get(0).getDown());
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void tapCancelAndMultitouchBoundariesStayInOrder() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink);
        List<List<AirPlayContact>> sequence = Arrays.asList(finger(.1, true), finger(.1, false), finger(.2, true),
            Arrays.asList(new AirPlayContact(0,.2,.5,true), new AirPlayContact(1,.3,.6,true)),
            Collections.<AirPlayContact>emptyList(), Collections.singletonList(new AirPlayContact(2,.4,.5,true)));
        try {
            sender.offer(sequence.get(0)); await(sink.entered);
            for (int i=1; i<sequence.size(); i++) assertTrue(sender.offer(sequence.get(i)));
            sink.release.countDown(); sink.count(sequence.size());
            assertEquals(sequence, sink.sent);
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void callerListMutationCannotChangeQueuedReport() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink);
        try {
            sender.offer(finger(.1, true)); await(sink.entered);
            List<AirPlayContact> mutable = new ArrayList<AirPlayContact>(finger(.7, true));
            sender.offer(mutable); mutable.clear(); sink.release.countDown(); sink.count(2);
            assertEquals(.7, sink.sent.get(1).get(0).getX(), 0);
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void fullBoundaryQueueFailsAsynchronouslyWithoutDroppingUp() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink, 2, 5000, 0);
        try {
            sender.offer(finger(.1, true)); await(sink.entered);
            assertTrue(sender.offer(finger(.1, false))); assertTrue(sender.offer(finger(.2, true)));
            assertFalse(sender.offer(finger(.2, false))); await(sink.failed);
            assertFalse(sender.offer(finger(.3, true)));
            sink.release.countDown(); sink.count(1);
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void watchdogStopsBacklogEvenWhenSendIgnoresInterrupt() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink, 32, 50, 0);
        try {
            sender.offer(finger(.1,true)); await(sink.entered); sender.offer(finger(.9,true));
            await(sink.failed); assertFalse(sender.offer(finger(1,false)));
            sink.release.countDown(); sink.count(1);
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void unavailableEventSocketDoesNotDisconnectDuringStartup() throws Exception {
        RecordingSink sink = new RecordingSink(); sink.block = false; sink.result = false;
        TouchDispatcher sender = new TouchDispatcher(sink);
        try {
            sender.offer(finger(.1,true)); sink.count(1);
            sender.offer(finger(.1,false)); sink.count(2);
            assertEquals(1, sink.failed.getCount());
        } finally { sender.close(); }
    }
    @Test public void sendExceptionSealsTheQueueAndSignalsRecovery() throws Exception {
        final CountDownLatch failed = new CountDownLatch(1);
        TouchDispatcher sender = new TouchDispatcher(new TouchDispatcher.Sink() {
            public boolean send(List<AirPlayContact> c) { throw new IllegalStateException("broken socket"); }
            public void log(String message) {}
            public void failed(String message) { failed.countDown(); }
        });
        try {
            sender.offer(finger(.1,true)); await(failed);
            assertFalse(sender.offer(finger(.1,false)));
        } finally { sender.close(); }
    }
    @Test public void movesAreRateLimitedButReleaseFlushesLatestPosition() throws Exception {
        RecordingSink sink = new RecordingSink(); sink.block = false;
        TouchDispatcher sender = new TouchDispatcher(sink);
        try {
            sender.offer(finger(0,true)); sink.count(1);
            for (int i=1; i<=200; i++) { sender.offer(finger(i/200.0,true)); Thread.sleep(1); }
            sender.offer(finger(1,false));
            long end = System.nanoTime() + 1000000000L;
            while (sink.sent.get(sink.sent.size()-1).get(0).getDown() && System.nanoTime() < end) Thread.sleep(2);
            assertFalse(sink.sent.get(sink.sent.size()-1).get(0).getDown());
            assertEquals(1.0, sink.sent.get(sink.sent.size()-2).get(0).getX(), 0);
            assertTrue("move stream still flooded sender: " + sink.sent.size(), sink.sent.size() < 40);
        } finally { sender.close(); }
    }
    @Test public void closeDiscardsBacklogAndRejectsNewGestures() throws Exception {
        RecordingSink sink = new RecordingSink();
        TouchDispatcher sender = new TouchDispatcher(sink);
        try {
            sender.offer(finger(.1,true)); await(sink.entered); sender.offer(finger(.9,true));
            sender.close(); sender.close(); assertFalse(sender.offer(finger(.9,false)));
            sink.release.countDown(); sink.count(1); assertEquals(1,sink.failed.getCount());
        } finally { sink.release.countDown(); sender.close(); }
    }
    @Test public void replacementSessionCannotReceiveOldReports() throws Exception {
        final RecordingSink sink = new RecordingSink();
        AirPlaySession old = new AirPlaySession() {
            @Override public boolean sendTouch(List<AirPlayContact> contacts) { return sink.send(contacts); }
        };
        AirPlaySession next = new AirPlaySession(); TouchBridge bridge = new TouchBridge();
        try {
            bridge.setSession(old); bridge.offer(old,finger(.1,true)); await(sink.entered);
            bridge.offer(old,finger(.9,true)); bridge.setSession(next);
            assertFalse(bridge.offer(old,finger(.9,false))); assertTrue(bridge.offer(next,finger(.2,true)));
            long end = System.nanoTime()+1000000000L;
            while (next.reports.isEmpty() && System.nanoTime()<end) Thread.sleep(2);
            assertEquals(1,next.reports.size()); assertEquals(.2,next.reports.get(0).get(0).getX(),0);
            sink.release.countDown(); sink.count(1);
        } finally { sink.release.countDown(); bridge.close(); }
    }
    @Test public void nullSessionAndClosedControllerCannotAcceptReports() {
        TouchBridge bridge = new TouchBridge(); AirPlaySession session = new AirPlaySession();
        assertFalse(bridge.offer(null,finger(.1,true))); bridge.setSession(session);
        bridge.setSession(null); assertFalse(bridge.offer(session,finger(.2,true)));
        bridge.close(); bridge.setSession(session); assertFalse(bridge.offer(session,finger(.3,true)));
    }
}
