import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

/** Compare canonical bytecode, independently of relocated DEX indices/offsets. */
public class DexAudit {
    private static String canonical(ClassDef c) throws Exception {
        BaksmaliOptions options = new BaksmaliOptions(); options.apiLevel=19; options.sequentialLabels=true;
        StringWriter text = new StringWriter(); BaksmaliWriter writer = new BaksmaliWriter(text);
        ClassDefinition def = new ClassDefinition(options,c); def.writeTo(writer); writer.flush();
        if (def.hadValidationErrors()) throw new Exception("Invalid class " + c.getType());
        // DexWriter may promote a string load when the merged string index exceeds 65535.
        String result=text.toString().replace("const-string/jumbo ", "const-string ");
        // Trailing encoded static default values may be omitted by DexWriter.
        return result.replaceAll("(?m)^(\\.field [^\\r\\n]+?) = (false|0x0|null|0\\.0f?)(?=\\r?$)", "$1");
    }
    private static Map<String,String> methods(String text) {
        Map<String,String> result = new TreeMap<String,String>();
        Matcher matcher = Pattern.compile("(?m)^\\.method ([^\\n]+)\\n.*?^\\.end method", Pattern.DOTALL).matcher(text);
        while (matcher.find()) result.put(matcher.group(1).trim(), matcher.group());
        return result;
    }
    public static void main(String[] args) throws Exception {
        String controller="Lcom/shilapi/xcertplay/orchestration/CarPlayController;";
        String stream="Lcom/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream;";
        String session="Lcom/shilapi/xcertplay/airplay/AirPlaySession;";
        Map<String,ClassDef> target=new TreeMap<String,ClassDef>();
        DexFile original=DexFileFactory.loadDexFile(args[0],Opcodes.forApi(19));
        DexFile patched=DexFileFactory.loadDexFile(args[1],Opcodes.forApi(19));
        for (ClassDef c:patched.getClasses()) target.put(c.getType(),c);
        int unchanged=0,changed=0;
        for (ClassDef c:original.getClasses()) {
            ClassDef p=target.remove(c.getType());
            if (p==null) throw new Exception("Removed class " + c.getType());
            String before=canonical(c),after=canonical(p);
            if (before.equals(after)) {unchanged++;continue;}
            boolean enhancements=c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacyActivity;")
                || c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacySessionService;")
                || c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;")
                || c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyAudioFocus;")
                || c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;")
                || c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;")
                || c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;")
                || c.getType().equals("Lcom/shilapi/xcertplay/legacy/EasyPlayVersionSettings;");
            if (!c.getType().equals(stream) && !c.getType().equals(controller) && !c.getType().equals(session) && !enhancements) {
                java.nio.file.Files.write(java.nio.file.Paths.get(args[1]+".before.smali"),before.getBytes("UTF-8"));
                java.nio.file.Files.write(java.nio.file.Paths.get(args[1]+".after.smali"),after.getBytes("UTF-8"));
                throw new Exception("Unexpected change " + c.getType());
            }
            String beforeHeader=before.substring(0,before.indexOf(".method "));
            String afterHeader=after.substring(0,after.indexOf(".method "));
            afterHeader=afterHeader.replaceAll("(?m)^\\.field private final touchBridge:Lcom/shilapi/xcertplay/patch/TouchBridge;\\r?\\n","");
            afterHeader=afterHeader.replaceAll("(?m)^\\.field private enhancementFps:I\\r?\\n","");
            afterHeader=afterHeader.replaceAll("(?m)^\\.field private patchCodecProduced:Z\\r?\\n", "");
            afterHeader=afterHeader.replace(".field private final patchOwnedSocket:Ljava/io/Closeable;", "");
            if (!beforeHeader.replaceAll("(?m)^\\s*$","").equals(afterHeader.replaceAll("(?m)^\\s*$","")))
                throw new Exception("Unexpected field/class metadata change " + c.getType());
            Map<String,String> oldMethods=methods(before),newMethods=methods(after);
            for (Map.Entry<String,String> m:oldMethods.entrySet()) {
                String newer=newMethods.remove(m.getKey());
                if (m.getValue().equals(newer)) continue;
                String name=m.getKey();
                boolean allowed=c.getType().equals(controller) && (name.startsWith("public constructor <init>(")
                    || name.equals("public close()V") || name.equals("public final sendTouch(Ljava/util/List;)Z")
                    || name.startsWith("public static final synthetic access$setActiveSession$p("));
                allowed|=c.getType().equals(stream) && name.equals("private final closeSocketOnce()Ljava/io/IOException;");
                allowed|=c.getType().equals(controller) && (name.equals("private final runWireless(I)V") || name.equals("private final accessoryBluetoothMac(Landroid/bluetooth/BluetoothAdapter;)Ljava/lang/String;") || name.equals("private final selectWirelessBluetoothDevice(Landroid/bluetooth/BluetoothAdapter;)Landroid/bluetooth/BluetoothDevice;"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacyActivity;") && (name.equals("protected onCreate(Landroid/os/Bundle;)V") || name.equals("public onSurfaceTextureUpdated(Landroid/graphics/SurfaceTexture;)V"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacySessionService;") && (name.startsWith("static final startSession$lambda$46$lambda$43(") || name.equals("public final report()Ljava/lang/String;"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;") && name.equals("private final createTrack()V");
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyAudioFocus;") && (name.equals("public constructor <init>(Landroid/content/Context;ZLkotlin/jvm/functions/Function1;)V")
                    || name.equals("private final applyVolume(Landroid/media/AudioTrack;)V") || name.equals("public final declared-synchronized remove(Landroid/media/AudioTrack;)V"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;") && (name.startsWith("public constructor <init>(")
                    || name.equals("private final reset(Ljava/lang/String;)V") || name.equals("private final run()V")
                    || name.equals("private final feed(Lcom/shilapi/xcertplay/airplay/OwnedVideoFrame;)Z")
                    || name.equals("private final configureCodec()V") || name.equals("public final frame(Lcom/shilapi/xcertplay/airplay/OwnedVideoFrame;)V")
                    || name.equals("public close()V") || name.equals("private final drain(Landroid/media/MediaCodec;)V"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyVideoRenderStats;") && (name.equals("public final declared-synchronized queued()V")
                    || name.equals("public final declared-synchronized released(Z)V") || name.equals("public final declared-synchronized vendorCallStarted()V")
                    || name.equals("public final declared-synchronized vendorCallFinished()V"));
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;") && name.equals("public constructor <init>(Landroid/content/Context;)V");
                allowed|=c.getType().equals("Lcom/shilapi/xcertplay/legacy/EasyPlayVersionSettings;") && (name.equals("public final checkForUpdates()V")
                    || name.equals("public final showVersionHistory()V") || name.equals("private final showUpdateSource()V")
                    || name.equals("public final showAbout()V") || name.equals("private final openDownload(Ljava/lang/String;)V")
                    || name.equals("private final updateUrl()Ljava/lang/String;"));
                if (!allowed)
                    throw new Exception("Unexpected method change " + c.getType() + " " + name);
                changed++; System.out.println("Modified method: " + name);
            }
            for (String name:newMethods.keySet()) {
                if (!(c.getType().equals(stream) && name.equals("public constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/io/Closeable;)V"))
                    && !(c.getType().equals(session) && name.equals("public final touchPatchLog(Ljava/lang/String;)V"))
                    && !(c.getType().equals("Lcom/shilapi/xcertplay/media/LegacyVideoDecoder;") && (name.equals("private final patchCheckProgress()V") || name.equals("private final patchResync(Ljava/lang/String;)V"))))
                    throw new Exception("Unexpected new method " + name);
                System.out.println("Added method: " + name);
            }
        }
        for (ClassDef c:target.values()) {
            if (!c.getType().startsWith("Lcom/shilapi/xcertplay/patch/")) throw new Exception("Unexpected new class " + c.getType());
            canonical(c);
        }
        if (changed!=35) throw new Exception("Expected 35 patched methods; found " + changed);
        if (args.length>2) {
            Map<String,ClassDef> current=new HashMap<String,ClassDef>();
            for(ClassDef c:patched.getClasses()) current.put(c.getType(),c);
            int stable=0;
            for(ClassDef c:DexFileFactory.loadDexFile(args[2],Opcodes.forApi(19)).getClasses()) {
                if(c.getType().equals(controller) || c.getType().equals(session) || c.getType().startsWith("Lcom/shilapi/xcertplay/patch/Touch")) {
                    if(c.getType().equals(controller)) {
                        Map<String,String> old=methods(canonical(c)),now=methods(canonical(current.get(c.getType())));
                        for(String n:old.keySet()) {
                            if(n.equals("private final runWireless(I)V") || n.startsWith("private final accessoryBluetoothMac(") || n.startsWith("private final selectWirelessBluetoothDevice("))continue;
                            if(!old.get(n).equals(now.get(n)))throw new Exception("Stable controller method changed: "+n);
                        }
                    } else if(!canonical(c).equals(canonical(current.get(c.getType())))) throw new Exception("Stable touch patch changed: "+c.getType());
                    stable++;
                }
            }
            if(stable!=10) throw new Exception("Unexpected stable touch class count "+stable);
            System.out.println("Stable touchfix1 implementation unchanged: "+stable+" classes");
        }
        if(args.length>3) {
            Map<String,ClassDef> now=new HashMap<String,ClassDef>();
            for(ClassDef c:patched.getClasses())now.put(c.getType(),c);
            int stableMedia=0;
            for(ClassDef c:DexFileFactory.loadDexFile(args[3],Opcodes.forApi(19)).getClasses()) {
                String name=c.getType();
                if(name.startsWith("Lcom/shilapi/xcertplay/media/") || name.startsWith("Lcom/shilapi/xcertplay/patch/Video")
                    || name.startsWith("Lcom/shilapi/xcertplay/patch/Touch") || name.startsWith("Lcom/shilapi/xcertplay/patch/AudioLevels")) {
                    if(!canonical(c).equals(canonical(now.get(name))))throw new Exception("Published media/touch implementation changed: "+name);
                    stableMedia++;
                }
            }
            System.out.println("Published 0.1.0 media/touch classes unchanged: "+stableMedia);
        }
        System.out.println("AUDIT PASS: unchanged original classes="+unchanged+", patched original classes=11, new patch classes="+target.size());
    }
}
