import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
class ScanBrand {
 public static void main(String[] a)throws Exception{
  for(ClassDef c:DexFileFactory.loadDexFile(a[0],Opcodes.forApi(19)).getClasses()){
   if(!c.getType().startsWith("Lcom/shilapi/xcertplay/"))continue;
   for(Method m:c.getMethods())if(m.getImplementation()!=null)for(Instruction i:m.getImplementation().getInstructions())
    if(i instanceof ReferenceInstruction && ((ReferenceInstruction)i).getReference() instanceof StringReference){
      String s=((StringReference)((ReferenceInstruction)i).getReference()).getString();
      if(s.contains("EasyPlay")||s.equals("DiPlay")||s.startsWith("https://")||s.contains("0.2.7-lynk"))System.out.println(c.getType()+" "+m.getName()+" => "+s.replace('\n',' '));
    }
  }
 }
}
