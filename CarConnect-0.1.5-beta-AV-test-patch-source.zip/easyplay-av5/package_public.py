from pathlib import Path
import hashlib
import zipfile

ROOT=Path(__file__).resolve().parent.parent
module=ROOT/'easyplay-av5'
output=ROOT/'artifacts/CarConnect-0.1.5-beta-AV-test-patch-source.zip'
files=[]
for folder in ['src','test','test-stubs','tools']:
    files.extend((module/folder).rglob('*.java'))
files.extend(module/name for name in ['build.ps1','patch_apk.py','verify_apk.py','package_public.py','README.md','BUILD.zh-CN.md','VERIFICATION.zh-CN.md'])
files.extend(ROOT/name for name in ['LICENSE','easyplay-oem4/CREDITS.md','easyplay-oem4/tools/DexTool.java','easyplay-oem4/patch_brand.py','easyplay-oem4/stubs/kotlin/jvm/functions/Function1.java'])
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(files):
        name=path.relative_to(ROOT).as_posix()
        assert path.is_file() and not any(x in name.split('/') for x in ['.private','build','original','modified','__pycache__'])
        assert path.suffix in ['.java','.py','.ps1','.md'] or path.name=='LICENSE'
        z.write(path,name)
with zipfile.ZipFile(output) as z:assert z.testzip() is None and len(z.namelist())==len(files)
digest=hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix(output.suffix+'.sha256').write_text(digest+'  '+output.name+'\n',encoding='utf-8')
(ROOT/'artifacts/CarConnect-0.1.5-beta-AV-test-使用说明.md').write_text((module/'README.md').read_text(encoding='utf-8'),encoding='utf-8')
print('Source package:',len(files),'allowlisted files,',output.stat().st_size,'bytes; SHA256',digest)
