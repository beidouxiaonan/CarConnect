import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

public class Audit {
    static String canonical(ClassDef c)throws Exception {
        BaksmaliOptions o=new BaksmaliOptions();o.apiLevel=19;o.sequentialLabels=true;
        StringWriter s=new StringWriter();BaksmaliWriter w=new BaksmaliWriter(s);ClassDefinition d=new ClassDefinition(o,c);d.writeTo(w);w.flush();
        if(d.hadValidationErrors())throw new Exception("Invalid class "+c.getType());
        return s.toString().replace("const-string/jumbo ","const-string ").replaceAll("(?m)^(\\.field [^\\r\\n]+?) = (false|0x0|null|0\\.0f?)(?=\\r?$)","$1");
    }
    static Map<String,String> methods(String s){
        Map<String,String> r=new TreeMap<>();Matcher m=Pattern.compile("(?m)^\\.method ([^\\n]+)\\n.*?^\\.end method",Pattern.DOTALL).matcher(s);
        while(m.find())r.put(m.group(1).trim(),m.group());return r;
    }
    public static void main(String[] a)throws Exception{
        Map<String,ClassDef> now=new TreeMap<>();for(ClassDef c:DexFileFactory.loadDexFile(a[1],Opcodes.forApi(19)).getClasses())now.put(c.getType(),c);
        String old="Carplay-connect-0.1.4-beta-OEM-test",version="Carplay-connect-0.1.5-beta-AV-test";
        Set<String> changes=new TreeSet<>();int unchanged=0;
        for(ClassDef c:DexFileFactory.loadDexFile(a[0],Opcodes.forApi(19)).getClasses()){
            ClassDef n=now.remove(c.getType());if(n==null)throw new Exception("Removed "+c.getType());
            String before=canonical(c),after=canonical(n);if(before.equals(after)){unchanged++;continue;}
            String type=c.getType();changes.add(type);
            String oldHeader=before.substring(0,before.indexOf(".method ")).replace(old,version);
            String newHeader=after.substring(0,after.indexOf(".method "));
            if(!oldHeader.equals(newHeader))throw new Exception("Unexpected class metadata change "+type);
            Map<String,String> bm=methods(before),nm=methods(after);
            for(String name:bm.keySet()){
                String updated=nm.remove(name);if(updated==null)throw new Exception("Removed method "+type+name);
                if(bm.get(name).replace(old,version).replace("CarConnect 0.1.4 beta","CarConnect 0.1.5 beta").equals(updated))continue;
                boolean allowed=type.endsWith("/LegacyAudioRenderer;")&&(name.equals("private final createTrack()V")||name.equals("private final run()V"));
                allowed|=type.endsWith("/AudioStream;")&&name.startsWith("private final runData(");
                allowed|=type.endsWith("/LegacyActivity;")&&name.equals("private final render()V");
                allowed|=type.endsWith("/EnhancementPanel;")&&name.equals("private static showDiagnostics(Landroid/app/Activity;)V");
                if(!allowed)throw new Exception("Unexpected method change "+type+name);
                System.out.println("Changed "+type+" "+name);
            }
            for(String name:nm.keySet()){
                boolean allowed=type.endsWith("/LegacyActivity;")&&Arrays.asList("protected onResume()V","protected onPause()V","public onWindowFocusChanged(Z)V").contains(name);
                allowed|=type.endsWith("/LegacyAudioRenderer;")&&name.equals("private final patchAudioIdle()V");
                if(!allowed)throw new Exception("Unexpected new method "+type+name);
            }
        }
        Set<String> expected=new TreeSet<>();for(String s:new String[]{"media/LegacyAudioRenderer","airplay/AudioStream","legacy/LegacyActivity","legacy/LegacyConnectionScreen","legacy/LegacySessionService","patch/EnhancementPanel","patch/CarConnectInfo"})expected.add("Lcom/shilapi/xcertplay/"+s+";");
        if(!changes.equals(expected))throw new Exception("Unexpected changed classes "+changes);
        Set<String> newExpected=new TreeSet<>();for(String s:new String[]{"PcmBufferState","StableAudioTrack","AudioRuntime","FullscreenRecovery","FullscreenRecovery$Controller","AvDiagnostics","AvDiagnostics$1"})newExpected.add("Lcom/shilapi/xcertplay/patch/"+s+";");
        if(!now.keySet().equals(newExpected))throw new Exception("Unexpected added classes "+now.keySet());
        for(ClassDef c:now.values())canonical(c);
        System.out.println("Unchanged baseline classes="+unchanged+" changed="+changes.size()+" added="+now.size()+"; USB/NCM, OEM Bluetooth, video and touch bytecode unchanged");
    }
}
