from pathlib import Path
import hashlib
import importlib.util
import json
import re
import struct
import sys
import zipfile

ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'.private/apk-analysis/easyplay/av5'
BASE=ROOT/'artifacts/CarConnect-0.1.4-beta-OEM-test-Android4.2.apk'
BASE_HASH='dfccdeb5172d61840d5323a1857e3fe280d8b6c29ef30fe3ab6b937cb0871312'
VERSION='Carplay-connect-0.1.5-beta-AV-test'
spec=importlib.util.spec_from_file_location('brand',ROOT/'easyplay-oem4/patch_brand.py')
brand=importlib.util.module_from_spec(spec);spec.loader.exec_module(brand)
P='Lcom/shilapi/xcertplay/patch/'
CLASSES=['com/shilapi/xcertplay/'+x for x in [
    'media/LegacyAudioRenderer','airplay/AudioStream','legacy/LegacyActivity',
    'legacy/LegacyConnectionScreen','legacy/LegacySessionService',
    'patch/EnhancementPanel','patch/CarConnectInfo']]

def one(text,old,new):
    assert text.count(old)==1,(old,text.count(old))
    return text.replace(old,new)

def edit(text,signature,change):
    pat=r'^\.method [^\n]*'+re.escape(signature)+r'\n.*?^\.end method'
    matches=list(re.finditer(pat,text,re.M|re.S));assert len(matches)==1,signature
    m=matches[0];return text[:m.start()]+change(m[0])+text[m.end():]

def prepare():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest()==BASE_HASH,'Expected unmodified published 0.1.4 baseline'
    WORK.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(BASE) as z:(WORK/'base.dex').write_bytes(z.read('classes3.dex'))

def patch():
    for name in CLASSES:
        text=(WORK/'original'/(name+'.smali')).read_text(encoding='utf-8')
        if name.endswith('LegacyAudioRenderer'):
            def track(m):
                m=one(m,'new-instance v5, Landroid/media/AudioTrack;',f'new-instance v5, {P}StableAudioTrack;')
                m=one(m,'invoke-direct/range {v5 .. v11}, Landroid/media/AudioTrack;-><init>(IIIIII)V',
                    f'invoke-direct/range {{v5 .. v11}}, {P}StableAudioTrack;-><init>(IIIIII)V')
                m=one(m,'    invoke-virtual {v5}, Landroid/media/AudioTrack;->play()V',f'''
    iget-object v0, v1, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->selection:Lcom/shilapi/xcertplay/media/AudioChannelSelection;
    invoke-virtual {{v0}}, Lcom/shilapi/xcertplay/media/AudioChannelSelection;->getChannel()Lcom/shilapi/xcertplay/media/AudioChannel;
    move-result-object v0
    invoke-virtual {{v0}}, Ljava/lang/Enum;->name()Ljava/lang/String;
    move-result-object v0
    iget v7, v1, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->mediaBufferMillis:I
    iget-object v9, v1, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->report:Lkotlin/jvm/functions/Function1;
    invoke-static {{v5, v0, v7, v9}}, {P}AudioRuntime;->prepare(Landroid/media/AudioTrack;Ljava/lang/String;ILkotlin/jvm/functions/Function1;)V''')
                return one(m,'    invoke-virtual {v5}, Landroid/media/AudioTrack;->getPlayState()I',
                    f'    invoke-static {{v5}}, {P}AudioRuntime;->readyPlayState(Landroid/media/AudioTrack;)I')
            text=edit(text,'createTrack()V',track)
            def run(m):
                m=one(m,'    .registers 26','    .registers 26\n\n'+f'    invoke-static {{}}, {P}AudioRuntime;->workerPriority()V')
                return one(m,'    :cond_18e','    :cond_18e\n'+
                    '    invoke-direct {v1}, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->patchAudioIdle()V')
            text=edit(text,'run()V',run)
            text+=f'''
.method private final patchAudioIdle()V
    .registers 2
    iget-object v0, p0, Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;->track:Landroid/media/AudioTrack;
    invoke-static {{v0}}, {P}AudioRuntime;->idle(Landroid/media/AudioTrack;)V
    return-void
.end method
'''
        elif name.endswith('AudioStream'):
            text=edit(text,'runData(Ljava/net/DatagramSocket;Lcom/shilapi/xcertplay/airplay/AudioStream$Listener;)V',
                lambda m:re.sub(r'(    \.registers \d+)',r'\1\n\n    invoke-static {}, '+P+'AudioRuntime;->receivePriority()V',m,count=1))
        elif name.endswith('LegacyActivity'):
            # Existing Activity has no resume/pause/focus override. Added methods invoke the same superclass.
            for signature in ['onResume()V','onPause()V','onWindowFocusChanged(Z)V']:
                assert not re.search(r'^\.method [^\n]*'+re.escape(signature)+r'$',text,re.M),signature
            text+=f'''
.method protected onResume()V
    .registers 1
    invoke-super {{p0}}, Landroid/app/Activity;->onResume()V
    invoke-static {{p0}}, {P}FullscreenRecovery;->resumed(Landroid/app/Activity;)V
    return-void
.end method

.method protected onPause()V
    .registers 1
    invoke-static {{p0}}, {P}FullscreenRecovery;->paused(Landroid/app/Activity;)V
    invoke-super {{p0}}, Landroid/app/Activity;->onPause()V
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .registers 2
    invoke-super {{p0, p1}}, Landroid/app/Activity;->onWindowFocusChanged(Z)V
    invoke-static {{p0, p1}}, {P}FullscreenRecovery;->focused(Landroid/app/Activity;Z)V
    return-void
.end method
'''
            def render(m):
                m=one(m,'    if-nez v3, :cond_c8',f'''    if-nez v3, :cond_c8
    const/4 v3, 0x1
    invoke-static {{p0, v3}}, {P}FullscreenRecovery;->carPlay(Landroid/app/Activity;Z)V''')
                return one(m,'    :cond_c8',f'''    :cond_c8
    const/4 v3, 0x0
    invoke-static {{p0, v3}}, {P}FullscreenRecovery;->carPlay(Landroid/app/Activity;Z)V''')
            text=edit(text,'render()V',render)
        elif name.endswith('EnhancementPanel'):
            def diagnostics(m):
                # At this call site v0 is the LinearLayout, p0 is the Activity; v1 is the ScrollView.
                marker='    const-string v2, "\\u89c6\\u9891\\u72b6\\u6001"'
                return one(m,marker,f'    invoke-static {{p0, v0}}, {P}AvDiagnostics;->append(Landroid/app/Activity;Landroid/widget/LinearLayout;)V\n'+marker)
            text=edit(text,'showDiagnostics(Landroid/app/Activity;)V',diagnostics)
        text=text.replace('Carplay-connect-0.1.4-beta-OEM-test',VERSION).replace('CarConnect 0.1.4 beta','CarConnect 0.1.5 beta')
        path=WORK/'modified'/(name+'.smali');path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')

def manifest(data):
    data=bytearray(brand.binary_replace(data,{'Carplay-connect-0.1.4-beta-OEM-test':VERSION}))
    at=struct.unpack_from('<H',data,2)[0];names=None;changed=0
    while at<len(data):
        kind,header,size=struct.unpack_from('<HHI',data,at)
        if kind==1:names=brand.strings(data[at:at+size])
        elif kind==0x102:
            start,span,count=struct.unpack_from('<HHH',data,at+24)
            for i in range(count):
                pos=at+16+start+i*span
                if names[struct.unpack_from('<I',data,pos+4)[0]]=='versionCode':
                    assert struct.unpack_from('<I',data,pos+16)[0]==41
                    struct.pack_into('<I',data,pos+16,42);changed+=1
        at+=size
    assert changed==1
    return bytes(data)

def repack():
    def signing(name):
        n=name.upper();return n.startswith('META-INF/') and (n.endswith(('.RSA','.DSA','.EC','.SF')) or n=='META-INF/MANIFEST.MF')
    with zipfile.ZipFile(BASE) as src,zipfile.ZipFile(WORK/'unsigned.apk','w') as dst:
        for info in src.infolist():
            if signing(info.filename):continue
            data=src.read(info.filename)
            if info.filename=='classes3.dex':data=(WORK/'patched.dex').read_bytes()
            elif info.filename=='AndroidManifest.xml':data=manifest(data)
            elif info.filename=='assets/easyplay/about.html':
                data=data.decode().replace('Carplay-connect-0.1.4-beta-OEM-test',VERSION).replace('</p>',
                    '</p><p>0.1.5 音频与全屏测试：媒体预缓冲与断流恢复，音频工作/接收线程调度优化，手动启动及窗口焦点恢复时重新请求全屏。尚未经目标车机验证；厂商独立悬浮 Dock 可能需要额外适配。</p>',1).encode()
            elif info.filename=='assets/easyplay/releases.json':
                old=json.loads(data);old.insert(0,{'versionCode':42,'versionName':VERSION,'publishedAt':'2026-10-07',
                    'notesHtml':'<p>媒体预缓冲、断流恢复、音频线程调度；手动启动/进入 CarPlay/窗口焦点恢复时重新请求隐藏系统栏。本测试尚待车机验证。</p>'})
                data=json.dumps(old,ensure_ascii=False,indent=2).encode()
            dst.writestr(info,data)
    print('Repacked AV/fullscreen test from fixed 0.1.4 baseline')

if __name__=='__main__':globals()[sys.argv[1]]()
