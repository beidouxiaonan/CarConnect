param([string]$PythonPath='D:/Program Files/Python3.13.13/python.exe')
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath("$PSScriptRoot/..")
$work="$root/.private/apk-analysis/easyplay/av5"
$patchRoot=$PSScriptRoot
$java="$root/.tooling/jdk25/bin/java.exe"
$javac="$root/.tooling/jdk25/bin/javac.exe"
$jar="$root/.tooling/jdk25/bin/jar.exe"
$android="$root/.tooling/platform/android-4.2.2/android.jar"
$bt="$root/.tooling/build-tools/android-15"
$jadx="$root/.tooling/jadx/lib/jadx-1.5.6-all.jar"
function Run([string]$stage,[scriptblock]$block) {
    $prev=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $lines=& $block 2>&1; $code=$LASTEXITCODE } finally { $ErrorActionPreference=$prev }
    foreach($line in $lines) { Write-Output "$line" }
    if($code -ne 0) { throw "$stage failed: $code" }
}
Push-Location $root
try {
    New-Item -ItemType Directory -Force "$patchRoot/build/classes","$patchRoot/build/stubs","$patchRoot/build/tests","$patchRoot/build/fakes","$patchRoot/build/dex" | Out-Null
    Run 'Baseline hash/extract' { & $PythonPath "$patchRoot/patch_apk.py" prepare }
    # Only these freshly generated directories are cleared; baseline and inspection outputs remain intact.
    foreach($name in @('original','modified')) {
        $target=[IO.Path]::GetFullPath("$work/$name")
        if([IO.Path]::GetDirectoryName($target) -ne [IO.Path]::GetFullPath($work) -or
            -not $target.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe generated path' }
        if(Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    }
    $selected=@('Lcom/shilapi/xcertplay/media/LegacyAudioRenderer;','Lcom/shilapi/xcertplay/airplay/AudioStream;','Lcom/shilapi/xcertplay/legacy/LegacyActivity;','Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;','Lcom/shilapi/xcertplay/legacy/LegacySessionService;','Lcom/shilapi/xcertplay/patch/EnhancementPanel;','Lcom/shilapi/xcertplay/patch/CarConnectInfo;')
    Run 'Disassemble selected baseline classes' { & $java -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" dis "$work/base.dex" "$work/original" @selected }
    $sources=@(Get-ChildItem "$patchRoot/src" -Recurse -Filter '*.java' | ForEach-Object FullName)
    Run 'Compile Kotlin interface stub' { & $javac --release 8 -d "$patchRoot/build/stubs" "$root/easyplay-oem4/stubs/kotlin/jvm/functions/Function1.java" }
    Run 'Compile against Android API17' { & $javac --release 8 -encoding UTF-8 -cp "$android;$patchRoot/build/stubs" -d "$patchRoot/build/classes" @sources }
    $fakes=@(Get-ChildItem "$patchRoot/test-stubs" -Recurse -Filter '*.java' | ForEach-Object FullName)
    Run 'Compile JVM fakes' { & $javac --release 8 -d "$patchRoot/build/fakes" @fakes }
    $cp="$patchRoot/build/fakes;$patchRoot/build/classes;$patchRoot/build/stubs;$root/.tooling/test-libs/junit.jar;$root/.tooling/test-libs/hamcrest.jar;$android"
    $tests=@(Get-ChildItem "$patchRoot/test" -Recurse -Filter '*.java' | ForEach-Object FullName)
    Run 'Compile regression tests' { & $javac --release 8 -encoding UTF-8 -cp $cp -d "$patchRoot/build/tests" @tests }
    Run 'Audio/fullscreen regressions' { & $java -cp "$cp;$patchRoot/build/tests" org.junit.runner.JUnitCore com.shilapi.xcertplay.patch.AudioBufferTest com.shilapi.xcertplay.patch.FullscreenTest }
    Run 'Jar helpers' { & $jar --create --file "$patchRoot/build/helpers.jar" -C "$patchRoot/build/classes" . }
    Run 'Jar stubs' { & $jar --create --file "$patchRoot/build/stubs.jar" -C "$patchRoot/build/stubs" . }
    Run 'DEX API17' { & $java -cp "$bt/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 17 --lib $android --classpath "$patchRoot/build/stubs.jar" --output "$patchRoot/build/dex" "$patchRoot/build/helpers.jar" }
    Run 'Patch selected classes' { & $PythonPath "$patchRoot/patch_apk.py" patch }
    Run 'Assemble' { & $java -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" asm "$work/modified" "$work/overlay.dex" }
    Run 'Merge' { & $java -Xmx1g -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" merge "$work/patched.dex" "$work/base.dex" "$work/overlay.dex" "$patchRoot/build/dex/classes.dex" }
    Run 'Untouched class audit' { & $java -Xmx1g -cp $jadx "$patchRoot/tools/Audit.java" "$work/base.dex" "$work/patched.dex" }
    Run 'Repack' { & $PythonPath "$patchRoot/patch_apk.py" repack }
    Run 'Align' { & "$bt/zipalign.exe" -f 4 "$work/unsigned.apk" "$work/aligned.apk" }
    $apk="$root/artifacts/CarConnect-0.1.5-beta-AV-test-Android4.2-4.4.apk"
    Run 'Sign V1 only' { & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" sign --ks "$root/.private/kitkat-probe-debug.jks" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --min-sdk-version 17 --v1-signing-enabled true --v2-signing-enabled false --v3-signing-enabled false --v4-signing-enabled false --out $apk "$work/aligned.apk" }
    Run 'API17 signature check' { & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" verify --verbose --print-certs --min-sdk-version 17 $apk }
    Run 'Alignment check' { & "$bt/zipalign.exe" -c 4 $apk }
    Run 'Payload check' { & $PythonPath "$patchRoot/verify_apk.py" }
    # dump badging cannot resolve this baseline's framework icon without the platform resources.
    # xmltree checks the manifest directly; no application icon or resources are changed here.
    Run 'Manifest check' { & "$bt/aapt.exe" dump xmltree $apk AndroidManifest.xml }
    Write-Output "Output: $apk"
} finally { Pop-Location }
