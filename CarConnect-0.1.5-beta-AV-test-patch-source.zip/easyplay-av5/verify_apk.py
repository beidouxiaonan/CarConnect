from pathlib import Path
import hashlib
import importlib.util
import struct
import zipfile

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('patch',ROOT/'easyplay-av5/patch_apk.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
APK=ROOT/'artifacts/CarConnect-0.1.5-beta-AV-test-Android4.2-4.4.apk'
allowed={'classes3.dex','AndroidManifest.xml','assets/easyplay/about.html','assets/easyplay/releases.json'}
def signing(name):
    n=name.upper();return n.startswith('META-INF/') and (n.endswith(('.RSA','.DSA','.EC','.SF')) or n=='META-INF/MANIFEST.MF')
with zipfile.ZipFile(p.BASE) as base,zipfile.ZipFile(APK) as out:
    assert out.testzip() is None
    original={x for x in base.namelist() if not signing(x)}
    final={x for x in out.namelist() if not signing(x)}
    assert original==final,'Payload entry change'
    changed={x for x in original if base.read(x)!=out.read(x)}
    assert changed==allowed,changed
    for dex in ['classes.dex','classes2.dex','classes3.dex']:
        assert out.read(dex)[:8]==b'dex\n035\0'
    libs=[n for n in final if n.startswith('lib/') and n.endswith('.so')]
    assert len(libs)==3 and all(n.startswith('lib/armeabi-v7a/') for n in libs),libs
    for n in libs:
        elf=out.read(n);assert elf[:5]==b'\x7fELF\x01' and struct.unpack_from('<H',elf,18)[0]==40
    assert out.read('AndroidManifest.xml')==p.manifest(base.read('AndroidManifest.xml'))
    assert b'Carplay-connect-0.1.5-beta-AV-test' in out.read('assets/easyplay/about.html')
digest=hashlib.sha256(APK.read_bytes()).hexdigest()
(APK.with_suffix(APK.suffix+'.sha256')).write_text(digest+'  '+APK.name+'\n',encoding='utf-8')
print('ZIP CRC, DEX035, ARMv7 ELF32, original native/assets and classes1/2 preserved; changed payload=',sorted(changed))
print('SHA256',digest)
