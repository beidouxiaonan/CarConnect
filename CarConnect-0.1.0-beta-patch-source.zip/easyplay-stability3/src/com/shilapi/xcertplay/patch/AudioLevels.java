package com.shilapi.xcertplay.patch;

import android.media.AudioTrack;
import java.util.Map;
import java.util.WeakHashMap;

/** Per-track gain multiplied by the original focus attenuation, never system-wide volume. */
public final class AudioLevels {
    private static final class Entry {
        final String channel;
        float left = 1, right = 1;
        Entry(String channel) { this.channel = channel; }
    }
    private static final Map<AudioTrack, Entry> tracks = new WeakHashMap<AudioTrack, Entry>();
    private static int navigation = 100, media = 100;
    public static synchronized void register(AudioTrack track, String channel) {
        if (track == null) return;
        Entry entry = new Entry(channel);
        tracks.put(track, entry); apply(track, entry);
    }
    public static synchronized void unregister(AudioTrack track) { tracks.remove(track); }
    public static synchronized int setStereoVolume(AudioTrack track, float left, float right) {
        Entry entry = tracks.get(track);
        if (entry == null) { entry = new Entry(null); tracks.put(track, entry); }
        entry.left = clampGain(left); entry.right = clampGain(right);
        return apply(track, entry);
    }
    public static synchronized void setUserVolumes(int navigationPercent, int mediaPercent) {
        navigation = clampPercent(navigationPercent); media = clampPercent(mediaPercent);
        for (Map.Entry<AudioTrack, Entry> track : tracks.entrySet()) apply(track.getKey(), track.getValue());
    }
    public static synchronized int getNavigationVolume() { return navigation; }
    public static synchronized int getMediaVolume() { return media; }
    public static int clampPercent(int value) { return Math.max(0, Math.min(100, value)); }
    private static float clampGain(float value) { return Float.isNaN(value) ? 1 : Math.max(0, Math.min(1, value)); }
    public static float userGain(String channel, int navigation, int media) {
        if ("NAVIGATION".equals(channel)) return clampPercent(navigation) / 100f;
        if ("MEDIA".equals(channel)) return clampPercent(media) / 100f;
        return 1; // Phone and Siri remain governed by their original audio routing/focus.
    }
    private static int apply(AudioTrack track, Entry entry) {
        try {
            float user = userGain(entry.channel, navigation, media);
            return track.setStereoVolume(entry.left * user, entry.right * user);
        } catch (RuntimeException ignored) { return -3; } // Track may be concurrently shutting down.
    }
}
