package com.shilapi.xcertplay.patch;

import android.media.MediaCodec;
import android.view.Surface;
import com.shilapi.xcertplay.media.LegacyVideoRenderStats;
import kotlin.jvm.functions.Function1;

/** Decode every reference frame, but only display the newest available output in each batch. */
public final class VideoOutput {
    public static boolean drain(MediaCodec codec,MediaCodec.BufferInfo info,Surface surface,
                                LegacyVideoRenderStats stats,Function1 report) {
        int held=-1;
        try {
            for(int i=0;i<8;i++) {
                VideoGuard.stage(stats,"dequeue-output"); stats.vendorCallStarted();
                int index;
                try { index=codec.dequeueOutputBuffer(info,0); } finally { stats.vendorCallFinished(); }
                if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    report.invoke("legacy output "+codec.getOutputFormat()); continue;
                }
                if(index==MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED)continue;
                if(index<0)break;
                // Keep ownership of the newest index even if releasing the previous one throws.
                int previous=held; held=index;
                if(previous>=0)release(codec,previous,false,stats);
            }
            if(held<0)return false;
            int index=held; held=-1;
            boolean render=surface!=null&&surface.isValid();
            release(codec,index,render,stats); return render;
        } finally {
            if(held>=0) { try { release(codec,held,false,stats); } catch(Exception ignored) {} }
        }
    }
    private static void release(MediaCodec codec,int index,boolean render,LegacyVideoRenderStats stats) {
        VideoGuard.stage(stats,render?"release-to-surface":"release-old-output"); stats.vendorCallStarted();
        try { codec.releaseOutputBuffer(index,render); } finally { stats.vendorCallFinished(); }
        stats.released(render);
    }
}
