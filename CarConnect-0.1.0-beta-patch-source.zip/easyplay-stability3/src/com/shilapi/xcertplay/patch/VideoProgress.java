package com.shilapi.xcertplay.patch;

/** Progress uses monotonic nanoseconds; a static picture is never a decoder stall. */
public final class VideoProgress {
    private long received, queued, decoded, rendered, textures;
    private long lastReceive, lastQueue, lastDecode, lastTexture, pendingSince;
    private long nativeStart, lastRecovery = Long.MIN_VALUE, window;
    private boolean nativeActive;
    private String stage = "idle";
    public synchronized void received(long now) { received++; lastReceive=now; }
    public synchronized void queued(long now) {
        queued++; lastQueue=now;
        if (pendingSince==0) pendingSince=now;
    }
    public synchronized void released(long now,boolean render) {
        decoded++; lastDecode=now; pendingSince=0;
        if (render) rendered++;
    }
    public synchronized void texture(long now) { textures++; lastTexture=now; }
    public synchronized void stage(String value) { stage=value; }
    public synchronized void nativeStarted(long now) { nativeActive=true; nativeStart=now; }
    public synchronized void nativeFinished() { nativeActive=false; }
    public synchronized void reset() { pendingSince=0; }
    public synchronized boolean recoveryDue(long now,boolean usable) {
        // Only the decoder worker may flush. Never race a blocked native operation.
        if (!usable || nativeActive || pendingSince==0 || now-pendingSince<3000000000L
            || received==0 || now-lastReceive>1500000000L) return false;
        if (lastRecovery!=Long.MIN_VALUE && now-lastRecovery<5000000000L) return false;
        lastRecovery=now; pendingSince=0; return true;
    }
    public synchronized String report(long now,boolean force) {
        if (!force && now-window<5000000000L) return null;
        window=now;
        return "VideoHealth received="+received+" queued="+queued+" decoded="+decoded
            +" rendered="+rendered+" texture="+textures+" receiveAgeMs="+age(now,lastReceive,received)
            +" decodeAgeMs="+age(now,lastDecode,decoded)+" textureAgeMs="+age(now,lastTexture,textures)
            +" native="+(nativeActive?stage:"idle")+" nativeAgeMs="+(nativeActive?(now-nativeStart)/1000000:0);
    }
    private static long age(long now,long at,long count) { return count==0?-1:Math.max(0,(now-at)/1000000); }
}
