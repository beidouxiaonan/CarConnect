package com.shilapi.xcertplay.patch;

import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Read-only adapters selected by the actual service and verified Binder schema. */
public final class VendorBluetoothStatus {
    private static final String BC03 = "com.bt.BTFeature";
    private static final AtomicBoolean busy = new AtomicBoolean();
    public interface Adapter { String read(Context context) throws Exception; }

    public static void refresh(Context context, TextView target) {
        if (!busy.compareAndSet(false,true)) { target.setText("蓝牙接口仍在读取中，请稍后重试"); return; }
        final Context app = context.getApplicationContext();
        final WeakReference<TextView> view = new WeakReference<TextView>(target);
        final Handler main = new Handler(Looper.getMainLooper());
        final AtomicBoolean delivered = new AtomicBoolean();
        target.setText("正在读取原车蓝牙…");
        final Runnable timeout = new Runnable() {
            public void run() {
                if (!delivered.compareAndSet(false,true)) return;
                TextView text = view.get();
                if (text != null) text.setText("原车蓝牙接口读取超时；画面和声音不受影响。接口尚未返回时不会重复启动读取。");
            }
        };
        main.postDelayed(timeout,8000);
        Thread thread = new Thread(new Runnable() {
            public void run() {
                String result;
                try { result = read(app); }
                catch (Exception error) { result = "读取失败：" + error.getClass().getSimpleName() + " " + error.getMessage(); }
                final String message = result;
                busy.set(false);
                main.post(new Runnable() {
                    public void run() {
                        if (!delivered.compareAndSet(false,true)) return;
                        main.removeCallbacks(timeout);
                        TextView text = view.get(); if (text != null) text.setText(message);
                    }
                });
            }
        },"easyplay-bluetooth-status");
        thread.setDaemon(true); thread.start();
    }

    private static String read(Context context) throws Exception {
        StringBuilder notes = new StringBuilder();
        if (installed(context,"com.bt.bc03")) {
            try { return new Bc03Adapter().read(context); }
            catch (Exception error) { notes.append("BC03：").append(error.getMessage()).append('\n'); }
        }
        if (installed(context,"com.goodocom.gocsdk")) {
            try { return notes + new GocAdapter().read(context); }
            catch (Exception error) { notes.append("GocSdk：").append(error.getMessage()).append('\n'); }
        }
        if (installed(context,"com.hsae.bluetoothservice"))
            notes.append("检测到 HSAE 服务；需要该版本的 AIDL 才能接入原车状态。\n");
        return notes + new PlatformAdapter().read(context);
    }
    private static boolean installed(Context context,String name) {
        try { context.getPackageManager().getPackageInfo(name,0); return true; }
        catch (PackageManager.NameNotFoundException ignored) { return false; }
    }
    private static String text(String value) {
        if (value == null || value.trim().length() == 0) return "未上报";
        value = value.trim(); return value.length() > 128 ? value.substring(0,128) : value;
    }

    private static final class Binding implements ServiceConnection {
        final Context context;
        final CountDownLatch ready = new CountDownLatch(1);
        volatile IBinder binder;
        boolean bound;
        Binding(Context context,String packageName,String service) throws Exception {
            this.context = context;
            Intent intent = new Intent().setComponent(new ComponentName(packageName,service));
            // No AUTO_CREATE: observe an already running OEM service; do not boot/reset the module.
            bound = context.bindService(intent,this,0);
            if (!bound) throw new Exception("服务未运行或不可绑定");
        }
        IBinder get() throws Exception {
            if (!ready.await(1500,TimeUnit.MILLISECONDS) || binder == null) throw new Exception("绑定超时");
            return binder;
        }
        public void onServiceConnected(ComponentName name,IBinder binder) { this.binder=binder; ready.countDown(); }
        public void onServiceDisconnected(ComponentName name) { binder=null; ready.countDown(); }
        void close() { if (bound) { bound=false; try { context.unbindService(this); } catch (Exception ignored) {} } }
    }

    private static Parcel call(IBinder binder,String descriptor,int code,String argument,IBinder callback) throws Exception {
        Parcel data=Parcel.obtain(),reply=Parcel.obtain();
        try {
            data.writeInterfaceToken(descriptor);
            if (argument != null) data.writeString(argument);
            if (callback != null) data.writeStrongBinder(callback);
            if (!binder.transact(code,data,reply,0)) throw new Exception("接口未实现查询 " + code);
            reply.readException(); return reply;
        } catch (Exception error) { reply.recycle(); throw error; }
        finally { data.recycle(); }
    }
    private static boolean bool(IBinder binder,int code) throws Exception {
        Parcel reply=call(binder,BC03,code,null,null);
        try { return reply.readInt()!=0; } finally { reply.recycle(); }
    }

    private static final class Bc03Adapter implements Adapter {
        public String read(Context context) throws Exception {
            String version=context.getPackageManager().getPackageInfo("com.bt.bc03",0).versionName;
            Bc03Schema schema=Bc03Schema.read(context.getPackageManager().getApplicationInfo("com.bt.bc03",0).sourceDir);
            Binding connection=new Binding(context,"com.bt.bc03","com.bt.bc03.BTService");
            try {
                IBinder binder=connection.get();
                if (!BC03.equals(binder.getInterfaceDescriptor())) throw new Exception("Binder 接口不匹配");
                boolean ready=bool(binder,schema.code("isBlueToothPowerOn")),connected=bool(binder,schema.code("isConnectDevice")),
                    hfp=bool(binder,schema.code("isConnectHFP")),music=bool(binder,schema.code("isConnectA2DP"));
                Parcel nameReply=call(binder,BC03,schema.code("getLocalDeviceName"),null,null);
                String local;
                try { local=nameReply.readString(); } finally { nameReply.recycle(); }
                String phone="无手机通话连接";
                if ((connected || hfp) && schema.peerLayoutVerified) {
                    Parcel peer=call(binder,BC03,schema.code("getConnectDevice"),null,null);
                    try {
                        if (peer.readInt()!=0) {
                            // BTDevice's parcel layout: address, name, then class/service/pair fields.
                            String address=peer.readString(),name=peer.readString();
                            phone=text(name) + "\n" + (android.bluetooth.BluetoothAdapter.checkBluetoothAddress(address) ? text(address) : "服务地址格式异常");
                        } else phone="通话已连接，服务未上报手机";
                    } finally { peer.recycle(); }
                } else if (connected || hfp) phone="通话已连接；该版本手机信息格式尚未核对";
                else if (music) phone="音乐已连接，服务未上报通话手机";
                return "原车服务：BC03 " + text(version) + "（已核对实际接口）\n蓝牙模块就绪：" + (ready?"是":"否")
                    + "\n车机名称：" + text(local) + "\n通话连接：" + (hfp?"已连接":"未连接")
                    + "｜音乐连接：" + (music?"已连接":"未连接") + "\n手机：" + phone + "\n此项读取原车状态；无线 CarPlay 仍需原车支持 iAP2 数据通道。";
            } finally { connection.close(); }
        }
    }

    private static final class GocAdapter implements Adapter {
        private static final String SERVICE="com.goodocom.gocsdk.IGocsdkService";
        public String read(Context context) throws Exception {
            String version=context.getPackageManager().getPackageInfo("com.goodocom.gocsdk",0).versionName;
            if (!"1.0".equals(version)) throw new Exception("服务版本 " + version + " 与已核对的 1.0 不同");
            Binding connection=new Binding(context,"com.goodocom.gocsdk","com.goodocom.gocsdk.service.GocsdkService");
            IBinder binder=null; GocCallback callback=new GocCallback(); boolean registered=false;
            try {
                binder=connection.get();
                if (!SERVICE.equals(binder.getInterfaceDescriptor())) throw new Exception("Binder 接口不匹配");
                call(binder,SERVICE,1,null,callback).recycle(); registered=true;
                // Read-only queries verified against the user-provided AIDL proxy.
                for (int query:new int[]{32,37,61,62}) call(binder,SERVICE,query,null,null).recycle();
                callback.await();
                return callback.summary();
            } finally {
                if (registered) try { call(binder,SERVICE,2,null,callback).recycle(); } catch (Exception ignored) {}
                connection.close();
            }
        }
    }
    private static final class GocCallback extends Binder {
        private static final String DESCRIPTOR="com.goodocom.gocsdk.IGocsdkCallback";
        String address,name; Integer hfp,av; Boolean hfpConnected,a2dpConnected;
        int received;
        GocCallback() { attachInterface(null,DESCRIPTOR); }
        protected synchronized boolean onTransact(int code,Parcel data,Parcel reply,int flags) throws RemoteException {
            if (code==IBinder.INTERFACE_TRANSACTION) { if(reply!=null) reply.writeString(DESCRIPTOR); return true; }
            if (code<1 || code>51) return super.onTransact(code,data,reply,flags);
            data.enforceInterface(DESCRIPTOR);
            switch (code) {
                case 1: hfpConnected=false; break;
                case 2: hfpConnected=true; break;
                case 19: address=data.readString(); received|=1; break;
                case 20: name=data.readString(); break;
                case 21: hfp=data.readInt(); received|=2; break;
                case 22: av=data.readInt(); received|=4; break;
                case 24: name=data.readString(); received|=8; break;
                case 26: a2dpConnected=true; break;
                case 28: a2dpConnected=false; break;
                default: break; // Unrelated notifications are acknowledged without acting on them.
            }
            notifyAll(); if(reply!=null) reply.writeNoException(); return true;
        }
        synchronized void await() throws InterruptedException {
            long end=System.nanoTime()+1500000000L;
            while (received!=15) { long left=end-System.nanoTime(); if(left<=0) break; wait(Math.max(1,left/1000000L)); }
        }
        synchronized String summary() {
            if (received==0) return "原车服务：GocSdk 1.0\n接口已绑定，未收到状态回调；蓝牙状态暂无法确认。";
            return "原车服务：GocSdk 1.0\n当前设备上报：" + text(name) + "\n" + text(address)
                + "\nHFP 状态码：" + (hfp==null?"未上报":hfp) + "｜音乐状态码：" + (av==null?"未上报":av)
                + "\n通话连接通知：" + flag(hfpConnected) + "｜音乐连接通知：" + flag(a2dpConnected)
                + "\n原车状态码保留原值；地址上报不单独视为连接成功。";
        }
        private static String flag(Boolean b) { return b==null?"未上报":b?"已连接":"未连接"; }
    }

    private static final class PlatformAdapter implements Adapter {
        public String read(final Context context) throws Exception {
            final BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
            if (adapter==null) return "标准蓝牙栈：不可用\n原车服务未能提供状态。";
            if (!adapter.isEnabled()) return "标准蓝牙栈：关闭\n此结果不代表原车外置蓝牙模块也已关闭。";
            final Map<String,String> phones=Collections.synchronizedMap(new LinkedHashMap<String,String>());
            for (final int profile:new int[]{BluetoothProfile.HEADSET,BluetoothProfile.A2DP}) {
                final CountDownLatch ready=new CountDownLatch(1);
                final AtomicBoolean ended=new AtomicBoolean();
                final AtomicReference<BluetoothProfile> available=new AtomicReference<BluetoothProfile>();
                boolean accepted=adapter.getProfileProxy(context,new BluetoothProfile.ServiceListener() {
                    public void onServiceConnected(int type,BluetoothProfile proxy) {
                        boolean late;
                        synchronized (available) {
                            late=ended.get();
                            if (!late) available.set(proxy);
                            ready.countDown();
                        }
                        if (late) {
                            try { adapter.closeProfileProxy(type,proxy); } catch (Exception ignored) {}
                        }
                    }
                    public void onServiceDisconnected(int type) { ready.countDown(); }
                },profile);
                if (accepted) ready.await(1000,TimeUnit.MILLISECONDS);
                BluetoothProfile proxy;
                synchronized (available) { ended.set(true); proxy=available.getAndSet(null); }
                if (proxy!=null) {
                    try {
                        for (BluetoothDevice device:proxy.getConnectedDevices())
                            phones.put(device.getAddress(),text(device.getName()));
                    } catch (Exception ignored) {
                        // Run profile IPC on this background reader, never inside a main-thread callback.
                    } finally { try { adapter.closeProfileProxy(profile,proxy); } catch (Exception ignored) {} }
                }
            }
            StringBuilder result=new StringBuilder("标准蓝牙栈：开启\n车机名称：").append(text(adapter.getName()));
            synchronized (phones) {
                if (phones.isEmpty()) result.append("\n标准栈未查询到已连接手机；原车外置模块可能独立管理连接。\n此名称属于 Android 标准栈，不能代表原车蓝牙；版本不同不会自动支持无线 CarPlay。");
                else for (Map.Entry<String,String> peer:phones.entrySet())
                    result.append("\n已连接手机：").append(peer.getValue()).append('\n').append(peer.getKey());
            }
            return result.toString();
        }
    }
}
