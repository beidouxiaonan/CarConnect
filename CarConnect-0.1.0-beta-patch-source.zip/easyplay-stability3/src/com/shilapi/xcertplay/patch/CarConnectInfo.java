package com.shilapi.xcertplay.patch;
import android.app.*;
import android.content.*;
import android.net.Uri;
import android.widget.Toast;
public final class CarConnectInfo {
    public static final String HOME="https://github.com/beidouxiaonan";
    public static final String VERSION="Carplay-connect-0.1.0-beta";
    public static void open(Activity activity) {
        try { activity.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(HOME))); }
        catch(ActivityNotFoundException error) { Toast.makeText(activity,"GitHub 主页："+HOME,Toast.LENGTH_LONG).show(); }
    }
    public static void about(final Activity activity) {
        if(activity.isFinishing()||activity.isDestroyed())return;
        new AlertDialog.Builder(activity).setTitle("关于 CarConnect")
            .setMessage(VERSION+"\n\nAndroid 4.4 车机测试版。包含触摸调度、视频积压恢复、30/60fps 设置、独立音量与原车蓝牙状态读取。\n\n原车蓝牙状态读取不代表无线 CarPlay 已适配。\n\n基于用户提供的 EasyPlay 0.2.7(36) 修改，参考 DiPlay / xcertplay。保留原许可证及第三方声明。\n\n项目主页："+HOME)
            .setPositiveButton("GitHub 主页",new DialogInterface.OnClickListener(){public void onClick(DialogInterface dialog,int which){open(activity);}})
            .setNegativeButton("关闭",null).show();
    }
}
