package com.shilapi.xcertplay.patch;

import android.content.Context;
import android.content.SharedPreferences;

public final class EnhancementPrefs {
    private static SharedPreferences prefs;
    public static synchronized void init(Context context) {
        if (prefs != null || context == null) return;
        Context app = context.getApplicationContext();
        prefs = (app == null ? context : app).getSharedPreferences("easyplay_enhancements", Context.MODE_PRIVATE);
        AudioLevels.setUserVolumes(prefs.getInt("navigationVolume", 100), prefs.getInt("mediaVolume", 100));
    }
    public static synchronized int getVideoFps(Context context) {
        init(context);
        return prefs != null && prefs.getInt("videoFps", 30) == 60 ? 60 : 30;
    }
    public static synchronized void saveVideoFps(Context context, int fps) {
        init(context);
        if (prefs != null) prefs.edit().putInt("videoFps", fps == 60 ? 60 : 30).apply();
    }
    public static synchronized void saveVolumes() {
        if (prefs != null) prefs.edit().putInt("navigationVolume", AudioLevels.getNavigationVolume())
            .putInt("mediaVolume", AudioLevels.getMediaVolume()).apply();
    }
    public static String fpsSuffix(int fps) { return " / " + fps + "fps"; }
}
