package com.shilapi.xcertplay.patch;

import android.content.*;
import java.util.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class EnhancementPrefsTest {
    private static final class Prefs implements SharedPreferences {
        final Map<String,Object> values=new HashMap<String,Object>();
        public Map<String,?> getAll(){return new HashMap<String,Object>(values);}
        public String getString(String k,String d){return values.containsKey(k)?(String)values.get(k):d;}
        public Set<String> getStringSet(String k,Set<String>d){return d;}
        public int getInt(String k,int d){return values.containsKey(k)?(Integer)values.get(k):d;}
        public long getLong(String k,long d){return d;}
        public float getFloat(String k,float d){return d;}
        public boolean getBoolean(String k,boolean d){return d;}
        public boolean contains(String k){return values.containsKey(k);}
        public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l){}
        public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l){}
        public Editor edit(){return new Editor(){
            public Editor putString(String k,String v){values.put(k,v);return this;}
            public Editor putStringSet(String k,Set<String>v){return this;}
            public Editor putInt(String k,int v){values.put(k,v);return this;}
            public Editor putLong(String k,long v){return this;}
            public Editor putFloat(String k,float v){return this;}
            public Editor putBoolean(String k,boolean v){return this;}
            public Editor remove(String k){values.remove(k);return this;}
            public Editor clear(){values.clear();return this;}
            public boolean commit(){return true;}
            public void apply(){}
        };}
    }
    @Test public void fpsSelectionAndIndependentVolumesArePersisted() {
        final Prefs prefs=new Prefs();prefs.values.put("navigationVolume",45);prefs.values.put("mediaVolume",75);
        Context context=new Context(){public SharedPreferences getSharedPreferences(String n,int m){assertEquals("easyplay_enhancements",n);return prefs;}};
        assertEquals(30,EnhancementPrefs.getVideoFps(context));
        assertEquals(45,AudioLevels.getNavigationVolume());assertEquals(75,AudioLevels.getMediaVolume());
        EnhancementPrefs.saveVideoFps(context,60);assertEquals(60,EnhancementPrefs.getVideoFps(context));
        assertEquals(" / 60fps",EnhancementPrefs.fpsSuffix(60));
        AudioLevels.setUserVolumes(25,55);EnhancementPrefs.saveVolumes();
        assertEquals(25,prefs.getInt("navigationVolume",100));assertEquals(55,prefs.getInt("mediaVolume",100));
        EnhancementPrefs.saveVideoFps(context,120);assertEquals(30,EnhancementPrefs.getVideoFps(context));
    }
}
