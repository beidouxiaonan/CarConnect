from pathlib import Path
import hashlib
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
module = ROOT / 'easyplay-bc03-172-spp'
output = ROOT / 'artifacts/CarConnect-0.1.6-beta-BC03-1.7.2-SPP-patch-source.zip'
files = []
for folder in ['src','stubs','test','tools']:
    files.extend((module / folder).rglob('*.java'))
files.extend(module / n for n in ['build.ps1','patch_apk.py','verify_apk.py','package_public.py',
    'README.md','ANALYSIS.zh-CN.md','BUILD.zh-CN.md','VERIFICATION.zh-CN.md'])
files.extend(ROOT / n for n in ['LICENSE','easyplay-oem4/CREDITS.md','easyplay-oem4/tools/DexTool.java',
    'easyplay-oem4/patch_brand.py','easyplay-oem4/src/com/shilapi/xcertplay/patch/Bc03Schema.java',
    'easyplay-oem4/src/com/shilapi/xcertplay/patch/OemProtocol.java',
    'easyplay-oem4/stubs/com/shilapi/xcertplay/orchestration/CarPlayController.java',
    'easyplay-oem4/stubs/com/shilapi/xcertplay/transport/BluetoothRfcommDuplexStream.java',
    'easyplay-oem4/test/com/shilapi/xcertplay/patch/OemProtocolTest.java'])
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as z:
    for path in sorted(files):
        name = path.relative_to(ROOT).as_posix()
        assert path.is_file() and not any(x in name.split('/') for x in ['.private','build','original','modified','__pycache__'])
        assert path.suffix in ['.java','.py','.ps1','.md'] or path.name == 'LICENSE'
        z.write(path, name)
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None and len(z.namelist()) == len(files)
digest = hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix('.zip.sha256').write_text(digest + '  ' + output.name + '\n', encoding='utf-8')

publication = ROOT / 'artifacts/CarConnect-BC03-172-SPP-publication'
publication.mkdir(exist_ok=True)
readme = '[下载本次测试 APK 和补丁源码](https://github.com/beidouxiaonan/CarConnect/releases/tag/v0.1.6-beta-bc03-172-spp-test)\n\n'
readme += '[操作说明](BC03-172-SPP-USAGE.zh-CN.md) · [分析](BC03-172-SPP-ANALYSIS.zh-CN.md) · [构建](BC03-172-SPP-BUILD.zh-CN.md) · [验证](BC03-172-SPP-VERIFICATION.zh-CN.md)\n\n'
(publication / 'README.md').write_text(readme + (module / 'README.md').read_text(encoding='utf-8'),encoding='utf-8')
for source, target in [('README.md','BC03-172-SPP-USAGE.zh-CN.md'),
    ('ANALYSIS.zh-CN.md','BC03-172-SPP-ANALYSIS.zh-CN.md'),
    ('BUILD.zh-CN.md','BC03-172-SPP-BUILD.zh-CN.md'),
    ('VERIFICATION.zh-CN.md','BC03-172-SPP-VERIFICATION.zh-CN.md')]:
    shutil.copyfile(module / source, publication / target)
shutil.copyfile(output, publication / output.name)
shutil.copyfile(output.with_suffix('.zip.sha256'), publication / output.with_suffix('.zip.sha256').name)
apk_hash=ROOT / 'artifacts/CarConnect-0.1.6-beta-BC03-1.7.2-SPP-test.apk.sha256'
shutil.copyfile(apk_hash,publication / apk_hash.name)
print('Public source:', len(files), 'allowlisted files;', output.stat().st_size, 'bytes; SHA256', digest)
