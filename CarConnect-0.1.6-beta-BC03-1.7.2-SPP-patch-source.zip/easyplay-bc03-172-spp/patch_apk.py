"""Incremental BC03 1.7.2 compatibility patch on the released 0.1.5 BC03 1.7.2 APK."""
from pathlib import Path
import hashlib
import importlib.util
import json
import struct
import sys
import zipfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / '.private/apk-analysis/easyplay/bc03-172-spp'
BASE = ROOT / 'artifacts/CarConnect-0.1.5-beta-BC03-1.7.2-Android4.2-4.4.apk'
BASE_HASH = 'a66ca43a64a0537b955ee988b70a4b89a536584fe457f6e68ced183f703b2443'
OLD_VERSION = 'Carplay-connect-0.1.5-beta-BC03-172-test'
VERSION = 'Carplay-connect-0.1.6-beta-BC03-172-SPP-test'
CODE = 45
APK = ROOT / 'artifacts/CarConnect-0.1.6-beta-BC03-1.7.2-SPP-test.apk'
CLASSES = ['com/shilapi/xcertplay/' + x for x in [
    'patch/EnhancementPanel',
    'patch/CarConnectInfo', 'legacy/LegacyConnectionScreen', 'legacy/LegacySessionService']]
spec = importlib.util.spec_from_file_location('brand', ROOT / 'easyplay-oem4/patch_brand.py')
brand = importlib.util.module_from_spec(spec)
spec.loader.exec_module(brand)


def prepare():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_HASH, 'Unexpected released BC03 baseline'
    WORK.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE) as z:
        (WORK / 'base.dex').write_bytes(z.read('classes3.dex'))


def patch():
    for name in CLASSES:
        text = (WORK / 'original' / (name + '.smali')).read_text(encoding='utf-8')
        text = text.replace(OLD_VERSION, VERSION).replace('CarConnect 0.1.5 beta', 'CarConnect 0.1.6 beta')
        path = WORK / 'modified' / (name + '.smali')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')


def manifest(data):
    data = bytearray(brand.binary_replace(data, {OLD_VERSION: VERSION}))
    at = struct.unpack_from('<H', data, 2)[0]
    names = None
    changed = 0
    while at < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, at)
        if kind == 1:
            names = brand.strings(data[at:at + size])
        elif kind == 0x102:
            start, span, count = struct.unpack_from('<HHH', data, at + 24)
            for i in range(count):
                pos = at + 16 + start + i * span
                if names[struct.unpack_from('<I', data, pos + 4)[0]] == 'versionCode':
                    assert struct.unpack_from('<I', data, pos + 16)[0] == 43
                    struct.pack_into('<I', data, pos + 16, CODE)
                    changed += 1
        at += size
    assert changed == 1
    return bytes(data)


def signing(name):
    n = name.upper()
    return n.startswith('META-INF/') and (n.endswith(('.RSA', '.DSA', '.EC', '.SF')) or n == 'META-INF/MANIFEST.MF')


def repack():
    with zipfile.ZipFile(BASE) as src, zipfile.ZipFile(WORK / 'unsigned.apk', 'w') as dst:
        for info in src.infolist():
            if signing(info.filename):
                continue
            data = src.read(info.filename)
            if info.filename == 'classes3.dex':
                data = (WORK / 'patched.dex').read_bytes()
            elif info.filename == 'AndroidManifest.xml':
                data = manifest(data)
            elif info.filename == 'assets/easyplay/about.html':
                data = data.decode().replace(OLD_VERSION, VERSION)
                data = data.replace('</p>', '</p><p>BC03 1.7.2 SPP 接入测试：状态缺失时限时验证数据通道，保留原有 iAP2 握手校验。尚待实车验证。</p>', 1).encode()
            elif info.filename == 'assets/easyplay/releases.json':
                old = json.loads(data)
                old.insert(0, {'versionCode': CODE, 'versionName': VERSION, 'publishedAt': '2026-10-07',
                    'notesHtml': '<p>BC03 1.7.2 状态缺失时限时验证数据通道；新增 45 秒 VF 冷却和 S1~S6 阶段诊断。保留手机记忆与音视频优化，原 iAP2 握手仍须通过。有线重启问题未解决。</p>'})
                data = json.dumps(old, ensure_ascii=False, indent=2).encode()
            dst.writestr(info, data)


if __name__ == '__main__':
    {'prepare': prepare, 'patch': patch, 'repack': repack}[sys.argv[1]]()
