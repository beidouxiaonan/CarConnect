import java.io.*;
import java.util.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

public class Audit {
    static final String P="Lcom/shilapi/xcertplay/patch/";
    static String canonical(ClassDef c)throws Exception {
        BaksmaliOptions o=new BaksmaliOptions();o.apiLevel=19;o.sequentialLabels=true;
        StringWriter s=new StringWriter();BaksmaliWriter w=new BaksmaliWriter(s);
        ClassDefinition d=new ClassDefinition(o,c);d.writeTo(w);w.flush();
        if(d.hadValidationErrors())throw new Exception("Invalid class "+c.getType());
        return s.toString().replace("\r\n","\n").replace("const-string/jumbo ","const-string ")
            .replaceAll("(?m)^    nop\\n\\n(?=    :(?:pswitch|sswitch)_data_)","")
            .replaceAll("(?m)^(\\.field [^\\r\\n]+?) = (false|0x0|null|0\\.0f?)(?=\\r?$)","$1");
    }
    static String display(String s) {
        return s.replace("Carplay-connect-0.1.5-beta-BC03-172-test","Carplay-connect-0.1.6-beta-BC03-172-SPP-test")
            .replace("CarConnect 0.1.5 beta","CarConnect 0.1.6 beta");
    }
    static boolean transport(String t){return t.equals(P+"OemTransport;")||t.startsWith(P+"OemTransport$");}
    public static void main(String[] args)throws Exception {
        Map<String,ClassDef> now=new TreeMap<>();
        for(ClassDef c:DexFileFactory.loadDexFile(args[1],Opcodes.forApi(19)).getClasses())now.put(c.getType(),c);
        int preserved=0,labels=0,transport=0;
        for(ClassDef old:DexFileFactory.loadDexFile(args[0],Opcodes.forApi(19)).getClasses()) {
            ClassDef c=now.remove(old.getType());if(c==null)throw new Exception("Removed "+old.getType());
            String before=canonical(old),after=canonical(c);
            if(transport(old.getType())){transport++;continue;}
            if(before.equals(after)){preserved++;continue;}
            if(!display(before).equals(after))throw new Exception("Non-transport logic changed "+old.getType());
            labels++;
        }
        Set<String> added=new TreeSet<>(now.keySet());
        for(String t:added)if(!transport(t)&&!t.equals(P+"OemSppGate;")&&!t.equals(P+"OemSppGate$RetryWindow;"))throw new Exception("Unexpected added class "+t);
        if(!added.contains(P+"OemSppGate;")||!added.contains(P+"OemSppGate$RetryWindow;"))throw new Exception("Missing gate");
        System.out.println("Preserved="+preserved+" label-only="+labels+" authored-transport="+transport+" added="+added);
        System.out.println("BC03 gate/fingerprints, iAP2 handshake, audio/video/touch, phone memory, USB/NCM preserved");
    }
}
