package com.shilapi.xcertplay.patch;
import android.content.Context;
final class Bc03Access {
    Bc03Access(Context c)throws Exception {throw new AssertionError("compile-only stub");}
    boolean bool(String m)throws Exception {throw new AssertionError("compile-only stub");}
    Snapshot snapshot()throws Exception {throw new AssertionError("compile-only stub");}
    public void close(){throw new AssertionError("compile-only stub");}
    static final class Snapshot {final String phone=null,local=null,name=null;}
}
