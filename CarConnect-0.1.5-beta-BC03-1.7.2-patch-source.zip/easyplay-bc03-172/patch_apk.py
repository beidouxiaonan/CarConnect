"""Incremental BC03 1.7.2 compatibility patch on the fixed 0.1.5 AV APK."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import struct
import sys
import zipfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / '.private/apk-analysis/easyplay/bc03-172'
BASE = ROOT / 'artifacts/CarConnect-0.1.5-beta-AV-test-Android4.2-4.4.apk'
BASE_HASH = '46b756fe289e47b3d41bec1a4d79da3c4fe752f3ece6a797ffca812d7216d1e8'
OLD_VERSION = 'Carplay-connect-0.1.5-beta-AV-test'
VERSION = 'Carplay-connect-0.1.5-beta-BC03-172-test'
CODE = 43
APK = ROOT / 'artifacts/CarConnect-0.1.5-beta-BC03-1.7.2-Android4.2-4.4.apk'
VENDOR_HASH = '32b25ec4eacada6bad179e4015f1c9ae8f9ce4df4fee9ee8baf6e99a781ede58'
NATIVE_HASH = '3e8f5687b69623087145177358c2104aeae50f2eb943db8711af983e395ced60'
CLASSES = ['com/shilapi/xcertplay/' + x for x in [
    'patch/Bc03Access', 'patch/OemTransport', 'patch/EnhancementPanel',
    'patch/CarConnectInfo', 'legacy/LegacyConnectionScreen', 'legacy/LegacySessionService']]
spec = importlib.util.spec_from_file_location('brand', ROOT / 'easyplay-oem4/patch_brand.py')
brand = importlib.util.module_from_spec(spec)
spec.loader.exec_module(brand)


def one(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def edit(text, signature, change):
    matches = list(re.finditer(r'^\.method [^\n]*' + re.escape(signature) + r'\n.*?^\.end method', text, re.M | re.S))
    assert len(matches) == 1, signature
    m = matches[0]
    return text[:m.start()] + change(m[0]) + text[m.end():]


def prepare():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest() == BASE_HASH, 'Unexpected AV baseline'
    WORK.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE) as z:
        (WORK / 'base.dex').write_bytes(z.read('classes3.dex'))
    for folder, digest in [('bc03-172', VENDOR_HASH), ('bc03-179', '079e6446c475eaf7d067853cf525feedbf9a9619408db6df83d873c200616326')]:
        path = ROOT / '.private/vendor-analysis' / folder / 'input.apk'
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, 'Vendor input mismatch: ' + folder
        with zipfile.ZipFile(path) as z:
            (WORK / (folder + '.dex')).write_bytes(z.read('classes.dex'))
    native = ROOT / '.private/vendor-analysis/bc03-172/gocsdk'
    assert hashlib.sha256(native.read_bytes()).hexdigest() == NATIVE_HASH, 'Unverified gocsdk'


def patch():
    for name in CLASSES:
        text = (WORK / 'original' / (name + '.smali')).read_text(encoding='utf-8')
        if name.endswith('Bc03Access'):
            def gate(m):
                return one(m, '    const-string v3, "1.7.9"', '''    const-string v3, "1.7.2"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_29

    const-string v3, "1.7.9"''')
            text = edit(text, '<init>(Landroid/content/Context;)V', gate)
        elif name.endswith('OemTransport'):
            def fingerprints(m):
                m = one(m, '    const/4 v0, 0x2', '    const/4 v0, 0x3')
                marker = '    sput-object v0, Lcom/shilapi/xcertplay/patch/OemTransport;->APK_SHA:[Ljava/lang/String;'
                return one(m, marker, f'''    const-string v1, "{VENDOR_HASH}"

    const/4 v2, 0x2

    aput-object v1, v0, v2

{marker}''')
            text = edit(text, '<clinit>()V', fingerprints)
        text = text.replace(OLD_VERSION, VERSION).replace('CarConnect 0.1.5 beta', 'CarConnect 0.1.5 beta · BC03 1.7.2')
        text = text.replace('BC03 1.7.9 / 1.3.6', 'BC03 1.7.2 / 1.7.9 / 1.3.6')
        if name.endswith('CarConnectInfo'):
            # Keep the credits and URLs; add the model-specific testing limitation.
            text = one(text, 'Android 4.2~4.4 ',
                r'K2001N_HDKJ_S112406 / BC03 1.7.2\n\u65e0\u7ebf\u9002\u914d\u6d4b\u8bd5\u7248\uff0c\u5c1a\u5f85\u8f66\u673a\u9a8c\u8bc1\u3002\u8be5\u673a\u578b\u6709\u7ebf\u91cd\u542f\u95ee\u9898\u672a\u89e3\u51b3\uff0c\u8bf7\u4f7f\u7528\u65e0\u7ebf\u6a21\u5f0f\u3002\n\nAndroid 4.2~4.4 ')
        path = WORK / 'modified' / (name + '.smali')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')


def manifest(data):
    data = bytearray(brand.binary_replace(data, {OLD_VERSION: VERSION}))
    at = struct.unpack_from('<H', data, 2)[0]
    names = None
    changed = 0
    while at < len(data):
        kind, header, size = struct.unpack_from('<HHI', data, at)
        if kind == 1:
            names = brand.strings(data[at:at + size])
        elif kind == 0x102:
            start, span, count = struct.unpack_from('<HHH', data, at + 24)
            for i in range(count):
                pos = at + 16 + start + i * span
                if names[struct.unpack_from('<I', data, pos + 4)[0]] == 'versionCode':
                    assert struct.unpack_from('<I', data, pos + 16)[0] == 42
                    struct.pack_into('<I', data, pos + 16, CODE)
                    changed += 1
        at += size
    assert changed == 1
    return bytes(data)


def signing(name):
    n = name.upper()
    return n.startswith('META-INF/') and (n.endswith(('.RSA', '.DSA', '.EC', '.SF')) or n == 'META-INF/MANIFEST.MF')


def repack():
    with zipfile.ZipFile(BASE) as src, zipfile.ZipFile(WORK / 'unsigned.apk', 'w') as dst:
        for info in src.infolist():
            if signing(info.filename):
                continue
            data = src.read(info.filename)
            if info.filename == 'classes3.dex':
                data = (WORK / 'patched.dex').read_bytes()
            elif info.filename == 'AndroidManifest.xml':
                data = manifest(data)
            elif info.filename == 'assets/easyplay/about.html':
                data = data.decode().replace(OLD_VERSION, VERSION).replace('BC03 1.7.9 / 1.3.6', 'BC03 1.7.2 / 1.7.9 / 1.3.6')
                data = data.replace('</p>', '</p><p>K2001N_HDKJ_S112406 / BC03 1.7.2 无线测试版；尚待实车验证。这台车机的有线启动重启问题未解决，请使用无线模式。</p>', 1).encode()
            elif info.filename == 'assets/easyplay/releases.json':
                old = json.loads(data)
                old.insert(0, {'versionCode': CODE, 'versionName': VERSION, 'publishedAt': '2026-10-07',
                    'notesHtml': '<p>新增已核对的 BC03 1.7.2 服务与 gocsdk 指纹；保留手机记忆和 0.1.5 音频/全屏优化。K2001N 有线重启问题未解决，本包用于无线测试。</p>'})
                data = json.dumps(old, ensure_ascii=False, indent=2).encode()
            dst.writestr(info, data)


if __name__ == '__main__':
    {'prepare': prepare, 'patch': patch, 'repack': repack}[sys.argv[1]]()
