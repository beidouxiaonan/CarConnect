import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

/** Compare actual supplied DEX methods; do not execute vendor bytecode. */
public class VendorAudit {
    static Map<String,String> methods(String path,String type)throws Exception {
        for(ClassDef c:DexFileFactory.loadDexFile(path,Opcodes.forApi(19)).getClasses())if(c.getType().equals(type)) {
            BaksmaliOptions o=new BaksmaliOptions();o.apiLevel=19;o.sequentialLabels=true;o.debugInfo=false;
            StringWriter s=new StringWriter();BaksmaliWriter w=new BaksmaliWriter(s);new ClassDefinition(o,c).writeTo(w);w.flush();
            Map<String,String> r=new TreeMap<>();
            Matcher m=Pattern.compile("(?m)^\\.method [^\\n]*?([^\\s]+\\([^\\n]+)\\n.*?^\\.end method",Pattern.DOTALL).matcher(s.toString());
            while(m.find())r.put(m.group(1).trim(),m.group().replace("const-string/jumbo ","const-string "));
            return r;
        }
        throw new Exception("Missing vendor class "+type);
    }
    public static void main(String[] a)throws Exception {
        String[] types={"Lcom/bt/BTDevice;","Lcom/bt/bc03/HdLinkManager;","Lcom/bt/bc03/BTManager;"};
        String[][] selected={{"<init>(Landroid/os/Parcel;)V","writeToParcel(Landroid/os/Parcel;I)V"},
            {"SppConnect(Ljava/lang/String;)Z","isSppConnect()Z","onSppConnnected(ZLjava/lang/String;)V"},
            {"isBlueToothPowerOn()Z","isConnectDevice()Z","isConnectHFP()Z","isConnectA2DP()Z",
                "getLocalDeviceName()Ljava/lang/String;","getLocalDeviceAddress()Ljava/lang/String;",
                "getConnectDevice()Lcom/bt/BTDevice;","isSppConnect()Z","SppConnect(Ljava/lang/String;)Z"}};
        int count=0;
        for(int i=0;i<types.length;i++) {
            Map<String,String> n=methods(a[0],types[i]),old=methods(a[1],types[i]);
            for(String name:selected[i]) {
                if(n.get(name)==null||!n.get(name).equals(old.get(name)))throw new Exception("Review changed semantics: "+types[i]+name);
                count++;
            }
        }
        String stub=methods(a[0],types[1]).get("SppConnect(Ljava/lang/String;)Z");
        if(!stub.contains("const/4 v0, 0x1")||!stub.contains("return v0")||stub.contains("Lcom/bt/bc03/feature/"))
            throw new Exception("Unexpected SppConnect implementation");
        System.out.println(count+" relevant 1.7.2 method bodies match verified 1.7.9; Parcel layout and empty SppConnect confirmed");
    }
}
