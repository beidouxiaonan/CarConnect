import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.baksmali.*;
import com.android.tools.smali.baksmali.Adaptors.ClassDefinition;
import com.android.tools.smali.baksmali.formatter.BaksmaliWriter;

public class Audit {
    static String canonical(ClassDef c)throws Exception {
        BaksmaliOptions o=new BaksmaliOptions();o.apiLevel=19;o.sequentialLabels=true;
        StringWriter s=new StringWriter();BaksmaliWriter w=new BaksmaliWriter(s);
        ClassDefinition d=new ClassDefinition(o,c);d.writeTo(w);w.flush();
        if(d.hadValidationErrors())throw new Exception("Invalid class "+c.getType());
        return s.toString().replace("\r\n","\n").replace("const-string/jumbo ","const-string ")
            // Repacking changes instruction width; switch-payload alignment padding is not executable logic.
            .replaceAll("(?m)^    nop\\n\\n(?=    :(?:pswitch|sswitch)_data_)","")
            .replaceAll("(?m)^(\\.field [^\\r\\n]+?) = (false|0x0|null|0\\.0f?)(?=\\r?$)","$1");
    }
    static Map<String,String> methods(String s){
        Map<String,String> r=new TreeMap<>();
        Matcher m=Pattern.compile("(?m)^\\.method ([^\\n]+)\\n.*?^\\.end method",Pattern.DOTALL).matcher(s);
        while(m.find())r.put(m.group(1).trim(),m.group());return r;
    }
    static String display(String before){
        return before.replace("Carplay-connect-0.1.5-beta-AV-test","Carplay-connect-0.1.5-beta-BC03-172-test")
            .replace("CarConnect 0.1.5 beta","CarConnect 0.1.5 beta \\u00b7 BC03 1.7.2")
            .replace("BC03 1.7.9 / 1.3.6","BC03 1.7.2 / 1.7.9 / 1.3.6");
    }
    public static void main(String[] a)throws Exception {
        Map<String,ClassDef> now=new TreeMap<>();
        for(ClassDef c:DexFileFactory.loadDexFile(a[1],Opcodes.forApi(19)).getClasses())now.put(c.getType(),c);
        int unchanged=0;Set<String> changes=new TreeSet<>();
        for(ClassDef c:DexFileFactory.loadDexFile(a[0],Opcodes.forApi(19)).getClasses()) {
            ClassDef n=now.remove(c.getType());if(n==null)throw new Exception("Removed class "+c.getType());
            String before=canonical(c),after=canonical(n);
            if(before.equals(after)){unchanged++;continue;}
            String type=c.getType();changes.add(type);
            if(!display(before.substring(0,before.indexOf(".method "))).equals(after.substring(0,after.indexOf(".method "))))
                throw new Exception("Unexpected class metadata change "+type);
            Map<String,String> bm=methods(before),nm=methods(after);
            if(!bm.keySet().equals(nm.keySet()))throw new Exception("Changed method set "+type);
            for(String name:bm.keySet()) {
                if(display(bm.get(name)).equals(nm.get(name)))continue;
                boolean allowed=type.endsWith("/Bc03Access;")&&name.equals("constructor <init>(Landroid/content/Context;)V");
                allowed|=type.endsWith("/OemTransport;")&&name.equals("static constructor <clinit>()V");
                allowed|=type.endsWith("/CarConnectInfo;")&&name.equals("public static about(Landroid/app/Activity;)V");
                if(!allowed) {
                    java.nio.file.Files.write(java.nio.file.Paths.get(".private/apk-analysis/easyplay/bc03-172/audit-before.txt"),bm.get(name).getBytes("UTF-8"));
                    java.nio.file.Files.write(java.nio.file.Paths.get(".private/apk-analysis/easyplay/bc03-172/audit-after.txt"),nm.get(name).getBytes("UTF-8"));
                    throw new Exception("Unexpected method change "+type+name);
                }
                System.out.println("Changed "+type+" "+name);
            }
        }
        Set<String> expected=new TreeSet<>();
        for(String s:new String[]{"patch/Bc03Access","patch/OemTransport","patch/EnhancementPanel","patch/CarConnectInfo",
                "legacy/LegacyConnectionScreen","legacy/LegacySessionService"})expected.add("Lcom/shilapi/xcertplay/"+s+";");
        if(!changes.equals(expected)||!now.isEmpty())throw new Exception("Unexpected class set changes "+changes+" added="+now.keySet());
        System.out.println("Unchanged="+unchanged+" changed="+changes.size()+" added=0; audio/video/touch/USB/NCM and Bluetooth stream code preserved");
    }
}
