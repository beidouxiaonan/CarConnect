param([string]$PythonPath='D:/Program Files/Python3.13.13/python.exe')
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath("$PSScriptRoot/..")
$work="$root/.private/apk-analysis/easyplay/bc03-172"
$patchRoot=$PSScriptRoot
$java="$root/.tooling/jdk25/bin/java.exe"
$javac="$root/.tooling/jdk25/bin/javac.exe"
$android="$root/.tooling/platform/android-4.2.2/android.jar"
$bt="$root/.tooling/build-tools/android-15"
$jadx="$root/.tooling/jadx/lib/jadx-1.5.6-all.jar"
function Run([string]$stage,[scriptblock]$block) {
    $prev=$ErrorActionPreference; $ErrorActionPreference='Continue'
    try { $lines=& $block 2>&1; $code=$LASTEXITCODE } finally { $ErrorActionPreference=$prev }
    foreach($line in $lines) { Write-Output "$line" }
    if($code -ne 0) { throw "$stage failed: $code" }
}
Push-Location $root
try {
    New-Item -ItemType Directory -Force "$patchRoot/build/tests","$patchRoot/build/core" | Out-Null
    Run 'Verify baseline/vendor fingerprints and extract' { & $PythonPath "$patchRoot/patch_apk.py" prepare }
    foreach($name in @('original','modified')) {
        $target=[IO.Path]::GetFullPath("$work/$name")
        if([IO.Path]::GetDirectoryName($target) -ne [IO.Path]::GetFullPath($work) -or
            -not $target.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe generated path' }
        if(Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    }
    Run 'Vendor method semantics' { & $java -cp $jadx "$patchRoot/tools/VendorAudit.java" "$work/bc03-172.dex" "$work/bc03-179.dex" }
    $selected=@('Lcom/shilapi/xcertplay/patch/Bc03Access;','Lcom/shilapi/xcertplay/patch/OemTransport;',
        'Lcom/shilapi/xcertplay/patch/EnhancementPanel;','Lcom/shilapi/xcertplay/patch/CarConnectInfo;',
        'Lcom/shilapi/xcertplay/legacy/LegacyConnectionScreen;','Lcom/shilapi/xcertplay/legacy/LegacySessionService;')
    Run 'Disassemble selected classes' { & $java -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" dis "$work/base.dex" "$work/original" @selected }
    Run 'Compile read-only schema and protocol API17 regressions' {
        & $javac --release 8 -encoding UTF-8 -cp $android -d "$patchRoot/build/core" "$root/easyplay-oem4/src/com/shilapi/xcertplay/patch/Bc03Schema.java" "$root/easyplay-oem4/src/com/shilapi/xcertplay/patch/OemProtocol.java"
    }
    $cp="$patchRoot/build/core;$root/.tooling/test-libs/junit.jar;$root/.tooling/test-libs/hamcrest.jar;$android"
    Run 'Compile tests' {
        & $javac --release 8 -encoding UTF-8 -cp $cp -d "$patchRoot/build/tests" "$root/easyplay-oem4/test/com/shilapi/xcertplay/patch/Bc03SchemaTest.java" "$root/easyplay-oem4/test/com/shilapi/xcertplay/patch/OemProtocolTest.java" "$patchRoot/test/com/shilapi/xcertplay/patch/Bc03Firmware172Test.java"
    }
    Run 'Required actual172 and previous firmware regressions' {
        & $java -cp "$cp;$patchRoot/build/tests" org.junit.runner.JUnitCore com.shilapi.xcertplay.patch.Bc03SchemaTest com.shilapi.xcertplay.patch.OemProtocolTest com.shilapi.xcertplay.patch.Bc03Firmware172Test
    }
    Run 'Patch' { & $PythonPath "$patchRoot/patch_apk.py" patch }
    Run 'Assemble' { & $java -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" asm "$work/modified" "$work/overlay.dex" }
    Run 'Merge' { & $java -Xmx1g -cp $jadx "$root/easyplay-oem4/tools/DexTool.java" merge "$work/patched.dex" "$work/base.dex" "$work/overlay.dex" }
    Run 'Canonical unchanged class/method audit' { & $java -Xmx1g -cp $jadx "$patchRoot/tools/Audit.java" "$work/base.dex" "$work/patched.dex" }
    Run 'Repack' { & $PythonPath "$patchRoot/patch_apk.py" repack }
    Run 'Align' { & "$bt/zipalign.exe" -f 4 "$work/unsigned.apk" "$work/aligned.apk" }
    $apk="$root/artifacts/CarConnect-0.1.5-beta-BC03-1.7.2-Android4.2-4.4.apk"
    Run 'Sign V1 only with previous CarConnect test key' {
        & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" sign --ks "$root/.private/kitkat-probe-debug.jks" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --min-sdk-version 17 --v1-signing-enabled true --v2-signing-enabled false --v3-signing-enabled false --v4-signing-enabled false --out $apk "$work/aligned.apk"
    }
    Run 'API17 signature check' { & $java --enable-native-access=ALL-UNNAMED -jar "$bt/lib/apksigner.jar" verify --verbose --print-certs --min-sdk-version 17 $apk }
    Run 'Alignment check' { & "$bt/zipalign.exe" -c 4 $apk }
    Run 'Payload check' { & $PythonPath "$patchRoot/verify_apk.py" }
    Run 'Manifest check' { & "$bt/aapt.exe" dump xmltree $apk AndroidManifest.xml }
    Write-Output "Output: $apk"
} finally { Pop-Location }
