package android.os;
public class SystemClock { public static long now; public static long elapsedRealtime(){return now;} }
