package com.shilapi.xcertplay.patch;
import java.io.IOException;
import org.junit.Test;import static org.junit.Assert.*;
public class SppReleaseTest {
    private static class F implements SppRelease.Port,SppRelease.Monitor,SppRelease.Time {
        long tick,clearAt=300000000L; int commands; boolean initial=true,fail,cancel,cancelAfter;String last;
        public boolean connected(){return initial&&(commands==0||tick<clearAt);}
        public void disconnect()throws Exception{commands++;if(fail)throw new IOException("binder failure");if(cancelAfter)cancel=true;}
        public void check()throws Exception{if(cancel)throw new IOException("cancelled");}
        public void log(String s){last=s;}
        public long now(){return tick;}
        public void pause(){tick+=150000000L;}
    }
    private static void rejects(SppRelease r,boolean enabled,boolean owned,F f,String text)throws Exception {
        try{r.ensureFree(enabled,owned,f,f,f);fail("unexpected continuation");}
        catch(IOException e){assertTrue(e.getMessage(),e.getMessage().contains(text));}
    }
    @Test public void disabledNeverDisconnectsOccupiedChannel()throws Exception{F f=new F();rejects(new SppRelease(),false,false,f,"开关未开启");assertEquals(0,f.commands);}
    @Test public void freeChannelRequiresNoDisconnectEvenWhenDisabled()throws Exception{F f=new F();f.initial=false;assertFalse(new SppRelease().ensureFree(false,false,f,f,f));assertEquals(0,f.commands);}
    @Test public void ownSessionProtectedWhenEnabled()throws Exception{F f=new F();rejects(new SppRelease(),true,true,f,"自己");assertEquals(0,f.commands);}
    @Test public void waitsForAcknowledgedStableRelease()throws Exception{F f=new F();assertTrue(new SppRelease().ensureFree(true,false,f,f,f));assertEquals(1,f.commands);assertEquals(600000000L,f.tick);assertTrue(f.last.startsWith("C3"));}
    @Test public void returnedVoidDoesNotMeanReleased()throws Exception{F f=new F();f.clearAt=Long.MAX_VALUE;rejects(new SppRelease(),true,false,f,"超时");assertEquals(1,f.commands);assertTrue(f.tick>=SppRelease.WAIT);assertFalse(f.last.startsWith("C3"));}
    @Test public void temporaryFalseStateDoesNotReleaseGate()throws Exception{
        F f=new F(){public boolean connected(){if(commands==0)return true;return tick<300000000L||(tick>=450000000L&&tick<900000000L);}};
        assertTrue(new SppRelease().ensureFree(true,false,f,f,f));assertEquals(1200000000L,f.tick);assertEquals(1,f.commands);
    }
    @Test public void disconnectErrorCannotProceedAndIsRateLimited()throws Exception{F f=new F();f.fail=true;SppRelease r=new SppRelease();rejects(r,true,false,f,"binder failure");f.fail=false;rejects(r,true,false,f,"冷却");assertEquals(1,f.commands);}
    @Test public void timeoutRetryDoesNotRepeatDisconnect()throws Exception{F f=new F();f.clearAt=Long.MAX_VALUE;SppRelease r=new SppRelease();rejects(r,true,false,f,"超时");rejects(r,true,false,f,"冷却");assertEquals(1,f.commands);}
    @Test public void cancelledBeforeDispatchDoesNotDisconnect()throws Exception{F f=new F();f.cancel=true;rejects(new SppRelease(),true,false,f,"cancelled");assertEquals(0,f.commands);}
    @Test public void cancellationDuringWaitCannotContinue()throws Exception{F f=new F();f.cancelAfter=true;rejects(new SppRelease(),true,false,f,"cancelled");assertEquals(1,f.commands);assertFalse(f.last.startsWith("C3"));}
    @Test public void stateMayReleaseWithoutDispatch()throws Exception{F f=new F(){int reads;public boolean connected(){return ++reads==1;}};assertFalse(new SppRelease().ensureFree(true,false,f,f,f));assertEquals(0,f.commands);}
    @Test public void freedChannelMayConnectDuringCooldown()throws Exception{F f=new F();SppRelease r=new SppRelease();assertTrue(r.ensureFree(true,false,f,f,f));f.initial=false;assertFalse(r.ensureFree(true,false,f,f,f));assertEquals(1,f.commands);}
    @Test public void subsequentOccupiedChannelCanRetryAtCooldownBoundary()throws Exception{F f=new F();SppRelease r=new SppRelease();assertTrue(r.ensureFree(true,false,f,f,f));f.tick=SppRelease.COOLDOWN;f.clearAt=f.tick+300000000L;assertTrue(r.ensureFree(true,false,f,f,f));assertEquals(2,f.commands);}
}
